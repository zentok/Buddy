package com.buddy;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Buddy implements ModInitializer {
	public static final String MOD_ID = "buddy";
	public static final Logger LOGGER = LoggerFactory.getLogger("Buddy");
	public static final String DEFAULT_NAME = "Buddy";

	@Override
	public void onInitialize() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> registerCommands(dispatcher));
		ServerTickEvents.END_SERVER_TICK.register(BuddyManager::tick);
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> BuddyManager.onPlayerJoin(handler.player));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> BuddyManager.onPlayerLeave(handler.player));
		ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
			if (!(sender instanceof BuddyPlayer)) onChat(sender, message.getContent().getString());
		});
		LOGGER.info("Buddy загружен: /buddy spawn — позвать напарника");
	}

	// ================================================================ команды /buddy

	private static void registerCommands(CommandDispatcher<ServerCommandSource> d) {
		d.register(CommandManager.literal("buddy")
				.then(CommandManager.literal("spawn")
						.executes(c -> spawn(c, DEFAULT_NAME))
						.then(CommandManager.argument("name", StringArgumentType.word())
								.executes(c -> spawn(c, StringArgumentType.getString(c, "name")))))
				.then(CommandManager.literal("remove")
						.executes(c -> remove(c, null))
						.then(CommandManager.argument("name", StringArgumentType.word())
								.executes(c -> remove(c, StringArgumentType.getString(c, "name")))))
				.then(modeCommand("follow", BuddyPlayer.Mode.FOLLOW))
				.then(modeCommand("stay", BuddyPlayer.Mode.STAY))
				.then(modeCommand("come", BuddyPlayer.Mode.COME))
				.then(CommandManager.literal("list").executes(Buddy::list)));
	}

	private static com.mojang.brigadier.builder.LiteralArgumentBuilder<ServerCommandSource> modeCommand(String lit, BuddyPlayer.Mode mode) {
		return CommandManager.literal(lit)
				.executes(c -> setMode(c, null, mode))
				.then(CommandManager.argument("name", StringArgumentType.word())
						.executes(c -> setMode(c, StringArgumentType.getString(c, "name"), mode)));
	}

	private static int spawn(CommandContext<ServerCommandSource> c, String name) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
		ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
		String err = BuddyManager.create(p, name);
		if (err != null) {
			c.getSource().sendError(Text.literal(err));
			return 0;
		}
		return 1;
	}

	private static int remove(CommandContext<ServerCommandSource> c, String name) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
		ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
		List<BuddyPlayer> targets = targets(p, name);
		MinecraftServer server = c.getSource().getServer();
		if (targets.isEmpty() && name != null) {
			BuddyState.Entry e = BuddyManager.state(server).bots.get(name.toLowerCase(Locale.ROOT));
			if (e != null && (e.owner().equals(p.getUuid()) || p.hasPermissionLevel(2))) {
				BuddyManager.delete(server, name);
				c.getSource().sendFeedback(() -> Text.literal("Бот " + name + " убран"), false);
				return 1;
			}
		}
		if (targets.isEmpty()) {
			c.getSource().sendError(Text.literal("Нет твоих ботов с таким именем"));
			return 0;
		}
		for (BuddyPlayer b : targets) {
			String n = b.getGameProfile().getName();
			b.say("Пока!");
			BuddyManager.delete(server, n);
		}
		c.getSource().sendFeedback(() -> Text.literal("Убрано ботов: " + targets.size()), false);
		return targets.size();
	}

	private static int setMode(CommandContext<ServerCommandSource> c, String name, BuddyPlayer.Mode mode) throws com.mojang.brigadier.exceptions.CommandSyntaxException {
		ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
		List<BuddyPlayer> targets = targets(p, name);
		if (targets.isEmpty()) {
			c.getSource().sendError(Text.literal("Нет твоих ботов в игре. Позови: /buddy spawn"));
			return 0;
		}
		for (BuddyPlayer b : targets) applyMode(b, mode);
		return targets.size();
	}

	private static int list(CommandContext<ServerCommandSource> c) {
		MinecraftServer server = c.getSource().getServer();
		BuddyState st = BuddyManager.state(server);
		if (st.bots.isEmpty()) {
			c.getSource().sendFeedback(() -> Text.literal("Ботов нет. /buddy spawn — позвать"), false);
			return 0;
		}
		for (BuddyState.Entry e : st.bots.values()) {
			BuddyPlayer b = BuddyManager.byName(server, e.name());
			ServerPlayerEntity owner = server.getPlayerManager().getPlayer(e.owner());
			String ownerName = owner != null ? owner.getGameProfile().getName() : e.owner().toString().substring(0, 8);
			String where = b == null ? "не в игре" : String.format(Locale.ROOT, "%s, %.0f %.0f %.0f, ❤ %.0f",
					modeName(b.getMode()), b.getX(), b.getY(), b.getZ(), b.getHealth());
			c.getSource().sendFeedback(() -> Text.literal("• " + e.name() + " (хозяин " + ownerName + "): " + where), false);
		}
		return st.bots.size();
	}

	/** Боты игрока: конкретный по имени или все его. */
	private static List<BuddyPlayer> targets(ServerPlayerEntity p, String name) {
		MinecraftServer server = p.getServer();
		List<BuddyPlayer> out = new ArrayList<>();
		if (server == null) return out;
		if (name != null) {
			BuddyPlayer b = BuddyManager.byName(server, name);
			if (b != null && (b.getOwner().equals(p.getUuid()) || p.hasPermissionLevel(2))) out.add(b);
		} else {
			out.addAll(BuddyManager.ownedBy(server, p.getUuid()));
		}
		return out;
	}

	private static void applyMode(BuddyPlayer b, BuddyPlayer.Mode mode) {
		b.setMode(mode);
		switch (mode) {
			case FOLLOW -> b.say("Иду за тобой!");
			case STAY -> b.say("Стою здесь.");
			case COME -> b.say("Бегу к тебе!");
		}
	}

	private static String modeName(BuddyPlayer.Mode m) {
		return switch (m) {
			case FOLLOW -> "следует";
			case STAY -> "стоит";
			case COME -> "идёт к хозяину";
		};
	}

	// ================================================================ команды в чате

	private static final String[][] CHAT = {
			{"FOLLOW", "!следуй", "!за мной", "!follow", "!иди за мной"},
			{"STAY", "!стой", "!стоп", "!жди", "!stay", "!stop"},
			{"COME", "!ко мне", "!сюда", "!come", "!иди сюда"},
	};

	private static void onChat(ServerPlayerEntity sender, String raw) {
		String text = raw.trim();
		if (!text.startsWith("!")) return;
		String lower = text.toLowerCase(Locale.ROOT);
		for (String[] row : CHAT) {
			for (int i = 1; i < row.length; i++) {
				String cmd = row[i];
				if (lower.equals(cmd) || lower.startsWith(cmd + " ")) {
					String rest = text.substring(cmd.length()).trim();
					List<BuddyPlayer> targets = targets(sender, rest.isEmpty() ? null : rest);
					BuddyPlayer.Mode mode = BuddyPlayer.Mode.valueOf(row[0]);
					for (BuddyPlayer b : targets) applyMode(b, mode);
					return;
				}
			}
		}
	}
}
