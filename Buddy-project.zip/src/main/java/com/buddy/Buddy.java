package com.buddy;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.block.BedBlock;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Buddy implements ModInitializer {
	public static final String MOD_ID = "buddy";
	public static final Logger LOGGER = LoggerFactory.getLogger("Buddy");
	public static final String DEFAULT_NAME = "Buddy";

	@Override
	public void onInitialize() {
		BuddyConfig.load();
		BuddyNet.registerServer();
		CommandRegistrationCallback.EVENT.register((dispatcher, registry, env) -> registerCommands(dispatcher));
		ServerTickEvents.END_SERVER_TICK.register(BuddyManager::tick);
		ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> BuddyManager.onPlayerJoin(handler.player));
		ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> BuddyManager.onPlayerLeave(handler.player));
		ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
			if (!(sender instanceof BuddyPlayer)) onChat(sender, message.getContent().getString());
		});
		LOGGER.info("Buddy загружен: /buddy spawn — позвать напарника");
	}

	// ================================================================ единая точка команд (чат, /buddy, колесо)

	/**
	 * Выполнить действие для ботов игрока.
	 * action: follow, stay, come, mine[:y], chop, store, bed, unload. target — имя бота или null (все свои).
	 * pos — блок под прицелом (для склада и кровати), если пришёл с клиента.
	 */
	public static void runAction(ServerPlayerEntity p, String action, @Nullable String target, @Nullable BlockPos pos) {
		List<BuddyPlayer> bots = targets(p, target);
		if (bots.isEmpty()) {
			p.sendMessage(Text.literal("§cНет твоих ботов в игре. Позови: /buddy spawn"), false);
			return;
		}
		ServerWorld w = p.getServerWorld();
		if (pos != null && pos.getSquaredDistance(p.getBlockPos()) > 8 * 8) pos = null;
		if (pos == null) pos = BuddyNet.lookedAt(p);
		String a = action.toLowerCase(Locale.ROOT);
		Integer y = null;
		if (a.startsWith("mine:")) {
			try {
				y = Integer.parseInt(a.substring(5).trim());
			} catch (NumberFormatException ignored) {
			}
			a = "mine";
		}
		for (BuddyPlayer b : bots) {
			switch (a) {
				case "follow" -> {
					b.setMode(BuddyPlayer.Mode.FOLLOW);
					b.say("Иду за тобой!");
				}
				case "stay" -> {
					b.setMode(BuddyPlayer.Mode.STAY);
					b.say("Остаюсь здесь. Буду собирать урожай вокруг и носить в сундук.");
				}
				case "come" -> {
					b.setMode(BuddyPlayer.Mode.COME);
					b.say("Бегу к тебе!");
				}
				case "mine" -> {
					if (y != null) b.setMineTargetY(y);
					b.setMode(BuddyPlayer.Mode.MINE);
				}
				case "chop" -> b.setMode(BuddyPlayer.Mode.CHOP);
				case "unload" -> b.setMode(BuddyPlayer.Mode.UNLOAD);
				case "store" -> {
					if (pos != null && BuddyNet.isContainer(w, pos)) {
						b.setStoragePos(pos);
						b.say("Запомнил сундук на " + pos.getX() + " " + pos.getY() + " " + pos.getZ() + " — буду носить добычу сюда.");
					} else {
						b.setStoragePos(null);
						b.say("Посмотри на сундук и повтори. Пока ношу в ближайший к месту работы.");
					}
				}
				case "bed" -> {
					BlockPos head = pos != null ? BuddyPlayer.bedHead(w, pos) : null;
					if (head != null && w.getBlockState(head).getBlock() instanceof BedBlock) {
						b.setBedPos(head);
						b.say("Это моя кровать. Когда ты ляжешь спать, лягу и я.");
					} else {
						b.setBedPos(null);
						b.say("Посмотри на кровать и повтори. Пока лягу в любую свободную рядом.");
					}
				}
				default -> p.sendMessage(Text.literal("§cНеизвестная команда: " + action), false);
			}
		}
	}

	// ================================================================ команды /buddy

	private static void registerCommands(CommandDispatcher<ServerCommandSource> d) {
		LiteralArgumentBuilder<ServerCommandSource> root = CommandManager.literal("buddy")
				.then(CommandManager.literal("spawn")
						.executes(c -> spawn(c, DEFAULT_NAME))
						.then(CommandManager.argument("name", StringArgumentType.word())
								.executes(c -> spawn(c, StringArgumentType.getString(c, "name")))))
				.then(CommandManager.literal("remove")
						.executes(c -> remove(c, null))
						.then(CommandManager.argument("name", StringArgumentType.word())
								.executes(c -> remove(c, StringArgumentType.getString(c, "name")))))
				.then(CommandManager.literal("list").executes(Buddy::list))
				.then(CommandManager.literal("reload").requires(s -> s.hasPermissionLevel(2)).executes(c -> {
					BuddyConfig.load();
					c.getSource().sendFeedback(() -> Text.literal("config/buddy.json перечитан"), false);
					return 1;
				}))
				.then(CommandManager.literal("mine")
						.executes(c -> action(c, "mine", null))
						.then(CommandManager.argument("y", IntegerArgumentType.integer(-64, 320))
								.executes(c -> action(c, "mine:" + IntegerArgumentType.getInteger(c, "y"), null))));
		for (String a : new String[]{"follow", "stay", "come", "chop", "store", "bed", "unload"}) {
			root.then(CommandManager.literal(a)
					.executes(c -> action(c, a, null))
					.then(CommandManager.argument("name", StringArgumentType.word())
							.executes(c -> action(c, a, StringArgumentType.getString(c, "name")))));
		}
		d.register(root);
	}

	private static int action(CommandContext<ServerCommandSource> c, String a, @Nullable String name) throws CommandSyntaxException {
		runAction(c.getSource().getPlayerOrThrow(), a, name, null);
		return 1;
	}

	private static int spawn(CommandContext<ServerCommandSource> c, String name) throws CommandSyntaxException {
		ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
		String err = BuddyManager.create(p, name);
		if (err != null) {
			c.getSource().sendError(Text.literal(err));
			return 0;
		}
		return 1;
	}

	private static int remove(CommandContext<ServerCommandSource> c, @Nullable String name) throws CommandSyntaxException {
		ServerPlayerEntity p = c.getSource().getPlayerOrThrow();
		List<BuddyPlayer> bots = targets(p, name);
		MinecraftServer server = c.getSource().getServer();
		if (bots.isEmpty() && name != null) {
			BuddyState.Entry e = BuddyManager.state(server).bots.get(name.toLowerCase(Locale.ROOT));
			if (e != null && (e.owner().equals(p.getUuid()) || p.hasPermissionLevel(2))) {
				BuddyManager.delete(server, name);
				c.getSource().sendFeedback(() -> Text.literal("Бот " + name + " убран"), false);
				return 1;
			}
		}
		if (bots.isEmpty()) {
			c.getSource().sendError(Text.literal("Нет твоих ботов с таким именем"));
			return 0;
		}
		for (BuddyPlayer b : bots) {
			b.say("Пока!");
			BuddyManager.delete(server, b.getGameProfile().getName());
		}
		c.getSource().sendFeedback(() -> Text.literal("Убрано ботов: " + bots.size()), false);
		return bots.size();
	}

	private static int list(CommandContext<ServerCommandSource> c) {
		MinecraftServer server = c.getSource().getServer();
		BuddyState st = BuddyManager.state(server);
		if (st.bots.isEmpty()) {
			c.getSource().sendFeedback(() -> Text.literal("Ботов нет. /buddy spawn — позвать"), false);
			return 0;
		}
		for (BuddyState.Entry e : st.bots.values()) {
			BuddyPlayer b = BuddyManager.byName(server, e.name());
			ServerPlayerEntity owner = server.getPlayerManager().getPlayer(e.owner());
			String ownerName = owner != null ? owner.getGameProfile().getName() : e.owner().toString().substring(0, 8);
			String where = b == null ? "не в игре" : String.format(Locale.ROOT, "%s, %.0f %.0f %.0f, ❤ %.0f",
					modeName(b.getMode()), b.getX(), b.getY(), b.getZ(), b.getHealth());
			c.getSource().sendFeedback(() -> Text.literal("• " + e.name() + " (хозяин " + ownerName + "): " + where), false);
		}
		return st.bots.size();
	}

	/** Боты игрока: конкретный по имени или все его. */
	static List<BuddyPlayer> targets(ServerPlayerEntity p, @Nullable String name) {
		MinecraftServer server = p.getServer();
		List<BuddyPlayer> out = new ArrayList<>();
		if (server == null) return out;
		if (name != null) {
			BuddyPlayer b = BuddyManager.byName(server, name);
			if (b != null && (b.getOwner().equals(p.getUuid()) || p.hasPermissionLevel(2))) out.add(b);
		} else {
			out.addAll(BuddyManager.ownedBy(server, p.getUuid()));
		}
		return out;
	}

	private static String modeName(BuddyPlayer.Mode m) {
		return switch (m) {
			case FOLLOW -> "следует";
			case STAY -> "работает на месте";
			case COME -> "идёт к хозяину";
			case MINE -> "копает шахту";
			case CHOP -> "рубит лес";
			case UNLOAD -> "несёт добычу в сундук";
		};
	}

	// ================================================================ команды в чате

	private static final String[][] CHAT = {
			{"follow", "!следуй", "!за мной", "!иди за мной", "!follow"},
			{"stay", "!стой", "!стоп", "!жди", "!ферма", "!работай", "!stay", "!farm"},
			{"come", "!ко мне", "!сюда", "!иди сюда", "!come"},
			{"mine", "!шахта", "!копай", "!mine"},
			{"chop", "!лес", "!руби", "!chop"},
			{"store", "!склад", "!сундук", "!store"},
			{"bed", "!кровать", "!bed"},
			{"unload", "!разгрузись", "!выгрузи", "!unload"},
	};

	private static void onChat(ServerPlayerEntity sender, String raw) {
		String text = raw.trim();
		if (!text.startsWith("!")) return;
		String lower = text.toLowerCase(Locale.ROOT);
		for (String[] row : CHAT) {
			for (int i = 1; i < row.length; i++) {
				String cmd = row[i];
				if (!lower.equals(cmd) && !lower.startsWith(cmd + " ")) continue;
				String rest = text.substring(cmd.length()).trim();
				String action = row[0];
				String name = null;
				for (String part : rest.split("\\s+")) {
					if (part.isEmpty()) continue;
					if (action.equals("mine") && part.matches("-?\\d+")) action = "mine:" + part;
					else name = part;
				}
				runAction(sender, action, name, null);
				return;
			}
		}
	}
}
