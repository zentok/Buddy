package com.buddy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Настройки бота: файл config/buddy.json (создаётся сам при первом запуске).
 * Клавиша колеса команд настраивается в игре: Настройки → Управление → «Buddy».
 */
public class BuddyConfig {
	/** Следование: бот подходит к тебе на это расстояние... */
	public double followMin = 5.0;
	/** ...и стоит спокойно, пока ты не дальше этого. */
	public double followMax = 7.0;
	/** Дальше этого — телепорт к хозяину. */
	public double teleportDistance = 48.0;
	public boolean allowTeleport = true;

	/** Работа в режиме «стой»: радиус фермы вокруг места, где его поставили. */
	public int farmRadius = 10;
	/** Где искать сундук рядом, если склад не назначен. */
	public int chestSearchRadius = 16;

	/** Шахта: до какой высоты спускаться лесенкой. */
	public int mineTargetY = -54;
	/** Длина главного туннеля. */
	public int mainTunnelLength = 48;
	/** Длина боковых ответвлений. */
	public int branchLength = 12;
	/** Шаг между ответвлениями (блоки). */
	public int branchSpacing = 4;
	/** Ставить факел каждые N блоков (если темно и факелы есть). */
	public int torchInterval = 8;

	/** Лес: радиус поиска деревьев. */
	public int lumberRadius = 16;

	/** Ложиться спать, когда спит хозяин. */
	public boolean sleepWithOwner = true;
	/** Защищать хозяина и себя. */
	public boolean fight = true;

	private static BuddyConfig instance;

	public static BuddyConfig get() {
		if (instance == null) load();
		return instance;
	}

	public static void load() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("buddy.json");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		BuddyConfig cfg = null;
		if (Files.exists(file)) {
			try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
				cfg = gson.fromJson(r, BuddyConfig.class);
			} catch (Exception e) {
				Buddy.LOGGER.warn("Buddy: не удалось прочитать config/buddy.json, беру настройки по умолчанию", e);
			}
		}
		if (cfg == null) cfg = new BuddyConfig();
		if (cfg.followMax < cfg.followMin) cfg.followMax = cfg.followMin + 2;
		instance = cfg;
		try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
			gson.toJson(cfg, w);
		} catch (Exception e) {
			Buddy.LOGGER.warn("Buddy: не удалось записать config/buddy.json", e);
		}
	}
}
