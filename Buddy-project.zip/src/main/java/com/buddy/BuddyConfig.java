package com.buddy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Настройки бота: файл config/buddy.json (создаётся сам при первом запуске).
 * Клавиша колеса команд настраивается в игре: Настройки → Управление → «Buddy».
 */
public class BuddyConfig {
	/** Следование: бот подходит к тебе на это расстояние... */
	public double followMin = 5.0;
	/** ...и стоит спокойно, пока ты не дальше этого. */
	public double followMax = 7.0;
	/** Дальше этого — телепорт к хозяину. */
	public double teleportDistance = 48.0;
	public boolean allowTeleport = true;
	/** Как Baritone: если путь закрыт, копать природные блоки (землю, камень) — ступеньки из ямы, проходы. */
	public boolean pathDig = true;
	/** Подниматься столбом, ставя под себя блок (булыжник, землю), если иначе не выбраться. */
	public boolean pathPillar = true;

	/** Работа в режиме «стой»: радиус фермы вокруг места, где его поставили. */
	public int farmRadius = 10;
	/** Где искать сундук рядом, если склад не назначен. */
	public int chestSearchRadius = 16;

	/** Шахта: до какой высоты спускаться лесенкой. */
	public int mineTargetY = -54;
	/** Длина главного туннеля. */
	public int mainTunnelLength = 48;
	/** Длина боковых ответвлений. */
	public int branchLength = 12;
	/** Шаг между ответвлениями (блоки). */
	public int branchSpacing = 4;
	/** Ставить факел каждые N блоков (если темно и факелы есть). */
	public int torchInterval = 8;

	/** Лес: радиус поиска деревьев. */
	public int lumberRadius = 16;

	/** Ложиться спать, когда спит хозяин. */
	public boolean sleepWithOwner = true;
	/** Защищать хозяина и себя. */
	public boolean fight = true;

	/** ИИ-мозг. Выключен, пока не вписан ключ (или не выбрана локальная модель). */
	public Ai ai = new Ai();

	public static class Ai {
		/** Включить ИИ. */
		public boolean enabled = false;
		/**
		 * Кто думает за бота:
		 * "gigachat" — GigaChat от Сбера, БЕСПЛАТНО, работает из России без VPN, отлично понимает русский
		 *              (ключ: developers.sber.ru → GigaChat API → «Authorization key»);
		 * "gemini" — Google Gemini, бесплатно (из России не работает);
		 * "groq" — Groq, БЕСПЛАТНО (ключ: console.groq.com → API Keys);
		 * "openrouter" — бесплатные модели OpenRouter (мало запросов в день);
		 * "ollama" — своя модель на компьютере, бесплатно и без интернета;
		 * "claude" — Claude API (платно, самый умный); "openai" — любой другой OpenAI-совместимый сервер (свой openaiUrl).
		 */
		public String provider = "gigachat";
		/** Для GigaChat: GIGACHAT_API_PERS — физлица (бесплатный тариф), GIGACHAT_API_B2B / CORP — компании. */
		public String gigachatScope = "GIGACHAT_API_PERS";
		/** Ключ API Anthropic. Можно не писать сюда, а задать переменную окружения BUDDY_API_KEY. НИКОМУ НЕ ПОКАЗЫВАЙ. */
		public String apiKey = "";
		/** Модель. Пусто — подходящая по умолчанию для выбранного provider. */
		public String model = "";
		public String anthropicUrl = "https://api.anthropic.com";
		/** Адрес OpenAI-совместимого сервера (до /chat/completions). Пусто — по умолчанию для provider. */
		public String openaiUrl = "";
		public int maxTokens = 700;
		/** Сколько последних сообщений помнить в разговоре. */
		public int historyMessages = 16;
		/** Не тратить больше этого за сутки (в долларах). Для локальной модели не важно. */
		public double dailyBudgetUsd = 0.50;
		/** Цены модели за миллион токенов (для подсчёта трат). По умолчанию — Claude Haiku 5.5. */
		public double priceInputPerMTok = 0.10;
		public double priceOutputPerMTok = 0.50;
		/** Не чаще одного обращения в столько секунд и не больше стольких в час. */
		public double minSecondsBetweenCalls = 2.0;
		public int maxCallsPerHour = 150;
		/** Бот сам комментирует события (нашёл алмазы, напали, ночь). */
		public boolean proactive = true;
		public int proactiveCooldownSeconds = 90;
		/** Характер бота. */
		public String personality = "Дружелюбный, весёлый и немного хвастливый напарник. Любит шахты и порядок в сундуках. "
				+ "Отвечает коротко, по делу, иногда шутит. Обращается к хозяину на «ты».";

		public String apiKey() {
			String env = System.getenv("BUDDY_API_KEY");
			if (env != null && !env.isBlank()) return env.trim();
			return apiKey == null ? "" : apiKey.trim();
		}

		public boolean ready() {
			if (!enabled) return false;
			return isLocal() || !apiKey().isEmpty();
		}

		public String providerId() {
			return provider == null ? "gigachat" : provider.trim().toLowerCase(java.util.Locale.ROOT);
		}

		public boolean isClaude() {
			return providerId().equals("claude");
		}

		/** Платный ли провайдер (считаем траты только для Claude). */
		public boolean isPaid() {
			return isClaude();
		}

		public boolean isLocal() {
			return providerId().equals("ollama");
		}

		/** Модель с учётом значений по умолчанию. */
		public String model() {
			// старый конфиг мог оставить «claude-…» при другом провайдере — тогда берём модель по умолчанию
			if (model != null && !model.isBlank() && (isClaude() || !model.trim().startsWith("claude"))) return model.trim();
			return switch (providerId()) {
				case "claude" -> "claude-haiku-5-5";
				case "groq" -> "openai/gpt-oss-120b";
				case "gigachat" -> "GigaChat-2-Pro";
				case "openrouter" -> "openrouter/free";
				case "ollama" -> "qwen2.5:7b";
				default -> "gemini-2.5-flash";
			};
		}

		/** Адрес /chat/completions для OpenAI-совместимых провайдеров. */
		public String chatUrl() {
			boolean custom = (providerId().equals("openai") || providerId().equals("ollama")) && openaiUrl != null && !openaiUrl.isBlank();
			String base = custom ? openaiUrl.trim() : switch (providerId()) {
				case "groq" -> "https://api.groq.com/openai/v1";
				case "openrouter" -> "https://openrouter.ai/api/v1";
				case "ollama" -> "http://localhost:11434/v1";
				default -> "https://generativelanguage.googleapis.com/v1beta/openai";
			};
			if (base.endsWith("/")) base = base.substring(0, base.length() - 1);
			if (base.endsWith("/chat/completions")) return base;
			// старый формат для Ollama: http://localhost:11434 без /v1
			if (base.matches("https?://[^/]+") ) base = base + "/v1";
			return base + "/chat/completions";
		}
	}

	private static BuddyConfig instance;

	public static BuddyConfig get() {
		if (instance == null) load();
		return instance;
	}

	/** Сохранить текущие настройки в config/buddy.json. */
	public static void save() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("buddy.json");
		try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
			new GsonBuilder().setPrettyPrinting().create().toJson(get(), w);
		} catch (Exception e) {
			Buddy.LOGGER.warn("Buddy: не удалось записать config/buddy.json", e);
		}
	}

	public static void load() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("buddy.json");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		BuddyConfig cfg = null;
		if (Files.exists(file)) {
			try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
				cfg = gson.fromJson(r, BuddyConfig.class);
			} catch (Exception e) {
				Buddy.LOGGER.warn("Buddy: не удалось прочитать config/buddy.json, беру настройки по умолчанию", e);
			}
		}
		if (cfg == null) cfg = new BuddyConfig();
		if (cfg.followMax < cfg.followMin) cfg.followMax = cfg.followMin + 2;
		if (cfg.ai == null) cfg.ai = new Ai();
		instance = cfg;
		try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
			gson.toJson(cfg, w);
		} catch (Exception e) {
			Buddy.LOGGER.warn("Buddy: не удалось записать config/buddy.json", e);
		}
	}
}
