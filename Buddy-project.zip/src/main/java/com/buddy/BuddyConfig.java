package com.buddy;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Настройки бота: файл config/buddy.json (создаётся сам при первом запуске).
 * Клавиша колеса команд настраивается в игре: Настройки → Управление → «Buddy».
 */
public class BuddyConfig {
	/** Следование: бот подходит к тебе на это расстояние... */
	public double followMin = 5.0;
	/** ...и стоит спокойно, пока ты не дальше этого. */
	public double followMax = 7.0;
	/** Дальше этого — телепорт к хозяину. */
	public double teleportDistance = 48.0;
	public boolean allowTeleport = true;
	/** Как Baritone: если путь закрыт, копать природные блоки (землю, камень) — ступеньки из ямы, проходы. */
	public boolean pathDig = true;
	/** Подниматься столбом, ставя под себя блок (булыжник, землю), если иначе не выбраться. */
	public boolean pathPillar = true;

	/** Работа в режиме «стой»: радиус фермы вокруг места, где его поставили. */
	public int farmRadius = 10;
	/** Где искать сундук рядом, если склад не назначен. */
	public int chestSearchRadius = 16;

	/** Шахта: до какой высоты спускаться лесенкой. */
	public int mineTargetY = -54;
	/** Длина главного туннеля. */
	public int mainTunnelLength = 48;
	/** Длина боковых ответвлений. */
	public int branchLength = 12;
	/** Шаг между ответвлениями (блоки). */
	public int branchSpacing = 4;
	/** Ставить факел каждые N блоков (если темно и факелы есть). */
	public int torchInterval = 8;

	/** Лес: радиус поиска деревьев. */
	public int lumberRadius = 16;

	/** Ложиться спать, когда спит хозяин. */
	public boolean sleepWithOwner = true;
	/** Защищать хозяина и себя. */
	public boolean fight = true;

	/** ИИ-мозг. Выключен, пока не вписан ключ (или не выбрана локальная модель). */
	public Ai ai = new Ai();

	public static class Ai {
		/** Включить ИИ. */
		public boolean enabled = false;
		/** "claude" — Claude API; "ollama" / "openai" — локальная или любая OpenAI-совместимая модель. */
		public String provider = "claude";
		/** Ключ API Anthropic. Можно не писать сюда, а задать переменную окружения BUDDY_API_KEY. НИКОМУ НЕ ПОКАЗЫВАЙ. */
		public String apiKey = "";
		/** Модель: для Claude — "claude-haiku-5-5" (дёшево) или "claude-sonnet-5-5" (умнее); для Ollama — например "qwen2.5:7b". */
		public String model = "claude-haiku-5-5";
		public String anthropicUrl = "https://api.anthropic.com";
		/** Адрес локального сервера модели (Ollama по умолчанию). */
		public String openaiUrl = "http://localhost:11434";
		public int maxTokens = 700;
		/** Сколько последних сообщений помнить в разговоре. */
		public int historyMessages = 16;
		/** Не тратить больше этого за сутки (в долларах). Для локальной модели не важно. */
		public double dailyBudgetUsd = 0.50;
		/** Цены модели за миллион токенов (для подсчёта трат). По умолчанию — Claude Haiku 5.5. */
		public double priceInputPerMTok = 0.10;
		public double priceOutputPerMTok = 0.50;
		/** Не чаще одного обращения в столько секунд и не больше стольких в час. */
		public double minSecondsBetweenCalls = 2.0;
		public int maxCallsPerHour = 150;
		/** Бот сам комментирует события (нашёл алмазы, напали, ночь). */
		public boolean proactive = true;
		public int proactiveCooldownSeconds = 90;
		/** Характер бота. */
		public String personality = "Дружелюбный, весёлый и немного хвастливый напарник. Любит шахты и порядок в сундуках. "
				+ "Отвечает коротко, по делу, иногда шутит. Обращается к хозяину на «ты».";

		public String apiKey() {
			String env = System.getenv("BUDDY_API_KEY");
			if (env != null && !env.isBlank()) return env.trim();
			return apiKey == null ? "" : apiKey.trim();
		}

		public boolean ready() {
			if (!enabled) return false;
			return !provider.equalsIgnoreCase("claude") || !apiKey().isEmpty();
		}
	}

	private static BuddyConfig instance;

	public static BuddyConfig get() {
		if (instance == null) load();
		return instance;
	}

	/** Сохранить текущие настройки в config/buddy.json. */
	public static void save() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("buddy.json");
		try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
			new GsonBuilder().setPrettyPrinting().create().toJson(get(), w);
		} catch (Exception e) {
			Buddy.LOGGER.warn("Buddy: не удалось записать config/buddy.json", e);
		}
	}

	public static void load() {
		Path file = FabricLoader.getInstance().getConfigDir().resolve("buddy.json");
		Gson gson = new GsonBuilder().setPrettyPrinting().create();
		BuddyConfig cfg = null;
		if (Files.exists(file)) {
			try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
				cfg = gson.fromJson(r, BuddyConfig.class);
			} catch (Exception e) {
				Buddy.LOGGER.warn("Buddy: не удалось прочитать config/buddy.json, беру настройки по умолчанию", e);
			}
		}
		if (cfg == null) cfg = new BuddyConfig();
		if (cfg.followMax < cfg.followMin) cfg.followMax = cfg.followMin + 2;
		if (cfg.ai == null) cfg.ai = new Ai();
		instance = cfg;
		try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
			gson.toJson(cfg, w);
		} catch (Exception e) {
			Buddy.LOGGER.warn("Buddy: не удалось записать config/buddy.json", e);
		}
	}
}
