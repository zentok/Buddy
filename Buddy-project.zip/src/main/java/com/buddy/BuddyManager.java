package com.buddy;

import com.mojang.authlib.GameProfile;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Uuids;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.GameMode;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

/** Появление/уход ботов, сохранение списка, возрождение после смерти. */
public final class BuddyManager {
	public static final int MAX_PER_OWNER = 3;
	private static final Pattern NAME = Pattern.compile("[A-Za-z0-9_]{3,16}");
	/** Модельные слои скина (шапка, куртка, рукава, штанины) — все включены. */
	private static final byte ALL_SKIN_LAYERS = 0x7F;

	private static final Map<String, Integer> respawnTimers = new HashMap<>();
	private static final List<UUID> pendingOwnerJoins = new ArrayList<>();
	private static final List<UUID> pendingOwnerLeaves = new ArrayList<>();

	private BuddyManager() {
	}

	public static BuddyState state(MinecraftServer server) {
		return server.getOverworld().getPersistentStateManager().getOrCreate(BuddyState::fromNbt, BuddyState::new, "buddy");
	}

	public static List<BuddyPlayer> online(MinecraftServer server) {
		List<BuddyPlayer> out = new ArrayList<>();
		for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
			if (p instanceof BuddyPlayer b) out.add(b);
		}
		return out;
	}

	public static List<BuddyPlayer> ownedBy(MinecraftServer server, UUID owner) {
		List<BuddyPlayer> out = new ArrayList<>();
		for (BuddyPlayer b : online(server)) if (b.getOwner().equals(owner)) out.add(b);
		return out;
	}

	@Nullable
	public static BuddyPlayer byName(MinecraftServer server, String name) {
		ServerPlayerEntity p = server.getPlayerManager().getPlayer(name);
		return p instanceof BuddyPlayer b ? b : null;
	}

	// ------------------------------------------------------------------ команды

	/** Создать нового бота рядом с игроком. Возвращает текст ошибки или null. */
	@Nullable
	public static String create(ServerPlayerEntity owner, String name) {
		MinecraftServer server = owner.getServer();
		if (server == null) return "Сервер недоступен";
		if (!NAME.matcher(name).matches()) return "Имя: 3–16 латинских букв, цифр или _";
		BuddyState st = state(server);
		String key = name.toLowerCase(Locale.ROOT);
		BuddyState.Entry existing = st.bots.get(key);
		if (existing != null && !existing.owner().equals(owner.getUuid())) return "Бот " + name + " уже есть у другого игрока";
		ServerPlayerEntity online = server.getPlayerManager().getPlayer(name);
		if (online != null && !(online instanceof BuddyPlayer)) return "Игрок с таким именем сейчас в игре";
		if (online instanceof BuddyPlayer b) {
			b.teleportNear(owner);
			return null;
		}
		long mine = st.bots.values().stream().filter(e -> e.owner().equals(owner.getUuid())).count();
		if (existing == null && mine >= MAX_PER_OWNER) return "Можно не больше " + MAX_PER_OWNER + " ботов на игрока";
		st.bots.put(key, new BuddyState.Entry(name, owner.getUuid(), existing != null ? existing.mode() : "FOLLOW"));
		st.markDirty();
		BuddyPlayer bot = spawn(server, st.bots.get(key));
		if (bot == null) return "Не получилось впустить бота, смотри лог";
		bot.teleportNear(owner);
		bot.say("Привет! Я с тобой. Команды: колесо на G или ПКМ по мне; в чат: !следуй !стой !ко мне !шахта !лес !склад !кровать !разгрузись");
		return null;
	}

	/** Убрать бота насовсем (вещи и прогресс сохраняются в файле игрока, вернуть можно /buddy spawn). */
	public static boolean delete(MinecraftServer server, String name) {
		BuddyState st = state(server);
		boolean had = st.bots.remove(name.toLowerCase(Locale.ROOT)) != null;
		st.markDirty();
		BuddyPlayer b = byName(server, name);
		if (b != null) despawn(b);
		return had || b != null;
	}

	public static void saveMode(BuddyPlayer bot) {
		MinecraftServer server = bot.getServer();
		if (server == null) return;
		BuddyState st = state(server);
		String key = bot.getGameProfile().getName().toLowerCase(Locale.ROOT);
		BuddyState.Entry e = st.bots.get(key);
		if (e != null) {
			st.bots.put(key, new BuddyState.Entry(e.name(), e.owner(), bot.getMode().name()));
			st.markDirty();
		}
	}

	// ------------------------------------------------------------------ вход/выход

	@Nullable
	static BuddyPlayer spawn(MinecraftServer server, BuddyState.Entry entry) {
		if (server.getPlayerManager().getPlayer(entry.name()) != null) return null;
		try {
			GameProfile profile = new GameProfile(Uuids.getOfflinePlayerUuid(entry.name()), entry.name());
			ServerWorld world = server.getOverworld();
			BuddyPlayer bot = new BuddyPlayer(server, world, profile, entry.owner());
			server.getPlayerManager().onPlayerConnect(new FakeConnection(), bot);
			bot.getDataTracker().set(BuddyPlayer.modelPartsKey(), ALL_SKIN_LAYERS);
			bot.changeGameMode(GameMode.SURVIVAL);
			if (bot.getHealth() <= 0 || bot.isDead()) {
				bot.reviveIfDead();
				ServerPlayerEntity owner = server.getPlayerManager().getPlayer(entry.owner());
				if (owner != null && !(owner instanceof BuddyPlayer)) bot.teleportNear(owner);
				else {
					BlockPos sp = server.getOverworld().getSpawnPos();
					bot.teleport(server.getOverworld(), sp.getX() + 0.5, sp.getY(), sp.getZ() + 0.5, 0, 0);
				}
			}
			BuddyNet.syncAll(server);
			return bot;
		} catch (Exception e) {
			Buddy.LOGGER.error("Buddy: не удалось впустить бота {}", entry.name(), e);
			return null;
		}
	}

	static void despawn(BuddyPlayer bot) {
		MinecraftServer server = bot.getServer();
		bot.networkHandler.disconnect(Text.literal("Buddy ушёл"));
		if (server != null) BuddyNet.syncAll(server);
	}

	static void scheduleRespawn(BuddyPlayer bot) {
		respawnTimers.put(bot.getGameProfile().getName(), 60);
		bot.say("Меня убили... Вернусь через пару секунд.");
	}

	static void onPlayerJoin(ServerPlayerEntity p) {
		if (p instanceof BuddyPlayer) return;
		pendingOwnerJoins.add(p.getUuid());
	}

	static void onPlayerLeave(ServerPlayerEntity p) {
		if (p instanceof BuddyPlayer) return;
		pendingOwnerLeaves.add(p.getUuid());
	}

	static void tick(MinecraftServer server) {
		// хозяин зашёл — его боты заходят следом
		if (!pendingOwnerJoins.isEmpty()) {
			List<UUID> joins = new ArrayList<>(pendingOwnerJoins);
			pendingOwnerJoins.clear();
			BuddyState st = state(server);
			for (UUID owner : joins) {
				if (server.getPlayerManager().getPlayer(owner) == null) continue;
				for (BuddyState.Entry e : st.bots.values()) {
					if (e.owner().equals(owner) && server.getPlayerManager().getPlayer(e.name()) == null) spawn(server, e);
				}
			}
			BuddyNet.syncAll(server);
		}
		// хозяин вышел — его боты уходят (сохраняются и не держат чанки загруженными)
		if (!pendingOwnerLeaves.isEmpty()) {
			List<UUID> leaves = new ArrayList<>(pendingOwnerLeaves);
			pendingOwnerLeaves.clear();
			for (UUID owner : leaves) {
				if (server.getPlayerManager().getPlayer(owner) != null) continue;
				for (BuddyPlayer b : ownedBy(server, owner)) despawn(b);
			}
		}
		// возрождение после смерти: переподключаем бота
		if (!respawnTimers.isEmpty()) {
			Iterator<Map.Entry<String, Integer>> it = respawnTimers.entrySet().iterator();
			List<String> ready = new ArrayList<>();
			while (it.hasNext()) {
				Map.Entry<String, Integer> e = it.next();
				int t = e.getValue() - 1;
				if (t <= 0) {
					ready.add(e.getKey());
					it.remove();
				} else e.setValue(t);
			}
			BuddyState st = state(server);
			for (String name : ready) {
				ServerPlayerEntity old = server.getPlayerManager().getPlayer(name);
				if (old instanceof BuddyPlayer b) despawn(b);
				BuddyState.Entry e = st.bots.get(name.toLowerCase(Locale.ROOT));
				if (e == null) continue;
				ServerPlayerEntity owner = server.getPlayerManager().getPlayer(e.owner());
				if (owner == null || owner instanceof BuddyPlayer) continue;
				BuddyPlayer bot = spawn(server, e);
				if (bot != null) bot.say("Я вернулся!");
			}
		}
	}
}
