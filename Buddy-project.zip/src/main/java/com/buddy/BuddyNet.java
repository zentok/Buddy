package com.buddy;

import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/** Пакеты: колесо команд (клиент → сервер) и список своих ботов (сервер → клиент). */
public final class BuddyNet {
	public static final Identifier COMMAND = new Identifier(Buddy.MOD_ID, "command");
	public static final Identifier BOTS = new Identifier(Buddy.MOD_ID, "bots");

	private BuddyNet() {
	}

	public static void registerServer() {
		ServerPlayNetworking.registerGlobalReceiver(COMMAND, (server, player, handler, buf, sender) -> {
			String action = buf.readString(32);
			String target = buf.readString(16);
			BlockPos pos = buf.readBoolean() ? buf.readBlockPos() : null;
			server.execute(() -> Buddy.runAction(player, action, target.isEmpty() ? null : target, pos));
		});
	}

	/** Отправить каждому игроку имена его ботов (чтобы ПКМ по боту открывал колесо). */
	public static void syncAll(MinecraftServer server) {
		for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
			if (p instanceof BuddyPlayer || !ServerPlayNetworking.canSend(p, BOTS)) continue;
			List<BuddyPlayer> mine = BuddyManager.ownedBy(server, p.getUuid());
			PacketByteBuf buf = PacketByteBufs.create();
			buf.writeVarInt(mine.size());
			for (BuddyPlayer b : mine) buf.writeString(b.getGameProfile().getName());
			ServerPlayNetworking.send(p, BOTS, buf);
		}
	}

	/** Блок, на который смотрит игрок (до 6 блоков), или null. */
	@Nullable
	public static BlockPos lookedAt(ServerPlayerEntity p) {
		HitResult hit = p.raycast(6.0, 0f, false);
		if (hit instanceof BlockHitResult bh && hit.getType() == HitResult.Type.BLOCK) return bh.getBlockPos();
		return null;
	}

	public static boolean isContainer(ServerWorld w, BlockPos p) {
		BlockEntity be = w.getBlockEntity(p);
		return be != null && com.buddy.ai.Storekeeper.isStorage(w, p);
	}
}
