package com.buddy;

import com.buddy.ai.PathFinder;
import com.buddy.ai.Walker;
import com.mojang.authlib.GameProfile;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.item.FoodComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

import java.util.UUID;

/**
 * Бот — настоящий игрок на сервере, только без человека: сервер сам «нажимает клавиши».
 * Здесь его «мозг»: режимы следуй / стой / ко мне, еда, телепорт к хозяину.
 */
public class BuddyPlayer extends ServerPlayerEntity {
	public enum Mode {
		FOLLOW, STAY, COME;

		public static Mode parse(String s) {
			try {
				return valueOf(s);
			} catch (Exception e) {
				return FOLLOW;
			}
		}
	}

	private final UUID owner;
	private Mode mode = Mode.FOLLOW;
	private final Walker walker = new Walker(this);
	private int eatCooldown;
	private int hungryWarnCooldown;
	private int stuckWarnCooldown;
	private boolean loggedTickError;

	public BuddyPlayer(MinecraftServer server, ServerWorld world, GameProfile profile, UUID owner) {
		super(server, world, profile);
		this.owner = owner;
	}

	public UUID getOwner() {
		return owner;
	}

	public Mode getMode() {
		return mode;
	}

	/** Режим без сохранения (при загрузке). */
	void setModeSilently(Mode mode) {
		this.mode = mode;
	}

	/** Ключ данных «какие слои скина показывать» (защищённое поле PlayerEntity). */
	static net.minecraft.entity.data.TrackedData<Byte> modelPartsKey() {
		return PLAYER_MODEL_PARTS;
	}

	public void setMode(Mode mode) {
		this.mode = mode;
		walker.reset();
		BuddyManager.saveMode(this);
	}

	@Nullable
	public ServerPlayerEntity getOwnerPlayer() {
		ServerPlayerEntity p = getServer().getPlayerManager().getPlayer(owner);
		return p instanceof BuddyPlayer ? null : p;
	}

	/** Сказать в общий чат от имени бота. */
	public void say(String text) {
		getServer().getPlayerManager().broadcast(Text.literal("<" + getGameProfile().getName() + "> " + text), false);
	}

	// ================================================================ тик

	@Override
	public void tick() {
		if (getServer().getTicks() % 10 == 0) networkHandler.syncWithPlayerPosition();
		getServerWorld().getChunkManager().updatePosition(this);
		if (!isDead() && !isRemoved()) brainTick();
		try {
			super.tick();
			playerTick();
		} catch (NullPointerException e) {
			// некоторые моды ждут у игрока настоящее соединение; один раз пишем в лог и живём дальше
			if (!loggedTickError) {
				Buddy.LOGGER.warn("Buddy: ошибка в тике бота (продолжаю работу)", e);
				loggedTickError = true;
			}
		}
	}

	private void brainTick() {
		tickEat();
		ServerPlayerEntity ownerP = getOwnerPlayer();
		switch (mode) {
			case STAY -> {
				walker.stop();
				floatInWater();
				if (ownerP != null && ownerP.getWorld() == getWorld() && distanceTo(ownerP) < 8) lookAt(ownerP);
			}
			case FOLLOW -> follow(ownerP, false);
			case COME -> {
				if (follow(ownerP, true)) {
					mode = Mode.STAY;
					BuddyManager.saveMode(this);
					say("Я тут!");
				}
			}
		}
	}

	private void floatInWater() {
		if (isTouchingWater() && getFluidHeight(net.minecraft.registry.tag.FluidTags.WATER) > 0.4) setJumping(true);
	}

	/** Идти за хозяином. true — дошёл. */
	private boolean follow(@Nullable ServerPlayerEntity ownerP, boolean come) {
		if (ownerP == null) {
			walker.stop();
			floatInWater();
			return false;
		}
		if (ownerP.getWorld() != getWorld() || distanceTo(ownerP) > 48) {
			teleportNear(ownerP);
			return false;
		}
		double dist = distanceTo(ownerP);
		double reach = come ? 2.0 : 3.0;
		if (dist <= reach && Math.abs(ownerP.getY() - getY()) < 2.5) {
			walker.stop();
			floatInWater();
			lookAt(ownerP);
			return true;
		}
		boolean arrived = walker.moveTo(ownerP.getBlockPos(), reach, dist > 6);
		if ((walker.isStuck() && dist > 6) || (walker.failedSearches() >= 3 && dist > 12)) {
			if (stuckWarnCooldown <= 0) {
				say("Застрял, догоняю телепортом");
				stuckWarnCooldown = 600;
			}
			teleportNear(ownerP);
		}
		if (stuckWarnCooldown > 0) stuckWarnCooldown--;
		return arrived;
	}

	private void lookAt(ServerPlayerEntity target) {
		double dx = target.getX() - getX();
		double dz = target.getZ() - getZ();
		double dy = target.getEyeY() - getEyeY();
		float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
		float pitch = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));
		setYaw(yaw);
		setHeadYaw(yaw);
		setPitch(MathHelper.clamp(pitch, -60, 60));
	}

	/** Телепорт на свободное место рядом с хозяином. */
	public void teleportNear(ServerPlayerEntity target) {
		ServerWorld world = target.getServerWorld();
		PathFinder pf = new PathFinder(world);
		BlockPos base = target.getBlockPos();
		BlockPos spot = null;
		search:
		for (int r = 2; r <= 3; r++) {
			for (int dx = -r; dx <= r; dx++) {
				for (int dz = -r; dz <= r; dz++) {
					if (Math.abs(dx) != r && Math.abs(dz) != r) continue;
					for (int dy = 1; dy >= -2; dy--) {
						BlockPos p = base.add(dx, dy, dz);
						if (pf.standable(p)) {
							spot = p;
							break search;
						}
					}
				}
			}
		}
		Vec3d to = spot != null ? Vec3d.ofBottomCenter(spot) : target.getPos();
		teleport(world, to.x, to.y, to.z, target.getYaw(), 0);
		fallDistance = 0;
		walker.reset();
	}

	// ================================================================ еда

	private void tickEat() {
		if (isUsingItem()) return;
		if (eatCooldown > 0) {
			eatCooldown--;
			return;
		}
		if (hungryWarnCooldown > 0) hungryWarnCooldown--;
		HungerManager hm = getHungerManager();
		int food = hm.getFoodLevel();
		boolean need = food <= 14 || (getHealth() < getMaxHealth() && food <= 17);
		if (!need) return;
		int slot = findFood();
		if (slot < 0) {
			if (food <= 6 && hungryWarnCooldown <= 0) {
				say("Я голодный — дай мне поесть (брось еду рядом)");
				hungryWarnCooldown = 1200;
			}
			return;
		}
		var inv = getInventory();
		if (slot >= 9) {
			ItemStack moved = inv.main.get(slot);
			inv.main.set(slot, inv.main.get(8));
			inv.main.set(8, moved);
			slot = 8;
		}
		inv.selectedSlot = slot;
		ItemStack stack = inv.main.get(slot);
		interactionManager.interactItem(this, getWorld(), stack, Hand.MAIN_HAND);
		eatCooldown = 40;
	}

	private int findFood() {
		var main = getInventory().main;
		int best = -1;
		int bestHunger = -1;
		for (int i = 0; i < main.size(); i++) {
			ItemStack s = main.get(i);
			if (s.isEmpty() || !s.isFood()) continue;
			FoodComponent fc = s.getItem().getFoodComponent();
			if (fc == null || !fc.getStatusEffects().isEmpty()) continue; // не ест гнилое, паучьи глаза и золотые яблоки
			if (fc.getHunger() > bestHunger) {
				best = i;
				bestHunger = fc.getHunger();
			}
		}
		return best;
	}

	// ================================================================ смерть

	@Override
	public void onDeath(DamageSource source) {
		super.onDeath(source);
		BuddyManager.scheduleRespawn(this);
	}

	/** После загрузки «мёртвым» (умер и переподключился) — оживить. */
	public void reviveIfDead() {
		if (getHealth() > 0 && !isDead()) return;
		setHealth(getMaxHealth());
		deathTime = 0;
		getHungerManager().setFoodLevel(20);
		getHungerManager().setSaturationLevel(5f);
		clearStatusEffects();
		setFireTicks(0);
		setAir(getMaxAir());
		fallDistance = 0;
	}
}
