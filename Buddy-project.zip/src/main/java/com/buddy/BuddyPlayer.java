package com.buddy;

import com.buddy.ai.Combat;
import com.buddy.ai.FarmJob;
import com.buddy.ai.Hands;
import com.buddy.ai.Inv;
import com.buddy.ai.LumberJob;
import com.buddy.ai.MineJob;
import com.buddy.ai.PathFinder;
import com.buddy.ai.Storekeeper;
import com.buddy.ai.Walker;
import com.mojang.authlib.GameProfile;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.BedPart;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.player.HungerManager;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Бот — настоящий игрок на сервере, только без человека: сервер сам «нажимает клавиши».
 * Здесь его «мозг»: режимы, бой, еда, сон, работа (ферма, шахта, лес), склад.
 */
public class BuddyPlayer extends ServerPlayerEntity {
	public enum Mode {
		/** Ходит за хозяином на расстоянии 5–7 блоков. */
		FOLLOW,
		/** Стоит на месте и работает рядом: ферма, сундук. */
		STAY,
		/** Подойти вплотную, потом «стой». */
		COME,
		/** Шахта. */
		MINE,
		/** Лес. */
		CHOP,
		/** Отнести добычу в сундук и вернуться к прежнему делу. */
		UNLOAD,
		/** Задача от ИИ или команды: крафт, печь, добыть N, дойти, отдать, сундук. */
		TASK;

		public static Mode parse(String s) {
			try {
				return valueOf(s);
			} catch (Exception e) {
				return FOLLOW;
			}
		}
	}

	private final UUID owner;
	private Mode mode = Mode.FOLLOW;
	private Mode modeBeforeUnload = Mode.STAY;
	private final Walker walker = new Walker(this);
	private final Hands hands = new Hands(this);
	private final Storekeeper store = new Storekeeper(this, walker);
	private final Combat combat = new Combat(this, walker, hands);

	@Nullable
	private BlockPos anchor;
	@Nullable
	private BlockPos storagePos;
	@Nullable
	private BlockPos bedPos;
	private int mineTargetY = Integer.MIN_VALUE;
	private Direction mineDir = Direction.NORTH;

	@Nullable
	private FarmJob farm;
	@Nullable
	private MineJob mine;
	@Nullable
	private LumberJob lumber;
	@Nullable
	private com.buddy.task.Task task;
	private Mode modeBeforeTask = Mode.FOLLOW;
	private final com.buddy.brain.Brain brain = new com.buddy.brain.Brain(this);
	private long lastHurtEventMs;
	private int valuableCount = -1;
	private boolean wasNight;

	private boolean following; // гистерезис 5–7 блоков
	private int eatCooldown;
	private int stuckWarnCooldown;
	private int sleepTicks;
	private boolean loggedTickError;
	private final Map<String, Integer> saidAt = new HashMap<>();

	public BuddyPlayer(MinecraftServer server, ServerWorld world, GameProfile profile, UUID owner) {
		super(server, world, profile);
		this.owner = owner;
	}

	// ================================================================ свойства

	public UUID getOwner() {
		return owner;
	}

	public Mode getMode() {
		return mode;
	}

	@Nullable
	public BlockPos getStoragePos() {
		return storagePos;
	}

	public void setStoragePos(@Nullable BlockPos p) {
		storagePos = p == null ? null : p.toImmutable();
	}

	public void setBedPos(@Nullable BlockPos p) {
		bedPos = p == null ? null : p.toImmutable();
	}

	public void setMineTargetY(int y) {
		mineTargetY = y;
	}

	/** Режим без сообщений (при загрузке). */
	void setModeSilently(Mode m) {
		mode = m;
		resetJobs();
	}

	/** Ключ данных «какие слои скина показывать» (защищённое поле PlayerEntity). */
	static net.minecraft.entity.data.TrackedData<Byte> modelPartsKey() {
		return PLAYER_MODEL_PARTS;
	}

	public Hands hands() {
		return hands;
	}

	public com.buddy.brain.Brain brain() {
		return brain;
	}

	public void setMode(Mode m) {
		if (task != null) {
			task.cancel();
			task = null;
		}
		if (m == Mode.UNLOAD && mode != Mode.UNLOAD) modeBeforeUnload = mode == Mode.TASK ? modeBeforeTask : mode;
		mode = m;
		walker.reset();
		hands.cancel();
		combat.clear();
		if (m == Mode.STAY || m == Mode.COME) anchor = null;
		if (m == Mode.MINE) {
			ServerPlayerEntity o = getOwnerPlayer();
			mineDir = o != null ? o.getHorizontalFacing() : getHorizontalFacing();
		}
		resetJobs();
		if (isSleeping()) wakeUp(false, true);
		BuddyManager.saveMode(this);
	}

	private void resetJobs() {
		farm = null;
		mine = null;
		lumber = null;
	}

	@Nullable
	public ServerPlayerEntity getOwnerPlayer() {
		ServerPlayerEntity p = getServer().getPlayerManager().getPlayer(owner);
		return p instanceof BuddyPlayer ? null : p;
	}

	/** Сказать в общий чат от имени бота. */
	public void say(String text) {
		getServer().getPlayerManager().broadcast(Text.literal("<" + getGameProfile().getName() + "> " + text), false);
	}

	/** Сказать, но не чаще раза в cooldown тиков для одной темы. */
	public void sayOnce(String key, String text, int cooldown) {
		int now = getServer().getTicks();
		Integer last = saidAt.get(key);
		if (last != null && now - last < cooldown) return;
		saidAt.put(key, now);
		say(text);
	}

	// ================================================================ тик

	@Override
	public void tick() {
		if (getServer().getTicks() % 10 == 0) networkHandler.syncWithPlayerPosition();
		getServerWorld().getChunkManager().updatePosition(this);
		if (!isDead() && !isRemoved()) {
			try {
				brain.tick();
				senses();
				brainTick();
			} catch (RuntimeException e) {
				if (!loggedTickError) {
					Buddy.LOGGER.warn("Buddy: ошибка в «мозге» бота (продолжаю работу)", e);
					loggedTickError = true;
				}
				walker.stop();
			}
		}
		try {
			super.tick();
			playerTick();
		} catch (NullPointerException e) {
			// некоторые моды ждут у игрока настоящее соединение; один раз пишем в лог и живём дальше
			if (!loggedTickError) {
				Buddy.LOGGER.warn("Buddy: ошибка в тике бота (продолжаю работу)", e);
				loggedTickError = true;
			}
		}
	}

	private void brainTick() {
		ServerPlayerEntity ownerP = getOwnerPlayer();
		if (isSleeping()) {
			walker.stop();
			sleepTick(ownerP);
			return;
		}
		tickEat();
		if (isUsingItem()) { // ест — не дёргаем руки, иначе еда прервётся
			walker.stop();
			return;
		}
		if (wantsSleep(ownerP)) {
			goSleep(ownerP);
			return;
		}
		if (combat.tick(ownerP)) return;
		if (anchor == null) anchor = getBlockPos();
		switch (mode) {
			case FOLLOW -> follow(ownerP);
			case COME -> {
				if (come(ownerP)) {
					setMode(Mode.STAY);
					say("Я тут! Побуду рядом и займусь делами.");
				}
			}
			case STAY -> {
				if (farm == null || !farm.anchor().equals(anchor)) farm = new FarmJob(this, walker, hands, store, anchor);
				farm.tick();
				floatInWater();
			}
			case MINE -> {
				if (mine == null) {
					int y = mineTargetY != Integer.MIN_VALUE ? mineTargetY : BuddyConfig.get().mineTargetY;
					y = Math.max(y, getServerWorld().getBottomY() + 5);
					mine = new MineJob(this, walker, hands, store, mineDir, y);
					say("Иду копать шахту: лесенкой вниз до высоты " + y + ", потом туннели. Руду беру только ту, что вижу.");
				}
				if (!mine.tick()) {
					anchor = getBlockPos();
					setMode(Mode.STAY);
					brain.onEvent("Шахта закончена, я стою у входа. В инвентаре теперь то, что накопал.", true);
				}
			}
			case CHOP -> {
				if (lumber == null) {
					lumber = new LumberJob(this, walker, hands, store, getBlockPos());
					say("Иду рубить лес.");
				}
				if (!lumber.tick()) {
					anchor = getBlockPos();
					setMode(Mode.STAY);
					brain.onEvent("Рубка леса закончена (деревья рядом кончились).", true);
				}
			}
			case UNLOAD -> {
				if (!store.unload(anchor != null ? anchor : getBlockPos())) {
					if (!com.buddy.brain.Brain.active()) say("Готово, всё в сундуке.");
					Mode back = modeBeforeUnload == Mode.UNLOAD || modeBeforeUnload == Mode.TASK ? Mode.STAY : modeBeforeUnload;
					setMode(back);
					brain.onEvent("Добычу отнёс в сундук.", true);
				}
			}
			case TASK -> tickTask();
		}
	}

	private void floatInWater() {
		if (isTouchingWater() && getFluidHeight(net.minecraft.registry.tag.FluidTags.WATER) > 0.4) setJumping(true);
	}

	// ================================================================ задачи (для ИИ и команд)

	/** Команда режима (от ИИ). */
	public void command(String what) {
		switch (what) {
			case "follow" -> setMode(Mode.FOLLOW);
			case "stay" -> setMode(Mode.STAY);
			case "come" -> setMode(Mode.COME);
			case "mine" -> setMode(Mode.MINE);
			case "chop" -> setMode(Mode.CHOP);
			case "unload" -> setMode(Mode.UNLOAD);
			default -> {
			}
		}
	}

	private String begin(com.buddy.task.Task t) {
		Mode prev = mode == Mode.TASK ? modeBeforeTask : mode;
		setMode(Mode.TASK);
		modeBeforeTask = prev == Mode.COME || prev == Mode.UNLOAD ? Mode.FOLLOW : prev;
		task = t;
		return t.describe();
	}

	public String startTask(String kind, net.minecraft.item.Item item, int count) {
		return begin(switch (kind) {
			case "craft" -> new com.buddy.task.CraftTask(this, walker, hands, item, count);
			case "smelt" -> new com.buddy.task.SmeltTask(this, walker, hands, item, count);
			default -> new com.buddy.task.CollectTask(this, walker, hands, store, item, count);
		});
	}

	public String startGive(@Nullable net.minecraft.item.Item item, int count) {
		return begin(new com.buddy.task.GiveTask(this, walker, hands, item, count));
	}

	public String startChest(boolean take, @Nullable net.minecraft.item.Item item, int count) {
		return begin(new com.buddy.task.ChestTask(this, walker, hands, store, take, item, count));
	}

	public String startGoto(BlockPos p, String label) {
		return begin(new com.buddy.task.GotoTask(this, walker, p, label));
	}

	private void tickTask() {
		if (task == null) {
			setMode(modeBeforeTask);
			return;
		}
		com.buddy.task.Task.Status st = task.tick();
		if (st == com.buddy.task.Task.Status.RUNNING) return;
		com.buddy.task.Task done = task;
		task = null;
		walker.stop();
		hands.cancel();
		Mode back = modeBeforeTask;
		if (back == Mode.STAY || back == Mode.MINE || back == Mode.CHOP) {
			back = Mode.STAY;
			anchor = getBlockPos();
		}
		setMode(back);
		String text = "Задача «" + done.describe() + "»: " + (st == com.buddy.task.Task.Status.DONE ? "выполнено" : "НЕ получилось")
				+ " — " + done.result();
		if (com.buddy.brain.Brain.active()) brain.onEvent(text, true);
		else say((st == com.buddy.task.Task.Status.DONE ? "Готово: " : "Не вышло: ") + done.result());
	}

	/** Что бот сейчас делает — для ИИ и /buddy list. */
	public String activityText() {
		return switch (mode) {
			case FOLLOW -> "иду за хозяином";
			case STAY -> "стою на месте" + (anchor != null ? " (" + anchor.toShortString() + ")" : "") + ", присматриваю за фермой";
			case COME -> "иду к хозяину";
			case MINE -> "копаю шахту";
			case CHOP -> "рублю лес";
			case UNLOAD -> "несу добычу в сундук";
			case TASK -> task != null ? "задача: " + task.describe() : "задача";
		};
	}

	/** Мелкие наблюдения для ИИ: напали, нашёл ценное, наступила ночь. */
	private void senses() {
		if (getServer().getTicks() % 40 != 0) return;
		int v = Inv.count(this, s -> s.isOf(net.minecraft.item.Items.DIAMOND) || s.isOf(net.minecraft.item.Items.EMERALD)
				|| s.isOf(net.minecraft.item.Items.ANCIENT_DEBRIS) || s.isOf(net.minecraft.item.Items.DIAMOND_ORE)
				|| s.isOf(net.minecraft.item.Items.DEEPSLATE_DIAMOND_ORE));
		if (valuableCount >= 0 && v > valuableCount) brain.onEvent("Я только что добыл что-то ценное (алмазы/изумруды)! Теперь их " + v + ".", false);
		valuableCount = v;
		boolean night = getServerWorld().isNight();
		if (night && !wasNight) brain.onEvent("Наступает ночь.", false);
		wasNight = night;
		if (getHealth() <= 6 && getServer().getTicks() % 400 == 0) brain.onEvent("У меня мало здоровья: " + (int) getHealth() + "/20.", false);
	}

	@Override
	public boolean damage(DamageSource source, float amount) {
		boolean hurt = super.damage(source, amount);
		if (hurt && source.getAttacker() != null && System.currentTimeMillis() - lastHurtEventMs > 30_000) {
			lastHurtEventMs = System.currentTimeMillis();
			String who = source.getAttacker() instanceof ServerPlayerEntity sp ? "игрок " + sp.getGameProfile().getName()
					: net.minecraft.registry.Registries.ENTITY_TYPE.getId(source.getAttacker().getType()).getPath();
			brain.onEvent("На меня напал " + who + ".", false);
		}
		return hurt;
	}

	// ================================================================ следование (5–7 блоков)

	private void follow(@Nullable ServerPlayerEntity ownerP) {
		BuddyConfig cfg = BuddyConfig.get();
		if (ownerP == null) {
			walker.stop();
			floatInWater();
			return;
		}
		if (ownerP.getWorld() != getWorld() || distanceTo(ownerP) > cfg.teleportDistance) {
			if (cfg.allowTeleport) teleportNear(ownerP, cfg.followMin);
			return;
		}
		if (ownerP.hasVehicle() || ownerP.isFallFlying()) {
			// хозяин в транспорте/летит — просто держимся рядом, далеко — телепорт
			following = true;
		}
		double dist = distanceTo(ownerP);
		boolean sameLevel = Math.abs(ownerP.getY() - getY()) < 3;
		if (!following && (dist > cfg.followMax || !sameLevel)) following = true;
		if (following && dist <= cfg.followMin && sameLevel) following = false;
		if (!following) {
			walker.stop();
			floatInWater();
			if (!pickupNearbyFood()) lookAt(ownerP);
			return;
		}
		walker.moveTo(ownerP.getBlockPos(), cfg.followMin, dist > 10);
		if ((walker.isStuck() && dist > 8) || (walker.failedSearches() >= 3 && dist > 14)) {
			if (cfg.allowTeleport) {
				if (stuckWarnCooldown <= 0) {
					say("Застрял, догоняю телепортом");
					stuckWarnCooldown = 600;
				}
				teleportNear(ownerP, cfg.followMin);
			}
		}
		if (stuckWarnCooldown > 0) stuckWarnCooldown--;
	}

	private boolean come(@Nullable ServerPlayerEntity ownerP) {
		if (ownerP == null) return true;
		if (ownerP.getWorld() != getWorld() || distanceTo(ownerP) > BuddyConfig.get().teleportDistance) {
			teleportNear(ownerP, 2);
			return false;
		}
		if (distanceTo(ownerP) <= 2.5 && Math.abs(ownerP.getY() - getY()) < 2) {
			walker.stop();
			lookAt(ownerP);
			return true;
		}
		walker.moveTo(ownerP.getBlockPos(), 2.0, true);
		if (walker.isStuck() || walker.failedSearches() >= 3) teleportNear(ownerP, 2);
		return false;
	}

	/** Подобрать брошенную рядом еду (хозяин кормит бота). */
	private boolean pickupNearbyFood() {
		Box area = getBoundingBox().expand(8, 2, 8);
		for (ItemEntity e : getWorld().getEntitiesByClass(ItemEntity.class, area, e -> !e.cannotPickup() && Inv.isFood(e.getStack()))) {
			walker.approach(e.getPos(), 0.5);
			return true;
		}
		return false;
	}

	private void lookAt(ServerPlayerEntity target) {
		hands.lookAt(target.getEyePos());
		setPitch(MathHelper.clamp(getPitch(), -60, 60));
	}

	/** Телепорт на свободное место рядом с хозяином (примерно на расстоянии ring блоков). */
	public void teleportNear(ServerPlayerEntity target, double ring) {
		ServerWorld world = target.getServerWorld();
		PathFinder pf = new PathFinder(world);
		BlockPos base = target.getBlockPos();
		BlockPos spot = null;
		int r0 = Math.max(2, (int) Math.round(ring) - 1);
		search:
		for (int r = r0; r >= 1; r--) {
			for (int dx = -r; dx <= r; dx++) {
				for (int dz = -r; dz <= r; dz++) {
					if (Math.abs(dx) != r && Math.abs(dz) != r) continue;
					for (int dy = 1; dy >= -3; dy--) {
						BlockPos p = base.add(dx, dy, dz);
						if (pf.standable(p)) {
							spot = p;
							break search;
						}
					}
				}
			}
		}
		Vec3d to = spot != null ? Vec3d.ofBottomCenter(spot) : target.getPos();
		teleport(world, to.x, to.y, to.z, target.getYaw(), 0);
		fallDistance = 0;
		walker.reset();
	}

	public void teleportNear(ServerPlayerEntity target) {
		teleportNear(target, 3);
	}

	// ================================================================ еда

	private void tickEat() {
		if (isUsingItem()) return;
		if (eatCooldown > 0) {
			eatCooldown--;
			return;
		}
		HungerManager hm = getHungerManager();
		int food = hm.getFoodLevel();
		boolean need = food <= 14 || (getHealth() < getMaxHealth() && food <= 17);
		if (!need) return;
		int slot = bestFood();
		if (slot < 0) {
			if (food <= 6) sayOnce("hungry", "Я голодный — брось мне еды", 1200);
			return;
		}
		Inv.hold(this, slot);
		ItemStack stack = getMainHandStack();
		interactionManager.interactItem(this, getWorld(), stack, Hand.MAIN_HAND);
		eatCooldown = 40;
	}

	private int bestFood() {
		var main = getInventory().main;
		int best = -1;
		int bestHunger = -1;
		for (int i = 0; i < main.size(); i++) {
			ItemStack s = main.get(i);
			if (s.isEmpty() || !Inv.isFood(s)) continue; // не ест гнилое, паучьи глаза и золотые яблоки
			int h = s.getItem().getFoodComponent().getHunger();
			if (h > bestHunger) {
				best = i;
				bestHunger = h;
			}
		}
		return best;
	}

	// ================================================================ сон

	private boolean wantsSleep(@Nullable ServerPlayerEntity ownerP) {
		if (!BuddyConfig.get().sleepWithOwner || combat.inFight()) return false;
		if (mode == Mode.MINE || mode == Mode.CHOP || mode == Mode.UNLOAD || mode == Mode.TASK) return false;
		ServerWorld w = getServerWorld();
		if (!w.getDimension().bedWorks()) return false;
		boolean night = w.isNight() || w.isThundering();
		return night && ownerP != null && ownerP.isSleeping() && ownerP.getWorld() == w;
	}

	private void goSleep(@Nullable ServerPlayerEntity ownerP) {
		ServerWorld w = getServerWorld();
		BlockPos bed = findBed(w, ownerP);
		if (bed == null) {
			sayOnce("nobed", "Хочу спать, но свободной кровати рядом нет. Покажи мне кровать: !кровать", 2400);
			walker.stop();
			return;
		}
		if (getPos().distanceTo(Vec3d.ofBottomCenter(bed)) > 2.0) {
			walker.moveTo(bed, 1.5, false);
			if (walker.failedSearches() >= 3) {
				sayOnce("bedfar", "Не могу дойти до кровати", 2400);
			}
			return;
		}
		walker.stop();
		trySleep(bed).ifLeft(reason -> {
			if (reason == SleepFailureReason.NOT_SAFE) sayOnce("bedunsafe", "Рядом монстры — не могу лечь", 600);
			else if (reason == SleepFailureReason.OBSTRUCTED) sayOnce("bedblocked", "Кровать чем-то закрыта", 1200);
		});
		sleepTicks = 0;
	}

	/** Своя кровать (если показали) или ближайшая свободная, кроме кровати хозяина. */
	@Nullable
	private BlockPos findBed(ServerWorld w, @Nullable ServerPlayerEntity ownerP) {
		BlockPos ownerBed = ownerP != null ? ownerP.getSpawnPointPosition() : null;
		if (bedPos != null) {
			BlockPos head = bedHead(w, bedPos);
			if (head != null && !w.getBlockState(head).get(BedBlock.OCCUPIED)) return head;
		}
		BlockPos best = null;
		double bestD = Double.MAX_VALUE;
		BlockPos c = getBlockPos();
		for (BlockPos p : BlockPos.iterate(c.add(-24, -4, -24), c.add(24, 4, 24))) {
			BlockState s = w.getBlockState(p);
			if (!(s.getBlock() instanceof BedBlock) || s.get(BedBlock.PART) != BedPart.HEAD || s.get(BedBlock.OCCUPIED)) continue;
			if (ownerBed != null && (p.equals(ownerBed) || p.equals(ownerBed.offset(s.get(BedBlock.FACING).getOpposite())))) continue;
			double d = p.getSquaredDistance(c);
			if (d < bestD) {
				bestD = d;
				best = p.toImmutable();
			}
		}
		return best;
	}

	@Nullable
	public static BlockPos bedHead(ServerWorld w, BlockPos p) {
		BlockState s = w.getBlockState(p);
		if (!(s.getBlock() instanceof BedBlock)) return null;
		if (s.get(BedBlock.PART) == BedPart.HEAD) return p;
		return p.offset(s.get(BedBlock.FACING));
	}

	private void sleepTick(@Nullable ServerPlayerEntity ownerP) {
		sleepTicks++;
		// хозяин встал раньше утра — встаём тоже
		if (sleepTicks > 40 && (ownerP == null || !ownerP.isSleeping()) && getServerWorld().isNight()) {
			wakeUp(false, true);
		}
	}

	// ================================================================ сохранение

	@Override
	public void writeCustomDataToNbt(NbtCompound nbt) {
		super.writeCustomDataToNbt(nbt);
		NbtCompound b = new NbtCompound();
		b.putString("Mode", mode.name());
		if (anchor != null) b.put("Anchor", NbtHelper.fromBlockPos(anchor));
		if (storagePos != null) b.put("Storage", NbtHelper.fromBlockPos(storagePos));
		if (bedPos != null) b.put("Bed", NbtHelper.fromBlockPos(bedPos));
		if (mineTargetY != Integer.MIN_VALUE) b.putInt("MineY", mineTargetY);
		b.putString("MineDir", mineDir.asString());
		nbt.put("Buddy", b);
	}

	@Override
	public void readCustomDataFromNbt(NbtCompound nbt) {
		super.readCustomDataFromNbt(nbt);
		if (!nbt.contains("Buddy")) return;
		NbtCompound b = nbt.getCompound("Buddy");
		mode = Mode.parse(b.getString("Mode"));
		if (mode == Mode.UNLOAD || mode == Mode.COME || mode == Mode.TASK) mode = Mode.STAY;
		anchor = b.contains("Anchor") ? NbtHelper.toBlockPos(b.getCompound("Anchor")) : null;
		storagePos = b.contains("Storage") ? NbtHelper.toBlockPos(b.getCompound("Storage")) : null;
		bedPos = b.contains("Bed") ? NbtHelper.toBlockPos(b.getCompound("Bed")) : null;
		if (b.contains("MineY")) mineTargetY = b.getInt("MineY");
		Direction d = Direction.byName(b.getString("MineDir"));
		if (d != null && d.getAxis().isHorizontal()) mineDir = d;
	}

	// ================================================================ смерть

	@Override
	public void onDeath(DamageSource source) {
		super.onDeath(source);
		BuddyManager.scheduleRespawn(this);
	}

	/** После загрузки «мёртвым» (умер и переподключился) — оживить. */
	public void reviveIfDead() {
		if (getHealth() > 0 && !isDead()) return;
		setHealth(getMaxHealth());
		deathTime = 0;
		getHungerManager().setFoodLevel(20);
		getHungerManager().setSaturationLevel(5f);
		clearStatusEffects();
		setFireTicks(0);
		setAir(getMaxAir());
		fallDistance = 0;
	}
}
