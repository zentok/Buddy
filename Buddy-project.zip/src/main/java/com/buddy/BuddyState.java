package com.buddy;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.world.PersistentState;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;

/** Какие боты есть в мире, чьи они и в каком режиме. Хранится в data/buddy.dat мира. */
public class BuddyState extends PersistentState {
	public record Entry(String name, UUID owner, String mode) {
	}

	public final Map<String, Entry> bots = new LinkedHashMap<>();

	public static BuddyState fromNbt(NbtCompound tag) {
		BuddyState s = new BuddyState();
		NbtList list = tag.getList("Bots", NbtElement.COMPOUND_TYPE);
		for (int i = 0; i < list.size(); i++) {
			NbtCompound e = list.getCompound(i);
			if (!e.containsUuid("Owner")) continue;
			String name = e.getString("Name");
			s.bots.put(name.toLowerCase(java.util.Locale.ROOT), new Entry(name, e.getUuid("Owner"), e.getString("Mode")));
		}
		return s;
	}

	@Override
	public NbtCompound writeNbt(NbtCompound tag) {
		NbtList list = new NbtList();
		for (Entry e : bots.values()) {
			NbtCompound c = new NbtCompound();
			c.putString("Name", e.name());
			c.putUuid("Owner", e.owner());
			c.putString("Mode", e.mode());
			list.add(c);
		}
		tag.put("Bots", list);
		return tag;
	}
}
