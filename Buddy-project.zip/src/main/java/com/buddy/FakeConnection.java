package com.buddy;

import com.buddy.mixin.ClientConnectionAccessor;
import io.netty.channel.embedded.EmbeddedChannel;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.NetworkSide;
import net.minecraft.network.PacketCallbacks;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

import java.net.InetAddress;
import java.net.InetSocketAddress;

/** Соединение «в никуда»: пакеты боту просто выбрасываются, отключение срабатывает один раз. */
public class FakeConnection extends ClientConnection {
	private boolean disconnected;

	public FakeConnection() {
		super(NetworkSide.SERVERBOUND);
		((ClientConnectionAccessor) this).buddy$setChannel(new EmbeddedChannel());
		((ClientConnectionAccessor) this).buddy$setAddress(new InetSocketAddress(InetAddress.getLoopbackAddress(), 0));
	}

	@Override
	public void send(Packet<?> packet) {
	}

	@Override
	public void send(Packet<?> packet, @Nullable PacketCallbacks callbacks) {
	}

	@Override
	public boolean isOpen() {
		return !disconnected;
	}

	@Override
	public void disableAutoRead() {
	}

	@Override
	public void disconnect(Text reason) {
	}

	@Override
	public void tick() {
	}

	@Override
	public void handleDisconnection() {
		if (disconnected) return;
		disconnected = true;
		PacketListener listener = getPacketListener();
		if (listener != null) listener.onDisconnected(Text.literal("Buddy ушёл"));
	}
}
