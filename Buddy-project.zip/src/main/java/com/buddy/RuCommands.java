package com.buddy;

import com.buddy.task.Items2;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Обычные фразы без ИИ и без «!»: «сделай каменный топор», «добудь 10 угля», «переплавь железо»,
 * «дай мне брёвна», «иди за мной», «копай шахту». Понимает основные предметы по-русски и id на английском.
 */
public final class RuCommands {
	private RuCommands() {
	}

	private static final Pattern NUM = Pattern.compile("(\\d+)");

	private static final String[] CRAFT = {"сделай", "скрафт", "создай", "изготов", "смастер", "собери мне", "крафтни"};
	private static final String[] COLLECT = {"добуд", "принес", "накопа", "наруб", "набер", "собери", "найди", "достань", "насобира", "добыть"};
	private static final String[] SMELT = {"переплав", "расплав", "пережг", "обжиг", "пожар", "запеки", "приготов"};
	private static final String[] GIVE = {"дай ", "дай", "отдай", "передай", "кинь", "брось мне"};

	/** Простые команды режимов (без «!»). */
	private static final String[][] MODES = {
			{"follow", "иди за мной", "следуй", "за мной", "пошли со мной", "пойдём"},
			{"come", "ко мне", "иди сюда", "подойди"},
			{"stay", "стой", "жди здесь", "останься", "охраняй ферму", "работай тут"},
			{"mine", "копай шахту", "иди в шахту", "иди копать", "шахту"},
			{"chop", "руби лес", "иди рубить", "наруби леса"},
			{"unload", "разгрузись", "выгрузи", "отнеси в сундук", "сложи в сундук"},
	};

	/** Похоже ли сообщение на команду боту (чтобы реагировать без имени, если бот один). */
	public static boolean looksLikeCommand(String raw) {
		String t = norm(raw);
		for (String[] row : MODES) for (int i = 1; i < row.length; i++) if (t.startsWith(row[i])) return true;
		return startsWithAny(t, CRAFT) || startsWithAny(t, COLLECT) || startsWithAny(t, SMELT) || startsWithAny(t, GIVE);
	}

	/** Выполнить фразу. false — не понял. */
	public static boolean run(BuddyPlayer bot, String raw) {
		String t = norm(raw).replace(bot.getGameProfile().getName().toLowerCase(Locale.ROOT), " ").replaceAll("\\s+", " ").trim();
		if (t.startsWith(",")) t = t.substring(1).trim();
		Matcher m = NUM.matcher(t);
		Integer count = m.find() ? Integer.parseInt(m.group(1)) : null;

		// режимы
		for (String[] row : MODES) {
			for (int i = 1; i < row.length; i++) {
				if (t.startsWith(row[i]) || t.equals(row[i])) {
					String a = row[0];
					if (a.equals("mine") && (t.contains("нов"))) a = "mine:new";
					ownerAction(bot, a);
					return true;
				}
			}
		}
		String kind = containsAny(t, SMELT) ? "smelt" : containsAny(t, CRAFT) ? "craft" : containsAny(t, GIVE) ? "give"
				: containsAny(t, COLLECT) ? "collect" : null;
		if (kind == null) return false;
		Item item = item(bot, t, kind);
		if (kind.equals("give")) {
			String d = bot.startGive(item, count != null ? count : (item == null ? 64 : 64 * 36));
			bot.say("Несу: " + d);
			return true;
		}
		if (item == null && kind.equals("collect") && (t.contains("руд") || t.contains("ресурс") || t.contains("ископаем") || t.contains("шахт"))) {
			ownerAction(bot, "mine");
			return true;
		}
		if (item == null) {
			bot.say("Не понял, что именно. Скажи, например: «сделай каменный топор», «добудь 10 угля», «переплавь 5 железа».");
			return true;
		}
		int n = count != null ? count : (kind.equals("collect") ? 16 : 1);
		String d = bot.startTask(kind, item, n);
		bot.say("Принято: " + d + ".");
		return true;
	}

	private static void ownerAction(BuddyPlayer bot, String a) {
		var owner = bot.getOwnerPlayer();
		if (owner != null) Buddy.runAction(owner, a, bot.getGameProfile().getName(), null);
	}

	// ------------------------------------------------------------------ предметы по-русски

	private static final Map<String, String> MATERIAL = new LinkedHashMap<>();
	private static final Map<String, String> TOOL = new LinkedHashMap<>();
	private static final Map<String, String> WORDS = new LinkedHashMap<>();

	static {
		MATERIAL.put("незерит", "netherite");
		MATERIAL.put("алмаз", "diamond");
		MATERIAL.put("желез", "iron");
		MATERIAL.put("золот", "golden");
		MATERIAL.put("камен", "stone");
		MATERIAL.put("деревян", "wooden");
		MATERIAL.put("кожан", "leather");

		TOOL.put("кирк", "pickaxe");
		TOOL.put("топор", "axe");
		TOOL.put("меч", "sword");
		TOOL.put("лопат", "shovel");
		TOOL.put("мотыг", "hoe");
		TOOL.put("шлем", "helmet");
		TOOL.put("нагрудник", "chestplate");
		TOOL.put("кирас", "chestplate");
		TOOL.put("понож", "leggings");
		TOOL.put("штан", "leggings");
		TOOL.put("ботин", "boots");
		TOOL.put("сапог", "boots");

		// порядок важен: длинные/точные основы раньше
		WORDS.put("слит желез", "iron_ingot");
		WORDS.put("железн слит", "iron_ingot");
		WORDS.put("слит золот", "gold_ingot");
		WORDS.put("золот слит", "gold_ingot");
		WORDS.put("слит мед", "copper_ingot");
		WORDS.put("медн слит", "copper_ingot");
		WORDS.put("верстак", "crafting_table");
		WORDS.put("печк", "furnace");
		WORDS.put("печь", "furnace");
		WORDS.put("сундук", "chest");
		WORDS.put("бочк", "barrel");
		WORDS.put("факел", "torch");
		WORDS.put("палк", "stick");
		WORDS.put("доск", "#planks");
		WORDS.put("бревн", "oak_log");
		WORDS.put("древесин", "oak_log");
		WORDS.put("дерев", "oak_log");
		WORDS.put("угол", "coal");
		WORDS.put("угл", "coal");
		WORDS.put("булыжн", "cobblestone");
		WORDS.put("камн", "cobblestone");
		WORDS.put("камен", "cobblestone");
		WORDS.put("песо", "sand");
		WORDS.put("песк", "sand");
		WORDS.put("земл", "dirt");
		WORDS.put("грави", "gravel");
		WORDS.put("глин", "clay_ball");
		WORDS.put("стекл", "glass");
		WORDS.put("хлеб", "bread");
		WORDS.put("лестниц", "ladder");
		WORDS.put("ведр", "bucket");
		WORDS.put("щит", "shield");
		WORDS.put("стрел", "arrow");
		WORDS.put("удочк", "fishing_rod");
		WORDS.put("ножниц", "shears");
		WORDS.put("редстоун", "redstone");
		WORDS.put("красн пыл", "redstone");
		WORDS.put("лазурит", "lapis_lazuli");
		WORDS.put("изумруд", "emerald");
		WORDS.put("алмаз", "diamond");
		WORDS.put("мед", "raw_copper");
		WORDS.put("желез", "raw_iron");
		WORDS.put("золот", "raw_gold");
		WORDS.put("кремн", "flint");
		WORDS.put("нитк", "string");
		WORDS.put("нить", "string");
		WORDS.put("кост", "bone");
		WORDS.put("рельс", "rail");
		WORDS.put("тележк", "minecart");
		WORDS.put("лодк", "oak_boat");
		WORDS.put("лук", "bow");
		WORDS.put("говядин", "beef");
		WORDS.put("свинин", "porkchop");
		WORDS.put("куриц", "chicken");
		WORDS.put("баранин", "mutton");
		WORDS.put("картош", "potato");
	}

	@Nullable
	static Item item(BuddyPlayer bot, String t, String kind) {
		// 1) английский id прямо в тексте
		for (String w : t.split(" ")) {
			if (w.matches("[a-z0-9_:]+") && w.length() > 2) {
				Item i = Items2.resolve(w);
				if (i != null) return i;
			}
		}
		// 2) инструмент/броня: материал + предмет
		String tool = null;
		for (var e : TOOL.entrySet()) if (t.contains(e.getKey())) {
			tool = e.getValue();
			break;
		}
		if (tool != null) {
			String mat = null;
			for (var e : MATERIAL.entrySet()) if (t.contains(e.getKey())) {
				mat = e.getValue();
				break;
			}
			boolean armor = tool.equals("helmet") || tool.equals("chestplate") || tool.equals("leggings") || tool.equals("boots");
			if (mat == null) mat = armor ? "iron" : "stone";
			if (armor && (mat.equals("wooden") || mat.equals("stone"))) mat = "leather";
			if (!armor && mat.equals("leather")) mat = "wooden";
			if (armor && mat.equals("golden")) mat = "golden";
			Item i = Registries.ITEM.get(new Identifier("minecraft", mat + "_" + tool));
			if (i != Items.AIR) return i;
		}
		// 3) переплавка: «железо» → слиток, «песок» → стекло, мясо → жареное
		if (kind.equals("smelt")) {
			if (t.contains("желез")) return Items.IRON_INGOT;
			if (t.contains("золот")) return Items.GOLD_INGOT;
			if (t.contains("мед")) return Items.COPPER_INGOT;
			if (t.contains("песо") || t.contains("песк") || t.contains("стекл")) return Items.GLASS;
			if (t.contains("камн") || t.contains("булыжн") || t.contains("камен")) return Items.STONE;
			if (t.contains("говядин") || t.contains("мяс")) return Items.COOKED_BEEF;
			if (t.contains("свинин")) return Items.COOKED_PORKCHOP;
			if (t.contains("курин") || t.contains("куриц")) return Items.COOKED_CHICKEN;
			if (t.contains("баранин")) return Items.COOKED_MUTTON;
			if (t.contains("картош")) return Items.BAKED_POTATO;
			if (t.contains("бревн") || t.contains("брёвн") || t.contains("уголь") || t.contains("угл")) return Items.CHARCOAL;
		}
		// 4) остальные слова
		for (var e : WORDS.entrySet()) {
			if (!t.contains(e.getKey())) continue;
			if (e.getValue().equals("#planks")) return planksFor(bot);
			Item i = Items2.resolve(e.getValue());
			if (i != null) return i;
		}
		return null;
	}

	/** Доски из того дерева, брёвна которого есть в инвентаре (иначе дубовые). */
	private static Item planksFor(BuddyPlayer bot) {
		for (ItemStack s : bot.getInventory().main) {
			if (!s.isIn(ItemTags.LOGS)) continue;
			Identifier id = Registries.ITEM.getId(s.getItem());
			String p = id.getPath().replace("stripped_", "").replace("_log", "_planks").replace("_wood", "_planks")
					.replace("_stem", "_planks").replace("_hyphae", "_planks");
			Item i = Registries.ITEM.get(new Identifier(id.getNamespace(), p));
			if (i != Items.AIR) return i;
		}
		return Items.OAK_PLANKS;
	}

	// ------------------------------------------------------------------ строки

	private static String norm(String s) {
		return s.toLowerCase(Locale.ROOT).replace('ё', 'е').replaceAll("[.!?;:\"«»()]", " ").replaceAll("\\s+", " ").trim();
	}

	private static boolean startsWithAny(String t, String[] words) {
		for (String w : words) if (t.startsWith(w.trim())) return true;
		return false;
	}

	private static boolean containsAny(String t, String[] words) {
		for (String w : words) {
			String x = w.trim();
			if (t.startsWith(x) || t.contains(" " + x)) return true;
		}
		return false;
	}
}
