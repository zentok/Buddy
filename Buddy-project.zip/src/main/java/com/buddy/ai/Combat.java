package com.buddy.ai;

import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.CreeperEntity;
import net.minecraft.entity.mob.EndermanEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.passive.TameableEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

/**
 * Бой: защищает хозяина и себя, бьёт цель хозяина, сам берёт лучшее оружие.
 * От взрывающегося крипера отбегает, при малом здоровье отступает.
 */
public class Combat {
	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	@Nullable
	private LivingEntity target;
	private int scanTimer;
	private int equipTimer;

	public Combat(BuddyPlayer bot, Walker walker, Hands hands) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
	}

	public boolean inFight() {
		return target != null;
	}

	public void clear() {
		target = null;
	}

	/** true — бот сейчас занят боем (остальные дела ждут). */
	public boolean tick(@Nullable ServerPlayerEntity owner) {
		if (++equipTimer >= 100 && !blocking) {
			equipTimer = 0;
			Inv.equipBest(bot); // броня, тотем во вторую руку (или щит, если тотема нет)
		}
		if (!BuddyConfig.get().fight) return false;
		if (target != null && !valid(target)) target = null;
		if (target == null) lowerShield();
		if (--scanTimer <= 0) {
			scanTimer = 10;
			LivingEntity t = pick(owner);
			if (t != null) target = t;
		}
		if (target == null) return false;

		double dist = bot.distanceTo(target);
		// крипер шипит: есть щит — закрыться щитом в его сторону, нет — отбежать
		if (target instanceof CreeperEntity c && c.getFuseSpeed() > 0 && dist < 5.5) {
			if (raiseShield(c)) return true;
			retreatFrom(target.getPos());
			return true;
		}
		lowerShield();
		// мало здоровья — отступить (к хозяину, если он рядом)
		if (bot.getHealth() <= 6 && dist < 6) {
			if (owner != null && owner.getWorld() == bot.getWorld() && bot.distanceTo(owner) < 24) {
				walker.moveTo(owner.getBlockPos(), 2, true);
			} else {
				retreatFrom(target.getPos());
			}
			return true;
		}
		hands.cancel();
		Inv.holdBestWeapon(bot);
		hands.lookAt(target.getPos().add(0, target.getHeight() * 0.6, 0));
		if (dist > 2.6) {
			walker.moveTo(target.getBlockPos(), 2.2, dist > 5);
			hands.lookAt(target.getPos().add(0, target.getHeight() * 0.6, 0));
		} else {
			walker.stop();
		}
		if (dist < 3.2 && bot.canSee(target) && bot.getAttackCooldownProgress(0.5f) >= 0.95f) {
			bot.attack(target);
			bot.swingHand(Hand.MAIN_HAND);
		}
		return true;
	}

	// ------------------------------------------------------------------ щит

	/** Щит поднят (бот закрывается от крипера). */
	private boolean blocking;
	/** Слот, откуда достали щит (во второй руке был тотем — потом вернём). */
	private int shieldSwappedFrom = -1;

	public boolean isBlocking() {
		return blocking;
	}

	/** Взять щит во вторую руку (тотем на время убрать в инвентарь), повернуться к угрозе и закрыться. */
	private boolean raiseShield(LivingEntity threat) {
		ItemStack off = bot.getOffHandStack();
		if (!(off.getItem() instanceof net.minecraft.item.ShieldItem)) {
			int sh = Inv.find(bot, s -> s.getItem() instanceof net.minecraft.item.ShieldItem && Inv.healthy(s));
			if (sh < 0) return false;
			Inv.swapOffhand(bot, sh);
			shieldSwappedFrom = sh;
		}
		walker.stop();
		hands.cancel();
		hands.lookAt(threat.getPos().add(0, threat.getHeight() * 0.5, 0));
		if (!bot.isUsingItem() || bot.getActiveHand() != Hand.OFF_HAND) bot.setCurrentHand(Hand.OFF_HAND);
		blocking = true;
		return true;
	}

	/** Опустить щит и вернуть тотем во вторую руку. */
	private void lowerShield() {
		if (!blocking) return;
		blocking = false;
		if (bot.isUsingItem() && bot.getActiveHand() == Hand.OFF_HAND) bot.stopUsingItem();
		if (shieldSwappedFrom >= 0) {
			int totem = Inv.find(bot, s -> s.isOf(net.minecraft.item.Items.TOTEM_OF_UNDYING));
			if (totem >= 0) Inv.swapOffhand(bot, totem);
			shieldSwappedFrom = -1;
		}
	}

	private void retreatFrom(Vec3d danger) {
		Vec3d away = bot.getPos().subtract(danger);
		if (away.lengthSquared() < 1.0E-4) away = new Vec3d(1, 0, 0);
		Vec3d to = bot.getPos().add(away.normalize().multiply(6));
		walker.moveTo(BlockPos.ofFloored(to), 1.5, true);
	}

	private boolean valid(LivingEntity e) {
		return e.isAlive() && !e.isRemoved() && e.getWorld() == bot.getWorld() && bot.distanceTo(e) < 24
				&& !(e instanceof PlayerEntity);
	}

	private boolean hostileTo(MobEntity m, @Nullable ServerPlayerEntity owner) {
		LivingEntity t = m.getTarget();
		return t == bot || (owner != null && t == owner);
	}

	/** Кого бить: кто напал на хозяина/бота, кого бьёт хозяин, монстры, которые охотятся на нас, и монстры вплотную. */
	@Nullable
	private LivingEntity pick(@Nullable ServerPlayerEntity owner) {
		if (owner != null && owner.getWorld() == bot.getWorld() && bot.distanceTo(owner) < 24) {
			LivingEntity a = owner.getAttacker();
			if (a != null && canFight(a)) return a;
			LivingEntity hit = owner.getAttacking();
			if (hit != null && owner.age - owner.getLastAttackTime() < 100 && canFight(hit)) return hit;
		}
		LivingEntity mine = bot.getAttacker();
		if (mine != null && canFight(mine)) return mine;
		Box area = bot.getBoundingBox().expand(10, 4, 10);
		LivingEntity best = null;
		double bestD = Double.MAX_VALUE;
		for (Entity e : bot.getWorld().getOtherEntities(bot, area)) {
			if (!(e instanceof MobEntity m) || !(e instanceof Monster) || !canFight(m)) continue;
			if (m instanceof EndermanEntity en && !en.isAngry()) continue;
			double d = bot.distanceTo(m);
			boolean threat = hostileTo(m, owner) || d < 4.5;
			if (!threat || !bot.canSee(m)) continue;
			if (d < bestD) {
				best = m;
				bestD = d;
			}
		}
		return best;
	}

	private boolean canFight(LivingEntity e) {
		if (!valid(e) || e == bot) return false;
		if (e instanceof TameableEntity t && t.isTamed()) return false;
		return !(e instanceof BuddyPlayer);
	}
}
