package com.buddy.ai;

import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import net.minecraft.block.AttachedStemBlock;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CropBlock;
import net.minecraft.block.NetherWartBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.Nullable;

/**
 * Работа в режиме «стой»: бот остаётся на месте и следит за фермой вокруг —
 * собирает созревшее, сажает заново, подбирает выпавшее и уносит урожай в сундук.
 */
public class FarmJob {
	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Storekeeper store;
	private final BlockPos anchor;
	@Nullable
	private BlockPos target;
	@Nullable
	private BlockPos replant;
	@Nullable
	private Item replantItem;
	@Nullable
	private ItemEntity pickup;
	private int pickupTicks;
	private int scanTimer;
	private int targetTicks;
	private boolean unloading;

	public FarmJob(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, BlockPos anchor) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.store = store;
		this.anchor = anchor.toImmutable();
	}

	public BlockPos anchor() {
		return anchor;
	}

	public void tick() {
		ServerWorld world = bot.getServerWorld();
		// 1. разгрузка
		if (unloading || (target == null && replant == null && store.wantsToUnload(64))) {
			unloading = store.unload(anchor);
			if (unloading) return;
		}
		// 2. посадить на месте собранного
		if (replant != null) {
			if (!world.getBlockState(replant).isAir() || replantItem == null || Inv.find(bot, s -> s.isOf(replantItem)) < 0) {
				replant = null;
			} else if (!hands.inReach(replant.down()) || bot.getPos().distanceTo(net.minecraft.util.math.Vec3d.ofCenter(replant)) > 3.5) {
				walker.moveTo(replant, 2.0, false);
				return;
			} else {
				walker.stop();
				Item it = replantItem;
				hands.useOn(replant.down(), Direction.UP, s -> s.isOf(it));
				replant = null;
				return;
			}
		}
		// 3. подобрать выпавшее
		if (collect()) return;
		// 4. собрать созревшее
		if (target == null && --scanTimer <= 0) {
			scanTimer = 40;
			target = findRipe(world);
			targetTicks = 0;
		}
		if (target != null) {
			BlockState s = world.getBlockState(target);
			if (!isRipe(world, target, s) || ++targetTicks > 400) {
				target = null;
				hands.cancel();
				return;
			}
			if (!hands.inReach(target) || bot.getPos().distanceTo(net.minecraft.util.math.Vec3d.ofCenter(target)) > 3.5) {
				walker.moveTo(target, 2.0, false);
				return;
			}
			walker.stop();
			Item seed = needsReplant(s) ? s.getBlock().getPickStack(world, target, s).getItem() : null;
			if (hands.breakBlock(target)) {
				if (seed != null) {
					replant = target;
					replantItem = seed;
				}
				target = null;
			}
			return;
		}
		// 5. делать нечего — стоять на своём месте
		if (bot.getBlockPos().getSquaredDistance(anchor) > 2.5 * 2.5) walker.moveTo(anchor, 1.2, false);
		else walker.stop();
	}

	private boolean collect() {
		if (pickup != null && (!pickup.isAlive() || ++pickupTicks > 120)) pickup = null;
		if (pickup == null) {
			int r = BuddyConfig.get().farmRadius + 2;
			Box area = new Box(anchor).expand(r, 3, r);
			double best = 10 * 10;
			for (ItemEntity e : bot.getWorld().getEntitiesByClass(ItemEntity.class, area, e -> !e.cannotPickup())) {
				double d = e.squaredDistanceTo(bot);
				if (d < best) {
					best = d;
					pickup = e;
				}
			}
			pickupTicks = 0;
			if (pickup == null || Inv.emptySlots(bot) == 0) {
				pickup = null;
				return false;
			}
		}
		walker.moveTo(pickup.getBlockPos(), 0.6, false);
		return true;
	}

	@Nullable
	private BlockPos findRipe(ServerWorld world) {
		int r = BuddyConfig.get().farmRadius;
		BlockPos best = null;
		double bestD = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(anchor.add(-r, -2, -r), anchor.add(r, 3, r))) {
			BlockState s = world.getBlockState(p);
			if (!isRipe(world, p, s)) continue;
			double d = p.getSquaredDistance(bot.getBlockPos());
			if (d < bestD) {
				bestD = d;
				best = p.toImmutable();
			}
		}
		return best;
	}

	public static boolean needsReplant(BlockState s) {
		return s.getBlock() instanceof CropBlock || s.getBlock() instanceof NetherWartBlock;
	}

	/** Созрело ли: культуры (в т.ч. Farmer's Delight), адский нарост, тыквы/арбузы у стебля, тростник (верх). */
	public static boolean isRipe(ServerWorld world, BlockPos p, BlockState s) {
		Block b = s.getBlock();
		if (b instanceof CropBlock crop) return crop.isMature(s);
		if (b instanceof NetherWartBlock) return s.get(NetherWartBlock.AGE) >= 3;
		if (s.isOf(Blocks.PUMPKIN) || s.isOf(Blocks.MELON)) {
			for (Direction d : Direction.Type.HORIZONTAL) {
				BlockState n = world.getBlockState(p.offset(d));
				if (n.getBlock() instanceof AttachedStemBlock && n.get(AttachedStemBlock.FACING) == d.getOpposite()) return true;
			}
			return false;
		}
		if (s.isOf(Blocks.SUGAR_CANE)) return world.getBlockState(p.down()).isOf(Blocks.SUGAR_CANE)
				&& !world.getBlockState(p.down(2)).isOf(Blocks.SUGAR_CANE) || (world.getBlockState(p.down()).isOf(Blocks.SUGAR_CANE)
				&& world.getBlockState(p.down(2)).isOf(Blocks.SUGAR_CANE) && !world.getBlockState(p.down(3)).isOf(Blocks.SUGAR_CANE));
		return false;
	}

	@SuppressWarnings("unused")
	private static boolean has(BuddyPlayer bot, ItemStack s) {
		return Inv.find(bot, x -> ItemStack.canCombine(x, s)) >= 0;
	}
}
