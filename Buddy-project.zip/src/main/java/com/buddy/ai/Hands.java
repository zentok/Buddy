package com.buddy.ai;

import com.buddy.BuddyPlayer;
import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;

/**
 * «Руки» бота: ломает блоки с настоящей скоростью (инструмент, трещины, износ), ставит блоки, смотрит на цель.
 * Всё через обычные механики игрока, поэтому работают зачарования, опыт, выпадение и защита спавна.
 */
public class Hands {
	public static final double REACH = 4.5;

	private final BuddyPlayer bot;
	@Nullable
	private BlockPos breaking;
	private float progress;
	private int swingTimer;

	public Hands(BuddyPlayer bot) {
		this.bot = bot;
	}

	public void lookAt(Vec3d p) {
		double dx = p.x - bot.getX();
		double dz = p.z - bot.getZ();
		double dy = p.y - bot.getEyeY();
		float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
		float pitch = (float) -(MathHelper.atan2(dy, Math.sqrt(dx * dx + dz * dz)) * (180.0 / Math.PI));
		bot.setYaw(yaw);
		bot.setHeadYaw(yaw);
		bot.setBodyYaw(yaw);
		bot.setPitch(MathHelper.clamp(pitch, -90, 90));
	}

	public boolean inReach(BlockPos pos) {
		return bot.getEyePos().squaredDistanceTo(Vec3d.ofCenter(pos)) <= REACH * REACH;
	}

	public void cancel() {
		if (breaking != null) bot.getServerWorld().setBlockBreakingInfo(bot.getId(), breaking, -1);
		breaking = null;
		progress = 0;
	}

	public boolean isBreaking() {
		return breaking != null;
	}

	/**
	 * Ломать блок. true — блока больше нет (сломан или уже был воздух).
	 * false — ещё ломаем. Если блок нельзя сломать, вернёт true и hardFail() будет true.
	 */
	public boolean breakBlock(BlockPos pos) {
		ServerWorld world = bot.getServerWorld();
		BlockState state = world.getBlockState(pos);
		if (state.isAir()) {
			cancel();
			return true;
		}
		if (!state.getFluidState().isEmpty() && state.getBlock() instanceof net.minecraft.block.FluidBlock) {
			cancel();
			return true;
		}
		if (state.getHardness(world, pos) < 0) {
			cancel();
			failed = true;
			return true;
		}
		if (!pos.equals(breaking)) {
			cancel();
			breaking = pos.toImmutable();
			int tool = Inv.bestTool(bot, state);
			if (tool >= 0) Inv.hold(bot, tool);
			else Inv.holdFirst(bot, s -> !s.isDamageable() && !(s.getItem() instanceof net.minecraft.item.BlockItem)); // пустая/безопасная рука
			failed = false;
		}
		lookAt(Vec3d.ofCenter(pos));
		float delta = state.calcBlockBreakingDelta(bot, world, pos);
		progress += delta;
		if (++swingTimer >= 5) {
			bot.swingHand(Hand.MAIN_HAND);
			swingTimer = 0;
		}
		if (progress >= 1.0f) {
			world.setBlockBreakingInfo(bot.getId(), pos, -1);
			bot.interactionManager.tryBreakBlock(pos);
			bot.swingHand(Hand.MAIN_HAND);
			breaking = null;
			progress = 0;
			return world.getBlockState(pos).isAir() || world.getBlockState(pos).isReplaceable();
		}
		world.setBlockBreakingInfo(bot.getId(), pos, (int) (progress * 10.0f) - 1);
		return false;
	}

	private boolean failed;

	public boolean hardFail() {
		return failed;
	}

	/** Поставить блок предмета (из инвентаря) в позицию target, опираясь на соседний твёрдый блок. */
	public boolean place(BlockPos target, Predicate<ItemStack> item) {
		ServerWorld world = bot.getServerWorld();
		if (!world.getBlockState(target).isReplaceable()) return false;
		int slot = Inv.find(bot, item);
		if (slot < 0) return false;
		for (Direction d : Direction.values()) {
			BlockPos support = target.offset(d);
			BlockState s = world.getBlockState(support);
			if (s.isAir() || s.isReplaceable()) continue;
			Inv.hold(bot, slot);
			Direction face = d.getOpposite();
			Vec3d hit = Vec3d.ofCenter(support).add(Vec3d.of(face.getVector()).multiply(0.5));
			lookAt(hit);
			ItemStack stack = bot.getMainHandStack();
			bot.interactionManager.interactBlock(bot, world, stack, Hand.MAIN_HAND, new BlockHitResult(hit, face, support, false));
			bot.swingHand(Hand.MAIN_HAND);
			return !world.getBlockState(target).isReplaceable();
		}
		return false;
	}

	/** «Нажать ПКМ» предметом по грани блока (посадить семена на грядку, поставить факел на пол). */
	public boolean useOn(BlockPos block, Direction face, Predicate<ItemStack> item) {
		int slot = Inv.find(bot, item);
		if (slot < 0) return false;
		Inv.hold(bot, slot);
		ServerWorld world = bot.getServerWorld();
		Vec3d hit = Vec3d.ofCenter(block).add(Vec3d.of(face.getVector()).multiply(0.5));
		lookAt(hit);
		bot.interactionManager.interactBlock(bot, world, bot.getMainHandStack(), Hand.MAIN_HAND, new BlockHitResult(hit, face, block, false));
		bot.swingHand(Hand.MAIN_HAND);
		return true;
	}
}
