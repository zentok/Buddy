package com.buddy.ai;

import com.buddy.BuddyPlayer;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.block.BlockState;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributeModifier;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ArmorItem;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.MiningToolItem;
import net.minecraft.item.ShieldItem;
import net.minecraft.item.SwordItem;
import net.minecraft.item.ToolItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import org.jetbrains.annotations.Nullable;

import java.util.function.Predicate;

/** Работа с инвентарём бота: взять в руку, лучший инструмент/оружие, броня, разгрузка в сундук. */
public final class Inv {
	private Inv() {
	}

	/** Взять предмет из слота в руку (если он не в хотбаре — поменять местами с выбранным слотом). */
	public static void hold(BuddyPlayer bot, int slot) {
		PlayerInventory inv = bot.getInventory();
		if (slot < 0) return;
		if (slot < 9) {
			inv.selectedSlot = slot;
			return;
		}
		int hb = inv.selectedSlot;
		ItemStack a = inv.main.get(slot);
		inv.main.set(slot, inv.main.get(hb));
		inv.main.set(hb, a);
	}

	public static int find(BuddyPlayer bot, Predicate<ItemStack> p) {
		var main = bot.getInventory().main;
		for (int i = 0; i < main.size(); i++) {
			ItemStack s = main.get(i);
			if (!s.isEmpty() && p.test(s)) return i;
		}
		return -1;
	}

	public static int count(BuddyPlayer bot, Predicate<ItemStack> p) {
		int n = 0;
		for (ItemStack s : bot.getInventory().main) if (!s.isEmpty() && p.test(s)) n += s.getCount();
		return n;
	}

	public static boolean holdFirst(BuddyPlayer bot, Predicate<ItemStack> p) {
		int i = find(bot, p);
		if (i < 0) return false;
		hold(bot, i);
		return true;
	}

	public static int emptySlots(BuddyPlayer bot) {
		int n = 0;
		for (ItemStack s : bot.getInventory().main) if (s.isEmpty()) n++;
		return n;
	}

	/** Инструмент не на последнем издыхании (чтобы не ломать чужие кирки). */
	public static boolean healthy(ItemStack s) {
		return !s.isDamageable() || s.getMaxDamage() - s.getDamage() > 3;
	}

	/** Лучший инструмент для блока. -1 — рукой не хуже (или нет ничего). */
	public static int bestTool(BuddyPlayer bot, BlockState state) {
		var main = bot.getInventory().main;
		int best = -1;
		float bestSpeed = 1.0f;
		boolean needCorrect = state.isToolRequired();
		for (int i = 0; i < main.size(); i++) {
			ItemStack s = main.get(i);
			if (s.isEmpty() || !healthy(s)) continue;
			float speed = s.getMiningSpeedMultiplier(state);
			boolean ok = !needCorrect || s.isSuitableFor(state);
			if (ok && speed > bestSpeed) {
				best = i;
				bestSpeed = speed;
			}
		}
		return best;
	}

	/** Есть ли чем добыть блок так, чтобы он выпал. */
	public static boolean canHarvest(BuddyPlayer bot, BlockState state) {
		if (!state.isToolRequired()) return true;
		return find(bot, s -> healthy(s) && s.isSuitableFor(state)) >= 0;
	}

	public static double attackDamage(ItemStack s) {
		double d = 0;
		for (EntityAttributeModifier m : s.getAttributeModifiers(EquipmentSlot.MAINHAND).get(EntityAttributes.GENERIC_ATTACK_DAMAGE)) {
			if (m.getOperation() == EntityAttributeModifier.Operation.ADDITION) d += m.getValue();
		}
		return d;
	}

	/** Взять лучшее оружие (меч/топор/инструмент с наибольшим уроном). */
	public static void holdBestWeapon(BuddyPlayer bot) {
		var main = bot.getInventory().main;
		int best = -1;
		double bestDmg = 0.5;
		for (int i = 0; i < main.size(); i++) {
			ItemStack s = main.get(i);
			if (s.isEmpty() || !healthy(s)) continue;
			double d = attackDamage(s) + (s.getItem() instanceof SwordItem ? 0.5 : 0);
			if (d > bestDmg) {
				best = i;
				bestDmg = d;
			}
		}
		if (best >= 0) hold(bot, best);
	}

	private static float armorValue(ItemStack s) {
		if (!(s.getItem() instanceof ArmorItem a)) return -1;
		return a.getProtection() + a.getToughness() * 0.5f;
	}

	/** Надеть лучшую броню из инвентаря и щит во вторую руку. */
	public static void equipBest(BuddyPlayer bot) {
		PlayerInventory inv = bot.getInventory();
		for (int i = 0; i < inv.main.size(); i++) {
			ItemStack s = inv.main.get(i);
			if (s.getItem() instanceof ArmorItem a) {
				EquipmentSlot slot = a.getSlotType();
				ItemStack worn = bot.getEquippedStack(slot);
				if (armorValue(s) > armorValue(worn)) {
					inv.main.set(i, worn.copy());
					bot.equipStack(slot, s.copy());
				}
			}
		}
		// вторая рука: тотем бессмертия важнее всего (спасает от смерти), иначе щит
		ItemStack off = bot.getOffHandStack();
		if (!off.isOf(Items.TOTEM_OF_UNDYING)) {
			int totem = find(bot, s -> s.isOf(Items.TOTEM_OF_UNDYING));
			if (totem >= 0) {
				swapOffhand(bot, totem);
				return;
			}
		}
		if (bot.getOffHandStack().isEmpty()) {
			int sh = find(bot, s -> s.getItem() instanceof ShieldItem);
			if (sh >= 0) swapOffhand(bot, sh);
		}
	}

	/** Поменять местами предмет из слота инвентаря и вторую руку. */
	public static void swapOffhand(BuddyPlayer bot, int slot) {
		PlayerInventory inv = bot.getInventory();
		ItemStack off = bot.getOffHandStack().copy();
		bot.equipStack(EquipmentSlot.OFFHAND, inv.main.get(slot).copy());
		inv.main.set(slot, off);
	}

	// ------------------------------------------------------------------ что оставлять себе

	public static boolean isTool(ItemStack s) {
		Item i = s.getItem();
		return i instanceof ToolItem || i instanceof MiningToolItem || i instanceof SwordItem || i instanceof ShieldItem
				|| i instanceof ArmorItem || s.isDamageable();
	}

	public static boolean isSeed(ItemStack s) {
		Item i = s.getItem();
		return i == Items.WHEAT_SEEDS || i == Items.BEETROOT_SEEDS || i == Items.CARROT || i == Items.POTATO
				|| i == Items.NETHER_WART || i == Items.MELON_SEEDS || i == Items.PUMPKIN_SEEDS || s.isIn(ItemTags.SAPLINGS)
				|| Registries.ITEM.getId(i).getPath().contains("seed");
	}

	/** Мусорные камни из шахты. */
	public static boolean isJunk(ItemStack s) {
		Item i = s.getItem();
		return i == Items.COBBLESTONE || i == Items.COBBLED_DEEPSLATE || i == Items.DIRT || i == Items.GRAVEL || i == Items.TUFF
				|| i == Items.ANDESITE || i == Items.DIORITE || i == Items.GRANITE || i == Items.NETHERRACK || i == Items.CALCITE
				|| i == Items.SAND || i == Items.SANDSTONE || i == Items.SMOOTH_BASALT || i == Items.DRIPSTONE_BLOCK
				|| i == Items.POINTED_DRIPSTONE || i == Items.FLINT;
	}

	/** Блок, которым можно заделать дыру/лаву (камень, булыжник, глубинный сланец, земля). */
	public static boolean isFiller(ItemStack s) {
		Item i = s.getItem();
		return i == Items.COBBLESTONE || i == Items.COBBLED_DEEPSLATE || i == Items.DIRT || i == Items.NETHERRACK
				|| i == Items.STONE || i == Items.DEEPSLATE || i == Items.ANDESITE || i == Items.DIORITE || i == Items.GRANITE
				|| i == Items.TUFF;
	}

	public static boolean isFood(ItemStack s) {
		return s.isFood() && s.getItem().getFoodComponent() != null && s.getItem().getFoodComponent().getStatusEffects().isEmpty();
	}

	/**
	 * Выбросить лишний мусор из шахты, чтобы было куда класть руду. Оставляет 2 стака заделочных блоков.
	 */
	public static void dropExcessJunk(BuddyPlayer bot) {
		dropExcessJunk(bot, s -> false);
	}

	public static void dropExcessJunk(BuddyPlayer bot, Predicate<ItemStack> keep) {
		int keepFiller = 128;
		var main = bot.getInventory().main;
		for (int i = main.size() - 1; i >= 0; i--) {
			ItemStack s = main.get(i);
			if (s.isEmpty() || !isJunk(s) || keep.test(s)) continue;
			if (isFiller(s) && keepFiller > 0) {
				keepFiller -= s.getCount();
				continue;
			}
			var item = bot.dropItem(s.copy(), false, false);
			if (item != null) item.setPickupDelayInfinite();
			main.set(i, ItemStack.EMPTY);
		}
	}

	/**
	 * Сложить добычу в хранилище (сундук, бочка, хранилища модов — через Fabric Transfer API).
	 * Себе оставляет инструменты, броню, еду (стак), семена/саженцы (стак каждого), факелы и 2 стака камня.
	 * Возвращает, сколько предметов переложено, или -1, если там нет хранилища.
	 */
	public static int depositInto(BuddyPlayer bot, ServerWorld world, BlockPos pos) {
		Storage<ItemVariant> storage = ItemStorage.SIDED.find(world, pos, net.minecraft.util.math.Direction.UP);
		if (storage == null) return -1;
		var main = bot.getInventory().main;
		int moved = 0;
		java.util.Map<Item, Integer> kept = new java.util.HashMap<>();
		for (int i = 0; i < main.size(); i++) {
			ItemStack s = main.get(i);
			if (s.isEmpty()) continue;
			Item item = s.getItem();
			int keep = 0;
			if (isTool(s)) keep = s.getCount();
			else if (isFood(s)) keep = 64;
			else if (isSeed(s)) keep = 64;
			else if (item == Items.TORCH) keep = 64;
			else if (isFiller(s)) keep = 128;
			int already = kept.getOrDefault(item, 0);
			int keepHere = Math.max(0, Math.min(s.getCount(), keep - already));
			kept.put(item, already + keepHere);
			int give = s.getCount() - keepHere;
			if (give <= 0) continue;
			try (Transaction tx = Transaction.openOuter()) {
				long inserted = storage.insert(ItemVariant.of(s), give, tx);
				tx.commit();
				if (inserted > 0) {
					s.decrement((int) inserted);
					moved += (int) inserted;
				}
			}
		}
		return moved;
	}

	public static boolean isLog(BlockState s) {
		return s.isIn(net.minecraft.registry.tag.BlockTags.LOGS) && !Registries.BLOCK.getId(s.getBlock()).getPath().contains("stripped");
	}

	@Nullable
	public static Item saplingFor(BlockState log) {
		String path = Registries.BLOCK.getId(log.getBlock()).getPath();
		String ns = Registries.BLOCK.getId(log.getBlock()).getNamespace();
		String base = path.replace("_log", "").replace("_wood", "").replace("_stem", "");
		Item sap = Registries.ITEM.get(new net.minecraft.util.Identifier(ns, base + "_sapling"));
		if (sap != Items.AIR) return sap;
		if (base.equals("mangrove")) return Items.MANGROVE_PROPAGULE;
		return null;
	}

	public static boolean isPlaceableBlock(ItemStack s) {
		return s.getItem() instanceof BlockItem;
	}
}
