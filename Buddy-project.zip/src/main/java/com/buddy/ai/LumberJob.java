package com.buddy.ai;

import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import net.minecraft.block.BlockState;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.Item;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Лесоруб: находит рядом настоящие деревья (бревно на земле + листва сверху, чтобы не рубить дома),
 * срубает ствол, сажает саженец, подбирает выпавшее, носит в сундук.
 */
public class LumberJob {
	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Storekeeper store;
	private final BlockPos anchor;

	@Nullable
	private BlockPos base;
	private final List<BlockPos> logs = new ArrayList<>();
	@Nullable
	private Item sapling;
	private int collectTicks;
	private int treeTicks;
	private boolean unloading;
	private final Set<BlockPos> skip = new HashSet<>();
	private int trees;

	public LumberJob(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, BlockPos anchor) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.store = store;
		this.anchor = anchor.toImmutable();
	}

	/** false — работа закончена (деревьев рядом нет / нечем рубить). */
	public boolean tick() {
		ServerWorld world = bot.getServerWorld();
		if (unloading || (base == null && store.wantsToUnload(128))) {
			unloading = store.unload(anchor);
			if (unloading) return true;
		}
		if (base == null) {
			if (collectTicks > 0) {
				collectTicks--;
				if (collect()) return true;
			}
			base = findTree(world);
			treeTicks = 0;
			if (base == null) {
				bot.say(trees > 0 ? "Срубил деревьев: " + trees + ". Рядом больше нет." : "Не вижу рядом деревьев.");
				return false;
			}
			collectLogs(world, base);
			sapling = Inv.saplingFor(world.getBlockState(base));
		}
		if (++treeTicks > 2400) { // дерево не даётся — пропустить
			skip.add(base);
			base = null;
			hands.cancel();
			return true;
		}
		logs.removeIf(p -> !Inv.isLog(world.getBlockState(p)));
		if (logs.isEmpty()) {
			// посадить саженец
			Item sap = sapling;
			if (sap != null && world.getBlockState(base).isAir() && world.getBlockState(base.down()).isIn(BlockTags.DIRT)
					&& Inv.find(bot, s -> s.isOf(sap)) >= 0) {
				if (bot.getBlockPos().equals(base)) {
					walker.stepInto(sideFree(world, base));
					return true;
				}
				if (!hands.inReach(base.down())) {
					walker.moveTo(base, 2.0, false);
					return true;
				}
				hands.useOn(base.down(), Direction.UP, s -> s.isOf(sap));
			}
			trees++;
			base = null;
			collectTicks = 80;
			return true;
		}
		BlockPos next = logs.get(0);
		if (hands.inReach(next)) {
			walker.stop();
			hands.breakBlock(next);
			return true;
		}
		// не достаёт: встать в ствол (после двух нижних брёвен там пусто) или подойти
		BlockPos stand = world.getBlockState(base).isAir() && world.getBlockState(base.up()).isAir() ? base : null;
		if (stand != null && !bot.getBlockPos().equals(stand)) {
			if (bot.getPos().distanceTo(Vec3d.ofBottomCenter(stand)) < 3) walker.stepInto(stand);
			else walker.moveTo(stand, 0.5, false);
			return true;
		}
		if (stand != null) { // стоим в стволе, но всё равно не достаём — бросаем верхушку
			logs.removeIf(p -> !hands.inReach(p));
			return true;
		}
		walker.moveTo(next.getY() > base.getY() + 1 ? base : next, 2.5, false);
		if (walker.failedSearches() >= 4) {
			skip.add(base);
			base = null;
		}
		return true;
	}

	private BlockPos sideFree(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.Type.HORIZONTAL) {
			BlockPos s = p.offset(d);
			if (world.getBlockState(s).getCollisionShape(world, s).isEmpty()
					&& world.getBlockState(s.up()).getCollisionShape(world, s.up()).isEmpty()) return s;
		}
		return p.offset(Direction.NORTH);
	}

	private boolean collect() {
		Box area = new Box(bot.getBlockPos()).expand(8, 4, 8);
		ItemEntity best = null;
		double bd = Double.MAX_VALUE;
		for (ItemEntity e : bot.getWorld().getEntitiesByClass(ItemEntity.class, area, e -> !e.cannotPickup())) {
			double d = e.squaredDistanceTo(bot);
			if (d < bd) {
				bd = d;
				best = e;
			}
		}
		if (best == null || Inv.emptySlots(bot) == 0) return false;
		walker.moveTo(best.getBlockPos(), 0.6, false);
		return true;
	}

	/** Ближайшее «настоящее» дерево: нижнее бревно стоит на земле, а над стволом есть листва. */
	@Nullable
	private BlockPos findTree(ServerWorld world) {
		int r = BuddyConfig.get().lumberRadius;
		BlockPos best = null;
		double bestD = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(anchor.add(-r, -4, -r), anchor.add(r, 8, r))) {
			BlockState s = world.getBlockState(p);
			if (!Inv.isLog(s) || skip.contains(p)) continue;
			if (!world.getBlockState(p.down()).isIn(BlockTags.DIRT)) continue;
			if (!hasLeavesAbove(world, p)) continue;
			double d = p.getSquaredDistance(bot.getBlockPos());
			if (d < bestD) {
				bestD = d;
				best = p.toImmutable();
			}
		}
		return best;
	}

	private static boolean hasLeavesAbove(ServerWorld world, BlockPos base) {
		for (int y = 2; y <= 14; y++) {
			BlockPos c = base.up(y);
			for (BlockPos n : new BlockPos[]{c, c.north(), c.south(), c.east(), c.west()}) {
				BlockState s = world.getBlockState(n);
				if (s.isIn(BlockTags.LEAVES) && !s.get(net.minecraft.block.LeavesBlock.PERSISTENT)) return true;
			}
			if (!Inv.isLog(world.getBlockState(c)) && !world.getBlockState(c).isIn(BlockTags.LEAVES)) {
				// ствол кончился — смотрим ещё чуть-чуть по бокам
				if (y > 3) break;
			}
		}
		return false;
	}

	/** Все брёвна дерева (связанные, в пределах 5 блоков от ствола), снизу вверх. */
	private void collectLogs(ServerWorld world, BlockPos start) {
		logs.clear();
		Set<BlockPos> seen = new HashSet<>();
		ArrayDeque<BlockPos> q = new ArrayDeque<>();
		q.add(start);
		seen.add(start);
		while (!q.isEmpty() && logs.size() < 96) {
			BlockPos p = q.poll();
			logs.add(p);
			for (int dx = -1; dx <= 1; dx++) {
				for (int dy = 0; dy <= 1; dy++) {
					for (int dz = -1; dz <= 1; dz++) {
						BlockPos n = p.add(dx, dy, dz);
						if (seen.contains(n)) continue;
						if (Math.abs(n.getX() - start.getX()) > 5 || Math.abs(n.getZ() - start.getZ()) > 5) continue;
						seen.add(n);
						if (Inv.isLog(world.getBlockState(n))) q.add(n.toImmutable());
					}
				}
			}
		}
		logs.sort(Comparator.comparingInt(BlockPos::getY));
	}
}
