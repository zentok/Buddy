package com.buddy.ai;

import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import net.minecraft.block.BlockState;
import net.minecraft.block.LeavesBlock;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Лесоруб, который смотрит по сторонам.
 * <ol>
 * <li>Находит настоящее дерево (ствол на земле + листва сверху — дома не трогает).</li>
 * <li>Срубает ствол (встаёт в пень, чтобы дотянуться до верха).</li>
 * <li>Обрывает листву, до которой дотягивается, — так саженцы выпадают сразу, а не через минуту.</li>
 * <li>Подбирает всё, что выпало: брёвна, саженцы, палки, яблоки (каждый предмет — пока не подберёт).</li>
 * <li>Сажает саженец на пень. Если саженца нет — запоминает место и вернётся, когда листва осыпется.</li>
 * </ol>
 * В конце обходит запомненные пни, собирает осыпавшиеся саженцы и досаживает.
 */
public class LumberJob {
	private enum Phase {FIND, CUT, LEAVES, COLLECT, PLANT, WAIT_SAPLINGS}

	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Storekeeper store;
	private final BlockPos anchor;

	private Phase phase = Phase.FIND;
	@Nullable
	private BlockPos base;
	private final List<BlockPos> logs = new ArrayList<>();
	private final List<BlockPos> leaves = new ArrayList<>();
	@Nullable
	private Item saplingType;
	/** Пни без саженца — досадим позже. */
	private final List<BlockPos> stumps = new ArrayList<>();
	private final List<Item> stumpTypes = new ArrayList<>();
	private final Set<BlockPos> skipTrees = new HashSet<>();
	private final Set<Integer> skipItems = new HashSet<>();
	@Nullable
	private ItemEntity pickup;
	private int pickupTicks;
	private int phaseTicks;
	private boolean unloading;
	private int trees;
	private int planted;
	/** Топор, сделанный по ходу дела (если его не дали). */
	@Nullable
	private com.buddy.task.CraftTask axeTask;
	private boolean triedAxe;

	public LumberJob(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, BlockPos anchor) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.store = store;
		this.anchor = anchor.toImmutable();
	}

	private void go(Phase p) {
		phase = p;
		phaseTicks = 0;
		hands.cancel();
	}

	/** false — работа закончена. */
	public boolean tick() {
		ServerWorld w = bot.getServerWorld();
		phaseTicks++;
		if (unloading || ((phase == Phase.FIND) && store.wantsToUnload(128))) {
			unloading = store.unload(anchor);
			if (unloading) return true;
		}
		switch (phase) {
			case FIND -> {
				// сначала подобрать то, что лежит рядом (брёвна, саженцы)
				if (collectAround(bot.getBlockPos(), 10)) return true;
				// нет топора, а брёвна уже есть — сделать топор (верстак поставит сам)
				if (makeAxe()) return true;
				base = findTree(w);
				if (base == null) {
					if (!stumps.isEmpty()) {
						bot.say("Деревья рядом кончились. Подожду, пока осыплется листва, и досажу саженцы.");
						go(Phase.WAIT_SAPLINGS);
						return true;
					}
					bot.say(trees > 0 ? "Срубил деревьев: " + trees + ", посадил саженцев: " + planted + ". Рядом больше нет." : "Не вижу рядом деревьев.");
					return false;
				}
				collectLogs(w, base);
				saplingType = Inv.saplingFor(w.getBlockState(base));
				go(Phase.CUT);
			}
			case CUT -> cut(w);
			case LEAVES -> {
				// обрываем листву своего дерева, до которой достаём, — саженцы выпадут сразу
				leaves.removeIf(p -> !w.getBlockState(p).isIn(BlockTags.LEAVES) || !hands.inReach(p));
				if (leaves.isEmpty() || phaseTicks > 600 || hasSapling()) {
					go(Phase.COLLECT);
					return true;
				}
				walker.stop();
				BlockPos l = leaves.get(0);
				int tool = Inv.find(bot, s -> s.isOf(net.minecraft.item.Items.SHEARS) || s.isIn(ItemTags.HOES));
				if (tool >= 0) Inv.hold(bot, tool);
				if (hands.breakBlock(l)) leaves.remove(0);
			}
			case COLLECT -> {
				if (base != null && collectAround(base, 8) && phaseTicks < 900) return true;
				go(Phase.PLANT);
			}
			case PLANT -> {
				BlockPos b = base;
				if (b == null) {
					go(Phase.FIND);
					return true;
				}
				if (!canPlantAt(w, b)) {
					finishTree();
					return true;
				}
				Item sap = pickSapling();
				if (sap == null) {
					// саженца нет — листва осыплется позже, вернёмся
					stumps.add(b);
					stumpTypes.add(saplingType);
					finishTree();
					return true;
				}
				if (plant(w, b, sap) || phaseTicks > 300) finishTree();
			}
			case WAIT_SAPLINGS -> {
				// обходим пни: подбираем осыпавшиеся саженцы, сажаем
				stumps.removeIf(p -> !canPlantAt(w, p));
				if (stumps.isEmpty() || phaseTicks > 20 * 90) {
					bot.say("Готово: срубил " + trees + " деревьев, посадил " + planted + " саженцев"
							+ (stumps.isEmpty() ? "." : ", на " + stumps.size() + " пнях саженцы так и не выпали."));
					return false;
				}
				BlockPos s = stumps.get(0);
				if (collectAround(s, 8)) return true;
				Item sap = pickSapling();
				if (sap != null) {
					if (plant(w, s, sap)) {
						stumps.remove(0);
						stumpTypes.remove(0);
					}
					return true;
				}
				// ждём у пня, иногда обрываем листву, до которой дотягиваемся
				if (bot.getPos().distanceTo(Vec3d.ofBottomCenter(s)) > 4) walker.moveTo(s, 3, false);
				else {
					walker.stop();
					BlockPos leaf = reachableLeaf(w, s);
					if (leaf != null) hands.breakBlock(leaf);
					else if (phaseTicks % 200 == 0 && stumps.size() > 1) { // следующий пень
						stumps.add(stumps.remove(0));
						stumpTypes.add(stumpTypes.remove(0));
					}
				}
			}
		}
		return true;
	}

	private boolean hasAxe() {
		return Inv.find(bot, s -> s.getItem() instanceof net.minecraft.item.AxeItem && Inv.healthy(s)) >= 0;
	}

	private boolean makeAxe() {
		if (axeTask != null) {
			com.buddy.task.Task.Status st = axeTask.tick();
			if (st == com.buddy.task.Task.Status.RUNNING) return true;
			if (st == com.buddy.task.Task.Status.DONE) bot.say("Сделал себе топор — дальше пойдёт быстрее.");
			axeTask = null;
			return false;
		}
		if (triedAxe || hasAxe()) return false;
		int logs = Inv.count(bot, s -> s.isIn(ItemTags.LOGS)) + Inv.count(bot, s -> s.isIn(ItemTags.PLANKS)) / 4;
		if (logs < 3) return false;
		triedAxe = true;
		Item axe = Inv.count(bot, s -> s.isOf(net.minecraft.item.Items.COBBLESTONE) || s.isOf(net.minecraft.item.Items.COBBLED_DEEPSLATE)) >= 3
				? net.minecraft.item.Items.STONE_AXE : net.minecraft.item.Items.WOODEN_AXE;
		axeTask = new com.buddy.task.CraftTask(bot, walker, hands, axe, 1);
		return true;
	}

	private void finishTree() {
		trees++;
		base = null;
		go(Phase.FIND);
	}

	// ------------------------------------------------------------------ рубка

	private void cut(ServerWorld w) {
		if (base == null) {
			go(Phase.FIND);
			return;
		}
		if (phaseTicks > 2400) { // дерево не даётся
			skipTrees.add(base);
			base = null;
			go(Phase.FIND);
			return;
		}
		logs.removeIf(p -> !Inv.isLog(w.getBlockState(p)));
		if (logs.isEmpty()) {
			// спуститься со своего столба, разбирая его
			if (pillarHeight > 0) {
				descendPillar(w);
				return;
			}
			collectLeaves(w, base);
			go(Phase.LEAVES);
			return;
		}
		BlockPos next = logs.get(0);
		if (hands.inReach(next)) {
			walker.stop();
			hands.breakBlock(next);
			return;
		}
		// не достаёт: встать в пень (после нижних брёвен там пусто) или подойти
		boolean trunkFree = w.getBlockState(base).getCollisionShape(w, base).isEmpty()
				&& w.getBlockState(base.up()).getCollisionShape(w, base.up()).isEmpty();
		if (trunkFree && pillarHeight == 0 && !bot.getBlockPos().equals(base)) {
			if (bot.getPos().distanceTo(Vec3d.ofBottomCenter(base)) < 3) walker.stepInto(base);
			else walker.moveTo(base, 0.5, false);
			return;
		}
		if (trunkFree || pillarHeight > 0) {
			// стоим в стволе и не достаём — подняться столбом (блок под себя), как игрок
			BlockPos feet = bot.getBlockPos();
			BlockPos head = feet.up(2);
			BlockState hs = w.getBlockState(head);
			if (!hs.getCollisionShape(w, head).isEmpty()) {
				// над головой листва/бревно — сломать
				if (hands.inReach(head)) hands.breakBlock(head);
				else logs.removeIf(p -> !hands.inReach(p));
				return;
			}
			if (pillarHeight < 16 && Inv.find(bot, LumberJob::pillarBlock) >= 0) {
				pillarUp(w, feet);
				return;
			}
			if (pillarHeight == 0 && Inv.find(bot, LumberJob::pillarBlock) < 0) {
				bot.sayOnce("nopillar", "Дерево высокое — дай мне земли или булыжника, чтобы подняться и срубить верх", 2400);
			}
			logs.removeIf(p -> !hands.inReach(p)); // совсем никак — верхушку оставляем
			return;
		}
		walker.moveTo(next.getY() > base.getY() + 1 ? base : next, 2.5, false);
		if (walker.failedSearches() >= 4) {
			skipTrees.add(base);
			base = null;
			go(Phase.FIND);
		}
	}

	// ------------------------------------------------------------------ столб для высоких деревьев

	private int pillarHeight;

	/** Чем можно строить столб: земля, булыжник, камень… в крайнем случае — бревно (потом заберём). */
	private static boolean pillarBlock(ItemStack s) {
		return Inv.isFiller(s) || s.isIn(ItemTags.LOGS) || s.isIn(ItemTags.PLANKS);
	}

	private void pillarUp(ServerWorld w, BlockPos feet) {
		walker.stop();
		bot.setPitch(90);
		if (bot.getY() >= feet.getY() + 1.0 - 1.0E-3 && w.getBlockState(feet).isReplaceable()) {
			// в прыжке: поставить блок под себя (сначала камень/землю, бревно — в последнюю очередь)
			int slot = Inv.find(bot, Inv::isFiller);
			java.util.function.Predicate<ItemStack> what = slot >= 0 ? Inv::isFiller : LumberJob::pillarBlock;
			bot.setJumping(false);
			if (hands.place(feet, what)) pillarHeight++;
			return;
		}
		bot.setJumping(bot.isOnGround());
	}

	/** Спуск: ломаем блок столба под ногами, падаем на блок, и так до земли. */
	private void descendPillar(ServerWorld w) {
		walker.stop();
		if (base == null || bot.getBlockY() <= base.getY()) {
			pillarHeight = 0;
			return;
		}
		if (!bot.isOnGround()) return;
		BlockPos below = bot.getBlockPos().down();
		if (below.getY() < base.getY()) {
			pillarHeight = 0;
			return;
		}
		if (hands.breakBlock(below)) pillarHeight = Math.max(0, bot.getBlockY() - 1 - base.getY());
	}

	// ------------------------------------------------------------------ саженцы

	private boolean hasSapling() {
		return Inv.find(bot, s -> s.isIn(ItemTags.SAPLINGS) || s.isOf(net.minecraft.item.Items.MANGROVE_PROPAGULE)) >= 0;
	}

	/** Саженец того же дерева, а если такого нет — любой. */
	@Nullable
	private Item pickSapling() {
		Item want = saplingType;
		if (want != null && Inv.find(bot, s -> s.isOf(want)) >= 0) return want;
		int i = Inv.find(bot, s -> s.isIn(ItemTags.SAPLINGS));
		return i >= 0 ? bot.getInventory().main.get(i).getItem() : null;
	}

	private static boolean canPlantAt(ServerWorld w, BlockPos p) {
		BlockState s = w.getBlockState(p);
		return (s.isAir() || s.isReplaceable() && s.getFluidState().isEmpty()) && w.getBlockState(p.down()).isIn(BlockTags.DIRT);
	}

	private boolean plant(ServerWorld w, BlockPos p, Item sap) {
		// стоим в пне — отойти
		if (bot.getBlockPos().equals(p)) {
			walker.stepInto(sideFree(w, p));
			return false;
		}
		if (!hands.inReach(p.down())) {
			walker.moveTo(p, 2.0, false);
			return false;
		}
		walker.stop();
		hands.useOn(p.down(), Direction.UP, s -> s.isOf(sap));
		boolean ok = w.getBlockState(p).getBlock() instanceof net.minecraft.block.SaplingBlock
				|| (sap instanceof BlockItem bi && w.getBlockState(p).isOf(bi.getBlock()));
		if (ok) planted++;
		return ok;
	}

	private BlockPos sideFree(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.Type.HORIZONTAL) {
			BlockPos s = p.offset(d);
			if (world.getBlockState(s).getCollisionShape(world, s).isEmpty()
					&& world.getBlockState(s.up()).getCollisionShape(world, s.up()).isEmpty()) return s;
		}
		return p.offset(Direction.NORTH);
	}

	// ------------------------------------------------------------------ подбор выпавшего

	/** Подобрать предметы рядом с точкой (каждый — пока не подберёт или не станет ясно, что не дойти). */
	private boolean collectAround(BlockPos center, int r) {
		if (Inv.emptySlots(bot) == 0) return false;
		if (pickup != null && (!pickup.isAlive() || ++pickupTicks > 200)) {
			if (pickup.isAlive()) skipItems.add(pickup.getId());
			pickup = null;
		}
		if (pickup == null) {
			Box area = new Box(center).expand(r, 5, r);
			double best = Double.MAX_VALUE;
			for (ItemEntity e : bot.getWorld().getEntitiesByClass(ItemEntity.class, area,
					e -> !e.cannotPickup() && !skipItems.contains(e.getId()) && wanted(e.getStack()))) {
				double d = e.squaredDistanceTo(bot);
				if (d < best) {
					best = d;
					pickup = e;
				}
			}
			pickupTicks = 0;
			if (pickup == null) return false;
		}
		walker.approach(pickup.getPos(), 0.5);
		return true;
	}

	private static boolean wanted(ItemStack s) {
		return s.isIn(ItemTags.LOGS) || s.isIn(ItemTags.SAPLINGS) || s.isOf(net.minecraft.item.Items.STICK)
				|| s.isOf(net.minecraft.item.Items.APPLE) || s.isOf(net.minecraft.item.Items.MANGROVE_PROPAGULE);
	}

	// ------------------------------------------------------------------ поиск

	@Nullable
	private BlockPos findTree(ServerWorld world) {
		int r = BuddyConfig.get().lumberRadius;
		BlockPos best = null;
		double bestD = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(anchor.add(-r, -4, -r), anchor.add(r, 8, r))) {
			BlockState s = world.getBlockState(p);
			if (!Inv.isLog(s) || skipTrees.contains(p)) continue;
			if (!world.getBlockState(p.down()).isIn(BlockTags.DIRT)) continue;
			if (!hasLeavesAbove(world, p)) continue;
			double d = p.getSquaredDistance(bot.getBlockPos());
			if (d < bestD) {
				bestD = d;
				best = p.toImmutable();
			}
		}
		return best;
	}

	private static boolean natural(BlockState s) {
		return s.isIn(BlockTags.LEAVES) && s.contains(LeavesBlock.PERSISTENT) && !s.get(LeavesBlock.PERSISTENT);
	}

	private static boolean hasLeavesAbove(ServerWorld world, BlockPos base) {
		for (int y = 2; y <= 14; y++) {
			BlockPos c = base.up(y);
			for (BlockPos n : new BlockPos[]{c, c.north(), c.south(), c.east(), c.west()}) {
				if (natural(world.getBlockState(n))) return true;
			}
			if (!Inv.isLog(world.getBlockState(c)) && !world.getBlockState(c).isIn(BlockTags.LEAVES) && y > 3) break;
		}
		return false;
	}

	/** Листва своего дерева, до которой бот дотягивается с земли (снизу вверх, ближние первыми). */
	private void collectLeaves(ServerWorld w, BlockPos b) {
		leaves.clear();
		for (BlockPos p : BlockPos.iterate(b.add(-3, 0, -3), b.add(3, 6, 3))) {
			if (natural(w.getBlockState(p)) && hands.inReach(p)) leaves.add(p.toImmutable());
		}
		leaves.sort(Comparator.comparingDouble(p -> p.getSquaredDistance(bot.getBlockPos())));
		if (leaves.size() > 24) leaves.subList(24, leaves.size()).clear();
	}

	@Nullable
	private BlockPos reachableLeaf(ServerWorld w, BlockPos stump) {
		for (BlockPos p : BlockPos.iterate(stump.add(-3, 0, -3), stump.add(3, 6, 3))) {
			if (natural(w.getBlockState(p)) && hands.inReach(p)) return p.toImmutable();
		}
		return null;
	}

	/** Все брёвна дерева (связанные, в пределах 5 блоков от ствола), снизу вверх. */
	private void collectLogs(ServerWorld world, BlockPos start) {
		logs.clear();
		Set<BlockPos> seen = new HashSet<>();
		ArrayDeque<BlockPos> q = new ArrayDeque<>();
		q.add(start);
		seen.add(start);
		while (!q.isEmpty() && logs.size() < 96) {
			BlockPos p = q.poll();
			logs.add(p);
			for (int dx = -1; dx <= 1; dx++) {
				for (int dy = 0; dy <= 1; dy++) {
					for (int dz = -1; dz <= 1; dz++) {
						BlockPos n = p.add(dx, dy, dz);
						if (seen.contains(n)) continue;
						if (Math.abs(n.getX() - start.getX()) > 5 || Math.abs(n.getZ() - start.getZ()) > 5) continue;
						seen.add(n);
						if (Inv.isLog(world.getBlockState(n))) q.add(n.toImmutable());
					}
				}
			}
		}
		logs.sort(Comparator.comparingInt(BlockPos::getY));
	}
}
