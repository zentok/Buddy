package com.buddy.ai;

import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalBlockTags;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Шахта БЕЗ рентгена.
 * <p>
 * Бот не знает, где руда под землёй. Он копает как игрок: лесенкой вниз до нужной высоты, потом главный туннель
 * 1×2 с боковыми ответвлениями (branch mining). Руду он берёт только ту, которую ВИДИТ: блок руды должен
 * касаться воздуха, а луч от глаз бота до него не должен упираться в другой блок. Так он находит руду
 * в стенах своего туннеля (и всю жилу дальше — она открывается по мере добычи) и в пещерах, куда выкопался.
 * <p>
 * Безопасность: не вскрывает блоки рядом с лавой/водой, заделывает дыры в полу, перекапывает осыпавшийся гравий,
 * ставит факелы, лишний камень выбрасывает, полный инвентарь уносит в сундук по своему же туннелю и возвращается.
 */
public class MineJob {
	private enum Phase {DESCEND, TUNNEL, BRANCH_OUT, BRANCH_BACK, EXPLORE, RETURN_HOME, DONE}

	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Storekeeper store;
	private final int targetY;
	private final Direction dir;

	private Phase phase;
	/** Путь «хлебных крошек» от входа до забоя — по нему бот ходит туда и обратно. */
	private final List<BlockPos> crumbs = new ArrayList<>();
	private BlockPos face;
	private int mainDug;
	private int lastBranchAt = -1;
	private Direction branchDir;
	private boolean branchRightDone;
	private int branchDug;
	@Nullable
	private BlockPos branchStart;
	private int torchCounter;
	/** Длина главного туннеля (растёт, если вернуться в законченную шахту). */
	private int mainLimit = BuddyConfig.get().mainTunnelLength;

	// --- пещеры
	/** Клетки 8×8×8, где бот уже побывал в пещере. */
	private final Set<Long> visitedCells = new HashSet<>();
	@Nullable
	private BlockPos exploreTarget;
	private int exploreTicks;
	private int noFrontier;
	private int caveCheck;
	/** Пещеру рядом уже обошли — копаем свою шахту. */
	private boolean caveDone;
	private int caveTorchCounter;

	// --- подбор выпавшего
	@Nullable
	private net.minecraft.entity.ItemEntity pickup;
	private int pickupTicks;
	private final Set<Integer> skipItems = new HashSet<>();

	@Nullable
	private BlockPos ore;
	private int oreTicks;
	private int oreScan;
	private final Set<BlockPos> ignored = new HashSet<>();
	@Nullable
	private BlockPos stepTarget;
	private int stepTicks;

	// разгрузка
	private boolean tripOut;
	private boolean tripBack;
	private int crumbIndex;

	public MineJob(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, Direction dir, int targetY) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.store = store;
		this.dir = dir.getAxis().isHorizontal() ? dir : Direction.NORTH;
		this.targetY = targetY;
		this.face = bot.getBlockPos();
		this.crumbs.add(face);
		this.phase = bot.getBlockY() > targetY ? Phase.DESCEND : Phase.TUNNEL;
		this.branchDir = this.dir.rotateYCounterclockwise();
	}

	// ------------------------------------------------------------------ память шахты

	/** Сохранить шахту (путь, забой, ответвления), чтобы потом вернуться в неё, а не копать новую. */
	public net.minecraft.nbt.NbtCompound toNbt() {
		net.minecraft.nbt.NbtCompound t = new net.minecraft.nbt.NbtCompound();
		t.putString("Dim", bot.getServerWorld().getRegistryKey().getValue().toString());
		t.putString("Dir", dir.asString());
		t.putInt("TargetY", targetY);
		Phase ph = phase == Phase.RETURN_HOME ? Phase.DONE : phase;
		if (ph == Phase.BRANCH_BACK) ph = Phase.BRANCH_OUT;
		t.putString("Phase", ph.name());
		t.putLongArray("Crumbs", crumbs.stream().mapToLong(BlockPos::asLong).toArray());
		t.putLong("Face", face.asLong());
		t.putInt("MainDug", mainDug);
		t.putInt("MainLimit", mainLimit);
		t.putInt("LastBranch", lastBranchAt);
		t.putString("BranchDir", branchDir.asString());
		t.putBoolean("BranchRight", branchRightDone);
		t.putInt("BranchDug", branchDug);
		if (branchStart != null) t.putLong("BranchStart", branchStart.asLong());
		t.putBoolean("CaveDone", caveDone);
		t.putLongArray("Visited", visitedCells.stream().limit(4096).mapToLong(Long::longValue).toArray());
		return t;
	}

	/** Вернуться в сохранённую шахту: дойти до входа и по своему пути — до забоя, дальше копать там. */
	public static MineJob resume(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, net.minecraft.nbt.NbtCompound t) {
		Direction d = Direction.byName(t.getString("Dir"));
		MineJob m = new MineJob(bot, walker, hands, store, d == null ? Direction.NORTH : d, t.getInt("TargetY"));
		m.crumbs.clear();
		for (long l : t.getLongArray("Crumbs")) m.crumbs.add(BlockPos.fromLong(l));
		if (m.crumbs.isEmpty()) m.crumbs.add(bot.getBlockPos());
		m.face = BlockPos.fromLong(t.getLong("Face"));
		m.mainDug = t.getInt("MainDug");
		m.mainLimit = Math.max(t.getInt("MainLimit"), BuddyConfig.get().mainTunnelLength);
		m.lastBranchAt = t.getInt("LastBranch");
		Direction bd = Direction.byName(t.getString("BranchDir"));
		if (bd != null) m.branchDir = bd;
		m.branchRightDone = t.getBoolean("BranchRight");
		m.branchDug = t.getInt("BranchDug");
		if (t.contains("BranchStart")) m.branchStart = BlockPos.fromLong(t.getLong("BranchStart"));
		m.caveDone = t.getBoolean("CaveDone");
		for (long l : t.getLongArray("Visited")) m.visitedCells.add(l);
		Phase ph;
		try {
			ph = Phase.valueOf(t.getString("Phase"));
		} catch (Exception e) {
			ph = Phase.TUNNEL;
		}
		if (ph == Phase.DONE) { // шахта была закончена — продлеваем главный туннель
			ph = m.caveDone || m.mainDug > 0 ? Phase.TUNNEL : (bot.getBlockY() > m.targetY ? Phase.DESCEND : Phase.TUNNEL);
			m.mainLimit = m.mainDug + BuddyConfig.get().mainTunnelLength;
			m.caveDone = true;
		}
		m.phase = ph;
		// идём по своему пути от входа до конца
		m.tripBack = true;
		m.crumbIndex = 0;
		return m;
	}

	public static boolean sameDimension(BuddyPlayer bot, net.minecraft.nbt.NbtCompound t) {
		return bot.getServerWorld().getRegistryKey().getValue().toString().equals(t.getString("Dim"));
	}

	public static BlockPos savedEntrance(net.minecraft.nbt.NbtCompound t) {
		long[] c = t.getLongArray("Crumbs");
		return c.length > 0 ? BlockPos.fromLong(c[0]) : BlockPos.ORIGIN;
	}

	/** Что не выбрасывать как мусор (например, если просили набрать булыжника). */
	public java.util.function.Predicate<net.minecraft.item.ItemStack> keep = st -> false;

	/** Хватит копать — вернуться к входу и закончить. */
	public void finish() {
		if (phase == Phase.DONE || phase == Phase.RETURN_HOME) return;
		phase = Phase.RETURN_HOME;
		crumbIndex = crumbs.size() - 1;
		ore = null;
		hands.cancel();
	}

	public boolean isActive() {
		return phase != Phase.DONE;
	}

	public boolean isReturning() {
		return phase == Phase.RETURN_HOME;
	}

	public BlockPos entrance() {
		return crumbs.get(0);
	}

	/** false — закончил. */
	public boolean tick() {
		ServerWorld world = bot.getServerWorld();
		if (phase == Phase.DONE) return false;

		// --- поход к сундуку и обратно по своему туннелю
		if (tripOut || tripBack) return tickTrip();
		if (Inv.emptySlots(bot) <= 2) {
			Inv.dropExcessJunk(bot, keep);
			if (Inv.emptySlots(bot) <= 2) {
				if (store.findChest(entrance()) != null) {
					bot.say("Сумка полная, несу добычу в сундук");
					tripOut = true;
					crumbIndex = crumbs.size() - 1;
					return true;
				}
				bot.say("Сумка полная, а сундука нет. Забери добычу или покажи сундук: !склад");
				phase = Phase.DONE;
				return false;
			}
		}

		// --- нужна кирка
		if (Inv.find(bot, s -> s.getItem() instanceof PickaxeItem && Inv.healthy(s)) < 0) {
			bot.say("У меня нет целой кирки — дай кирку, и я продолжу.");
			phase = Phase.DONE;
			return false;
		}

		// --- сначала подобрать то, что выпало (руда разлетается — раньше бот часть бросал)
		if (ore == null && collectDrops()) return true;

		// --- оказался в пещере — исследовать её, а не копать свою шахту
		if (!caveDone && (phase == Phase.DESCEND || phase == Phase.TUNNEL) && --caveCheck <= 0) {
			caveCheck = 40;
			if (inCave(world)) {
				phase = Phase.EXPLORE;
				exploreTarget = null;
				noFrontier = 0;
				bot.say("Я в пещере — исследую её и беру руду, которую вижу. Свою шахту копать не буду, пока тут есть куда идти.");
				return true;
			}
		}

		// --- видимая руда важнее туннеля
		if (ore == null && --oreScan <= 0) {
			oreScan = 10;
			ore = findVisibleOre(world);
			oreTicks = 0;
		}
		if (ore != null) {
			mineOre(world);
			return true;
		}

		// --- вернуться к забою, если отошёл (за рудой в пещеру)
		if (phase != Phase.BRANCH_BACK && phase != Phase.RETURN_HOME && phase != Phase.EXPLORE && !bot.getBlockPos().equals(currentStandPos())
				&& !(stepTarget != null && nearStep())) {
			BlockPos stand = currentStandPos();
			if (bot.getPos().distanceTo(Vec3d.ofBottomCenter(stand)) < 1.6) walker.stepInto(stand);
			else walker.moveTo(stand, 0.5, false);
			return true;
		}

		switch (phase) {
			case EXPLORE -> explore(world);
			case DESCEND -> {
				if (bot.getBlockY() <= targetY) {
					phase = Phase.TUNNEL;
					bot.say("Спустился на глубину " + bot.getBlockY() + ", копаю туннели.");
					return true;
				}
				StepResult r = step(world, dir, true, true);
				if (r == StepResult.BLOCKED) {
					bot.say("Внизу опасно (лава или вода) — начинаю туннель здесь, на " + bot.getBlockY());
					phase = Phase.TUNNEL;
				}
			}
			case TUNNEL -> {
				if (mainDug >= mainLimit) {
					bot.say("Главный туннель готов (" + mainDug + " блоков). Возвращаюсь.");
					phase = Phase.RETURN_HOME;
					crumbIndex = crumbs.size() - 1;
					return true;
				}
				int spacing = Math.max(2, BuddyConfig.get().branchSpacing);
				if (mainDug > 0 && mainDug % spacing == 0 && lastBranchAt != mainDug) {
					lastBranchAt = mainDug;
					branchStart = face;
					branchDir = dir.rotateYCounterclockwise();
					branchRightDone = false;
					branchDug = 0;
					phase = Phase.BRANCH_OUT;
					return true;
				}
				StepResult r = step(world, dir, false, true);
				if (r == StepResult.MOVED) mainDug++;
				else if (r == StepResult.BLOCKED) {
					bot.say("Впереди опасно (лава или вода) — дальше не копаю. Возвращаюсь.");
					phase = Phase.RETURN_HOME;
					crumbIndex = crumbs.size() - 1;
				}
			}
			case BRANCH_OUT -> {
				if (branchDug >= BuddyConfig.get().branchLength) {
					phase = Phase.BRANCH_BACK;
					return true;
				}
				StepResult r = step(world, branchDir, false, false);
				if (r == StepResult.MOVED) branchDug++;
				else if (r == StepResult.BLOCKED) phase = Phase.BRANCH_BACK;
			}
			case BRANCH_BACK -> {
				if (branchStart == null || walker.moveTo(branchStart, 0.4, false) || bot.getBlockPos().equals(branchStart)) {
					if (branchStart != null && !bot.getBlockPos().equals(branchStart)) {
						walker.stepInto(branchStart);
						return true;
					}
					if (!branchRightDone) {
						branchRightDone = true;
						branchDir = dir.rotateYClockwise();
						branchDug = 0;
						phase = Phase.BRANCH_OUT;
					} else {
						phase = Phase.TUNNEL;
					}
				}
			}
			case RETURN_HOME -> {
				if (followCrumbs(-1)) {
					bot.say("Я у входа в шахту.");
					phase = Phase.DONE;
					return false;
				}
			}
			default -> {
			}
		}
		return true;
	}

	/**
	 * Бот в процессе шага: уже за краем текущего блока, но ещё не спустился в следующий.
	 * Раньше это считалось «ушёл с места» — бот возвращался назад и крутился на краю ямы.
	 */
	private boolean nearStep() {
		if (stepTarget == null) return false;
		BlockPos from = currentStandPos();
		Vec3d p = bot.getPos();
		double minX = Math.min(from.getX(), stepTarget.getX()) - 0.2, maxX = Math.max(from.getX(), stepTarget.getX()) + 1.2;
		double minZ = Math.min(from.getZ(), stepTarget.getZ()) - 0.2, maxZ = Math.max(from.getZ(), stepTarget.getZ()) + 1.2;
		double minY = Math.min(from.getY(), stepTarget.getY()) - 0.5, maxY = Math.max(from.getY(), stepTarget.getY()) + 1.0;
		return p.x >= minX && p.x <= maxX && p.z >= minZ && p.z <= maxZ && p.y >= minY && p.y <= maxY;
	}

	/** Где бот должен стоять для текущей фазы. */
	private BlockPos currentStandPos() {
		if (phase == Phase.BRANCH_OUT && branchStart != null) {
			return branchStart.offset(branchDir, branchDug);
		}
		return face;
	}

	// ------------------------------------------------------------------ шаг туннеля

	private enum StepResult {WORKING, MOVED, BLOCKED}

	/**
	 * Выкопать проход 1×2 на шаг в сторону d (down — лесенкой вниз) и шагнуть туда.
	 */
	private StepResult step(ServerWorld world, Direction d, boolean down, boolean main) {
		BlockPos feet = currentStandPos();
		BlockPos next = down ? feet.offset(d).down() : feet.offset(d);
		if (stepTarget == null || !stepTarget.equals(next)) {
			stepTarget = next;
			stepTicks = 0;
		}
		if (++stepTicks > 1200) { // что-то не так (бесконечный гравий, неломаемый блок)
			stepTarget = null;
			return StepResult.BLOCKED;
		}
		List<BlockPos> clear = new ArrayList<>();
		clear.add(next.up());
		clear.add(next);
		if (down) clear.add(0, next.up(2));
		// опасность: рядом с тем, что вскрываем, есть жидкость
		for (BlockPos c : clear) {
			if (!isOpen(world, c) && touchesFluid(world, c)) return StepResult.BLOCKED;
			if (world.getBlockState(c).getFluidState().isIn(net.minecraft.registry.tag.FluidTags.LAVA)) return StepResult.BLOCKED;
		}
		for (BlockPos c : clear) {
			if (isOpen(world, c)) continue;
			if (world.getBlockState(c).getHardness(world, c) < 0) return StepResult.BLOCKED; // бедрок
			walker.stop();
			hands.breakBlock(c);
			return StepResult.WORKING;
		}
		// пол: если дыра/лава — заделать
		BlockPos floor = next.down();
		BlockState fs = world.getBlockState(floor);
		if (fs.getCollisionShape(world, floor).isEmpty()) {
			if (fs.getFluidState().isIn(net.minecraft.registry.tag.FluidTags.LAVA) || fs.isAir() || fs.isReplaceable()) {
				if (!hands.place(floor, Inv::isFiller)) return StepResult.BLOCKED;
				return StepResult.WORKING;
			}
		}
		// шагнуть
		if (!walker.stepInto(next)) return StepResult.WORKING;
		stepTarget = null;
		if (phase == Phase.BRANCH_OUT) {
			// в ответвлении крошки не пишем: назад идём к branchStart
		} else {
			face = next;
			crumbs.add(next);
		}
		maybeTorch(world, next, d);
		return StepResult.MOVED;
	}

	private static boolean isOpen(ServerWorld world, BlockPos p) {
		BlockState s = world.getBlockState(p);
		return s.getCollisionShape(world, p).isEmpty() && s.getFluidState().isEmpty() && !(s.getBlock() instanceof FallingBlock);
	}

	private static boolean touchesFluid(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.values()) {
			if (!world.getFluidState(p.offset(d)).isEmpty()) return true;
		}
		return false;
	}

	private void maybeTorch(ServerWorld world, BlockPos feet, Direction d) {
		if (++torchCounter < Math.max(3, BuddyConfig.get().torchInterval)) return;
		if (world.getLightLevel(LightType.BLOCK, feet) >= 8) return;
		if (Inv.find(bot, s -> s.isOf(Items.TORCH)) < 0) {
			bot.sayOnce("notorch", "Факелы кончились — в шахте темно", 6000);
			return;
		}
		// на стену сбоку, на уровне ног
		for (Direction side : new Direction[]{d.rotateYClockwise(), d.rotateYCounterclockwise()}) {
			BlockPos wall = feet.offset(side);
			if (world.getBlockState(wall).isSolidBlock(world, wall) && world.getBlockState(feet).isAir()) {
				hands.useOn(wall, side.getOpposite(), s -> s.isOf(Items.TORCH));
				if (world.getBlockState(feet).isOf(Blocks.WALL_TORCH)) {
					torchCounter = 0;
					return;
				}
			}
		}
	}

	// ------------------------------------------------------------------ руда (только видимая)

	public static boolean isOre(BlockState s) {
		if (s.isOf(Blocks.ANCIENT_DEBRIS)) return true;
		if (s.isIn(ConventionalBlockTags.ORES)) return true;
		return Registries.BLOCK.getId(s.getBlock()).getPath().endsWith("_ore");
	}

	/**
	 * Руда, которую бот видит глазами: касается воздуха и прямой луч от глаз попадает именно в неё.
	 * Никаких сканов сквозь камень.
	 */
	@Nullable
	private BlockPos findVisibleOre(ServerWorld world) {
		Vec3d eye = bot.getEyePos();
		BlockPos center = BlockPos.ofFloored(eye);
		int r = phase == Phase.EXPLORE ? 12 : 8;
		BlockPos best = null;
		double bestD = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(center.add(-r, -r, -r), center.add(r, r, r))) {
			BlockState s = world.getBlockState(p);
			if (!isOre(s) || ignored.contains(p)) continue;
			double d = eye.squaredDistanceTo(Vec3d.ofCenter(p));
			if (d > r * r || d >= bestD) continue;
			if (!exposed(world, p)) continue;
			if (!visible(world, eye, p)) continue;
			if (!Inv.canHarvest(bot, s)) {
				ignored.add(p.toImmutable());
				bot.sayOnce("tool_" + Registries.BLOCK.getId(s.getBlock()).getPath(),
						"Вижу " + s.getBlock().getName().getString() + ", но моя кирка слабовата для неё", 6000);
				continue;
			}
			best = p.toImmutable();
			bestD = d;
		}
		return best;
	}

	private static boolean exposed(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.values()) {
			BlockPos n = p.offset(d);
			BlockState s = world.getBlockState(n);
			if (s.isAir() || s.getCollisionShape(world, n).isEmpty() && s.getFluidState().isEmpty()) return true;
		}
		return false;
	}

	private boolean visible(ServerWorld world, Vec3d eye, BlockPos p) {
		// луч в центр и в центры открытых граней — достаточно, чтобы любой из них дошёл до самой руды
		List<Vec3d> points = new ArrayList<>();
		points.add(Vec3d.ofCenter(p));
		for (Direction d : Direction.values()) points.add(Vec3d.ofCenter(p).add(Vec3d.of(d.getVector()).multiply(0.49)));
		for (Vec3d to : points) {
			BlockHitResult hit = world.raycast(new RaycastContext(eye, to, RaycastContext.ShapeType.COLLIDER,
					RaycastContext.FluidHandling.NONE, bot));
			if (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(p)) return true;
		}
		return false;
	}

	private void mineOre(ServerWorld world) {
		BlockPos p = ore;
		if (p == null) return;
		BlockState s = world.getBlockState(p);
		if (!isOre(s) || ++oreTicks > 900) {
			if (oreTicks > 900) ignored.add(p);
			ore = null;
			oreScan = 0; // сразу поискать соседей по жиле
			hands.cancel();
			return;
		}
		if (touchesFluid(world, p) && touchesLava(world, p)) {
			ignored.add(p);
			ore = null;
			return;
		}
		if (hands.inReach(p) && visible(world, bot.getEyePos(), p)) {
			walker.stop();
			if (hands.breakBlock(p)) {
				ore = null;
				oreScan = 0;
			}
			return;
		}
		walker.moveTo(p, 3.2, false);
		if (walker.failedSearches() >= 3) {
			ignored.add(p);
			ore = null;
		}
	}

	private static boolean touchesLava(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.values()) {
			if (world.getFluidState(p.offset(d)).isIn(net.minecraft.registry.tag.FluidTags.LAVA)) return true;
		}
		return false;
	}

	// ------------------------------------------------------------------ пещеры

	/** В пещере: неба не видно, а вокруг много открытого воздуха (туннель 1×2 так не выглядит). */
	private boolean inCave(ServerWorld w) {
		BlockPos c = bot.getBlockPos();
		if (w.isSkyVisible(c)) return false;
		int air = 0;
		for (BlockPos p : BlockPos.iterate(c.add(-5, -3, -5), c.add(5, 4, 5))) {
			if (w.getBlockState(p).isAir()) air++;
		}
		return air > 220;
	}

	private static long cell(BlockPos p) {
		return BlockPos.asLong(p.getX() >> 3, p.getY() >> 3, p.getZ() >> 3);
	}

	/**
	 * Ходить по пещере: выбирать видимые глазами (без рентгена) места пола, где ещё не был,
	 * с уклоном вниз, если до нужной глубины далеко. Руду по пути берёт (сканер руды работает отдельно).
	 */
	private void explore(ServerWorld w) {
		visitedCells.add(cell(bot.getBlockPos()));
		recordCrumb();
		caveTorch(w);
		boolean reached = exploreTarget != null && bot.getPos().distanceTo(Vec3d.ofBottomCenter(exploreTarget)) < 2.0;
		if (exploreTarget == null || reached || ++exploreTicks > 400 || walker.failedSearches() >= 3) {
			if (exploreTarget != null && !reached) visitedCells.add(cell(exploreTarget)); // не дойти — не пытаться снова
			exploreTarget = pickFrontier(w);
			exploreTicks = 0;
			walker.reset();
			if (exploreTarget == null) {
				if (++noFrontier >= 3) {
					caveDone = true;
					face = bot.getBlockPos();
					if (!crumbs.get(crumbs.size() - 1).equals(face)) crumbs.add(face);
					mainDug = 0;
					lastBranchAt = -1;
					stepTarget = null;
					phase = bot.getBlockY() > targetY ? Phase.DESCEND : Phase.TUNNEL;
					bot.say("Пещеру обошёл — дальше копаю свою шахту отсюда.");
				}
				return;
			}
			noFrontier = 0;
		}
		walker.moveTo(exploreTarget, 1.5, false);
	}

	/** Следующая точка пещеры, которую видно и где бот ещё не был. */
	@Nullable
	private BlockPos pickFrontier(ServerWorld w) {
		PathFinder pf = new PathFinder(w);
		Vec3d eye = bot.getEyePos();
		BlockPos c = bot.getBlockPos();
		BlockPos best = null;
		double bestScore = -Double.MAX_VALUE;
		int r = 16;
		for (int dx = -r; dx <= r; dx += 2) {
			for (int dz = -r; dz <= r; dz += 2) {
				for (int dy = -10; dy <= 6; dy++) {
					BlockPos p = c.add(dx, dy, dz);
					if (visitedCells.contains(cell(p))) continue;
					double d = Math.sqrt(p.getSquaredDistance(c));
					if (d < 5 || d > r + 2) continue;
					if (!pf.standable(p) || w.isSkyVisible(p)) continue;
					if (p.getSquaredDistance(entrance()) > 96 * 96) continue;
					// видно ли это место (луч от глаз до точки над полом)
					Vec3d to = Vec3d.ofCenter(p);
					var hit = w.raycast(new RaycastContext(eye, to, RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.ANY, bot));
					if (hit.getType() == HitResult.Type.BLOCK && hit.getPos().squaredDistanceTo(to) > 1.0) continue;
					if (w.getFluidState(p).isIn(net.minecraft.registry.tag.FluidTags.LAVA)) continue;
					double score = d;
					if (bot.getBlockY() > targetY) score += (c.getY() - p.getY()) * 1.5; // вглубь, если ещё высоко
					score += bot.getRandom().nextDouble() * 3;
					if (score > bestScore) {
						bestScore = score;
						best = p.toImmutable();
					}
				}
			}
		}
		return best;
	}

	private void recordCrumb() {
		BlockPos last = crumbs.get(crumbs.size() - 1);
		BlockPos now = bot.getBlockPos();
		if ((bot.isOnGround() || bot.isTouchingWater()) && now.getSquaredDistance(last) >= 9) crumbs.add(now.toImmutable());
	}

	/** В тёмной пещере — факел под ноги время от времени. */
	private void caveTorch(ServerWorld w) {
		if (++caveTorchCounter < 60) return;
		caveTorchCounter = 0;
		BlockPos feet = bot.getBlockPos();
		if (w.getLightLevel(LightType.BLOCK, feet) >= 7 || !w.getBlockState(feet).isAir()) return;
		if (!w.getBlockState(feet.down()).isSolidBlock(w, feet.down())) return;
		if (Inv.find(bot, s -> s.isOf(Items.TORCH)) < 0) return;
		hands.useOn(feet.down(), Direction.UP, s -> s.isOf(Items.TORCH));
	}

	// ------------------------------------------------------------------ подбор выпавшего

	/** Подобрать выпавшую руду и прочее полезное рядом (мусорный камень не гоняется). */
	private boolean collectDrops() {
		if (Inv.emptySlots(bot) == 0) return false;
		if (pickup != null && (!pickup.isAlive() || ++pickupTicks > 160)) {
			if (pickup.isAlive()) skipItems.add(pickup.getId());
			pickup = null;
		}
		if (pickup == null) {
			net.minecraft.util.math.Box area = bot.getBoundingBox().expand(7, 4, 7);
			double best = Double.MAX_VALUE;
			for (net.minecraft.entity.ItemEntity e : bot.getWorld().getEntitiesByClass(net.minecraft.entity.ItemEntity.class, area,
					e -> !e.cannotPickup() && !skipItems.contains(e.getId()) && (!Inv.isJunk(e.getStack()) || keep.test(e.getStack())))) {
				if (e.getWorld().getFluidState(e.getBlockPos()).isIn(net.minecraft.registry.tag.FluidTags.LAVA)) continue;
				double d = e.squaredDistanceTo(bot);
				if (d < best) {
					best = d;
					pickup = e;
				}
			}
			pickupTicks = 0;
			if (pickup == null) return false;
		}
		walker.approach(pickup.getPos(), 0.5);
		return true;
	}

	// ------------------------------------------------------------------ поход к сундуку

	/** Идти по крошкам: dir=-1 — к выходу, +1 — к забою. true — дошли до конца. */
	private boolean followCrumbs(int step) {
		if (crumbIndex < 0) crumbIndex = 0;
		if (crumbIndex >= crumbs.size()) crumbIndex = crumbs.size() - 1;
		BlockPos c = crumbs.get(crumbIndex);
		boolean at = bot.getBlockPos().equals(c) || bot.getPos().distanceTo(Vec3d.ofBottomCenter(c)) < 0.7;
		if (!at) {
			if (bot.getPos().distanceTo(Vec3d.ofBottomCenter(c)) < 1.8) walker.stepInto(c);
			else walker.moveTo(c, 0.5, false);
			return false;
		}
		int nextIdx = crumbIndex + step;
		if (nextIdx < 0 || nextIdx >= crumbs.size()) return true;
		crumbIndex = nextIdx;
		return false;
	}

	private boolean tickTrip() {
		if (tripOut) {
			if (!followCrumbs(-1)) return true;
			// у входа — к сундуку
			if (store.unload(entrance())) return true;
			tripOut = false;
			tripBack = true;
			crumbIndex = 0;
			if (Inv.emptySlots(bot) <= 2) {
				bot.say("Сундук полон — заканчиваю шахту.");
				phase = Phase.DONE;
				tripBack = false;
				return false;
			}
			return true;
		}
		// обратно к забою
		if (crumbIndex == 0 && bot.getPos().distanceTo(Vec3d.ofBottomCenter(entrance())) > 2) {
			walker.moveTo(entrance(), 0.6, false);
			return true;
		}
		if (followCrumbs(+1)) {
			tripBack = false;
			bot.say("Вернулся в забой, копаю дальше");
		}
		return true;
	}
}
