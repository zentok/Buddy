package com.buddy.ai;

import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import net.fabricmc.fabric.api.tag.convention.v1.ConventionalBlockTags;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.FallingBlock;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;
import net.minecraft.registry.Registries;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.LightType;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Шахта БЕЗ рентгена.
 * <p>
 * Бот не знает, где руда под землёй. Он копает как игрок: лесенкой вниз до нужной высоты, потом главный туннель
 * 1×2 с боковыми ответвлениями (branch mining). Руду он берёт только ту, которую ВИДИТ: блок руды должен
 * касаться воздуха, а луч от глаз бота до него не должен упираться в другой блок. Так он находит руду
 * в стенах своего туннеля (и всю жилу дальше — она открывается по мере добычи) и в пещерах, куда выкопался.
 * <p>
 * Безопасность: не вскрывает блоки рядом с лавой/водой, заделывает дыры в полу, перекапывает осыпавшийся гравий,
 * ставит факелы, лишний камень выбрасывает, полный инвентарь уносит в сундук по своему же туннелю и возвращается.
 */
public class MineJob {
	private enum Phase {DESCEND, TUNNEL, BRANCH_OUT, BRANCH_BACK, RETURN_HOME, DONE}

	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Storekeeper store;
	private final int targetY;
	private final Direction dir;

	private Phase phase;
	/** Путь «хлебных крошек» от входа до забоя — по нему бот ходит туда и обратно. */
	private final List<BlockPos> crumbs = new ArrayList<>();
	private BlockPos face;
	private int mainDug;
	private int lastBranchAt = -1;
	private Direction branchDir;
	private boolean branchRightDone;
	private int branchDug;
	@Nullable
	private BlockPos branchStart;
	private int torchCounter;

	@Nullable
	private BlockPos ore;
	private int oreTicks;
	private int oreScan;
	private final Set<BlockPos> ignored = new HashSet<>();
	@Nullable
	private BlockPos stepTarget;
	private int stepTicks;

	// разгрузка
	private boolean tripOut;
	private boolean tripBack;
	private int crumbIndex;

	public MineJob(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, Direction dir, int targetY) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.store = store;
		this.dir = dir.getAxis().isHorizontal() ? dir : Direction.NORTH;
		this.targetY = targetY;
		this.face = bot.getBlockPos();
		this.crumbs.add(face);
		this.phase = bot.getBlockY() > targetY ? Phase.DESCEND : Phase.TUNNEL;
		this.branchDir = this.dir.rotateYCounterclockwise();
	}

	public BlockPos entrance() {
		return crumbs.get(0);
	}

	/** false — закончил. */
	public boolean tick() {
		ServerWorld world = bot.getServerWorld();
		if (phase == Phase.DONE) return false;

		// --- поход к сундуку и обратно по своему туннелю
		if (tripOut || tripBack) return tickTrip();
		if (Inv.emptySlots(bot) <= 2) {
			Inv.dropExcessJunk(bot);
			if (Inv.emptySlots(bot) <= 2) {
				if (store.findChest(entrance()) != null) {
					bot.say("Сумка полная, несу добычу в сундук");
					tripOut = true;
					crumbIndex = crumbs.size() - 1;
					return true;
				}
				bot.say("Сумка полная, а сундука нет. Забери добычу или покажи сундук: !склад");
				phase = Phase.DONE;
				return false;
			}
		}

		// --- нужна кирка
		if (Inv.find(bot, s -> s.getItem() instanceof PickaxeItem && Inv.healthy(s)) < 0) {
			bot.say("У меня нет целой кирки — дай кирку, и я продолжу.");
			phase = Phase.DONE;
			return false;
		}

		// --- видимая руда важнее туннеля
		if (ore == null && --oreScan <= 0) {
			oreScan = 10;
			ore = findVisibleOre(world);
			oreTicks = 0;
		}
		if (ore != null) {
			mineOre(world);
			return true;
		}

		// --- вернуться к забою, если отошёл (за рудой в пещеру)
		if (phase != Phase.BRANCH_BACK && phase != Phase.RETURN_HOME && !bot.getBlockPos().equals(currentStandPos())
				&& !(stepTarget != null && bot.getBlockPos().equals(stepTarget))) {
			BlockPos stand = currentStandPos();
			if (bot.getPos().distanceTo(Vec3d.ofBottomCenter(stand)) < 1.6) walker.stepInto(stand);
			else walker.moveTo(stand, 0.5, false);
			return true;
		}

		switch (phase) {
			case DESCEND -> {
				if (bot.getBlockY() <= targetY) {
					phase = Phase.TUNNEL;
					bot.say("Спустился на глубину " + bot.getBlockY() + ", копаю туннели.");
					return true;
				}
				StepResult r = step(world, dir, true, true);
				if (r == StepResult.BLOCKED) {
					bot.say("Внизу опасно (лава или вода) — начинаю туннель здесь, на " + bot.getBlockY());
					phase = Phase.TUNNEL;
				}
			}
			case TUNNEL -> {
				if (mainDug >= BuddyConfig.get().mainTunnelLength) {
					bot.say("Главный туннель готов (" + mainDug + " блоков). Возвращаюсь.");
					phase = Phase.RETURN_HOME;
					crumbIndex = crumbs.size() - 1;
					return true;
				}
				int spacing = Math.max(2, BuddyConfig.get().branchSpacing);
				if (mainDug > 0 && mainDug % spacing == 0 && lastBranchAt != mainDug) {
					lastBranchAt = mainDug;
					branchStart = face;
					branchDir = dir.rotateYCounterclockwise();
					branchRightDone = false;
					branchDug = 0;
					phase = Phase.BRANCH_OUT;
					return true;
				}
				StepResult r = step(world, dir, false, true);
				if (r == StepResult.MOVED) mainDug++;
				else if (r == StepResult.BLOCKED) {
					bot.say("Впереди опасно (лава или вода) — дальше не копаю. Возвращаюсь.");
					phase = Phase.RETURN_HOME;
					crumbIndex = crumbs.size() - 1;
				}
			}
			case BRANCH_OUT -> {
				if (branchDug >= BuddyConfig.get().branchLength) {
					phase = Phase.BRANCH_BACK;
					return true;
				}
				StepResult r = step(world, branchDir, false, false);
				if (r == StepResult.MOVED) branchDug++;
				else if (r == StepResult.BLOCKED) phase = Phase.BRANCH_BACK;
			}
			case BRANCH_BACK -> {
				if (branchStart == null || walker.moveTo(branchStart, 0.4, false) || bot.getBlockPos().equals(branchStart)) {
					if (branchStart != null && !bot.getBlockPos().equals(branchStart)) {
						walker.stepInto(branchStart);
						return true;
					}
					if (!branchRightDone) {
						branchRightDone = true;
						branchDir = dir.rotateYClockwise();
						branchDug = 0;
						phase = Phase.BRANCH_OUT;
					} else {
						phase = Phase.TUNNEL;
					}
				}
			}
			case RETURN_HOME -> {
				if (followCrumbs(-1)) {
					bot.say("Я у входа в шахту.");
					phase = Phase.DONE;
					return false;
				}
			}
			default -> {
			}
		}
		return true;
	}

	/** Где бот должен стоять для текущей фазы. */
	private BlockPos currentStandPos() {
		if (phase == Phase.BRANCH_OUT && branchStart != null) {
			return branchStart.offset(branchDir, branchDug);
		}
		return face;
	}

	// ------------------------------------------------------------------ шаг туннеля

	private enum StepResult {WORKING, MOVED, BLOCKED}

	/**
	 * Выкопать проход 1×2 на шаг в сторону d (down — лесенкой вниз) и шагнуть туда.
	 */
	private StepResult step(ServerWorld world, Direction d, boolean down, boolean main) {
		BlockPos feet = currentStandPos();
		BlockPos next = down ? feet.offset(d).down() : feet.offset(d);
		if (stepTarget == null || !stepTarget.equals(next)) {
			stepTarget = next;
			stepTicks = 0;
		}
		if (++stepTicks > 1200) { // что-то не так (бесконечный гравий, неломаемый блок)
			stepTarget = null;
			return StepResult.BLOCKED;
		}
		List<BlockPos> clear = new ArrayList<>();
		clear.add(next.up());
		clear.add(next);
		if (down) clear.add(0, next.up(2));
		// опасность: рядом с тем, что вскрываем, есть жидкость
		for (BlockPos c : clear) {
			if (!isOpen(world, c) && touchesFluid(world, c)) return StepResult.BLOCKED;
			if (world.getBlockState(c).getFluidState().isIn(net.minecraft.registry.tag.FluidTags.LAVA)) return StepResult.BLOCKED;
		}
		for (BlockPos c : clear) {
			if (isOpen(world, c)) continue;
			if (world.getBlockState(c).getHardness(world, c) < 0) return StepResult.BLOCKED; // бедрок
			walker.stop();
			hands.breakBlock(c);
			return StepResult.WORKING;
		}
		// пол: если дыра/лава — заделать
		BlockPos floor = next.down();
		BlockState fs = world.getBlockState(floor);
		if (fs.getCollisionShape(world, floor).isEmpty()) {
			if (fs.getFluidState().isIn(net.minecraft.registry.tag.FluidTags.LAVA) || fs.isAir() || fs.isReplaceable()) {
				if (!hands.place(floor, Inv::isFiller)) return StepResult.BLOCKED;
				return StepResult.WORKING;
			}
		}
		// шагнуть
		if (!walker.stepInto(next)) return StepResult.WORKING;
		stepTarget = null;
		if (phase == Phase.BRANCH_OUT) {
			// в ответвлении крошки не пишем: назад идём к branchStart
		} else {
			face = next;
			crumbs.add(next);
		}
		maybeTorch(world, next, d);
		return StepResult.MOVED;
	}

	private static boolean isOpen(ServerWorld world, BlockPos p) {
		BlockState s = world.getBlockState(p);
		return s.getCollisionShape(world, p).isEmpty() && s.getFluidState().isEmpty() && !(s.getBlock() instanceof FallingBlock);
	}

	private static boolean touchesFluid(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.values()) {
			if (!world.getFluidState(p.offset(d)).isEmpty()) return true;
		}
		return false;
	}

	private void maybeTorch(ServerWorld world, BlockPos feet, Direction d) {
		if (++torchCounter < Math.max(3, BuddyConfig.get().torchInterval)) return;
		if (world.getLightLevel(LightType.BLOCK, feet) >= 8) return;
		if (Inv.find(bot, s -> s.isOf(Items.TORCH)) < 0) {
			bot.sayOnce("notorch", "Факелы кончились — в шахте темно", 6000);
			return;
		}
		// на стену сбоку, на уровне ног
		for (Direction side : new Direction[]{d.rotateYClockwise(), d.rotateYCounterclockwise()}) {
			BlockPos wall = feet.offset(side);
			if (world.getBlockState(wall).isSolidBlock(world, wall) && world.getBlockState(feet).isAir()) {
				hands.useOn(wall, side.getOpposite(), s -> s.isOf(Items.TORCH));
				if (world.getBlockState(feet).isOf(Blocks.WALL_TORCH)) {
					torchCounter = 0;
					return;
				}
			}
		}
	}

	// ------------------------------------------------------------------ руда (только видимая)

	public static boolean isOre(BlockState s) {
		if (s.isOf(Blocks.ANCIENT_DEBRIS)) return true;
		if (s.isIn(ConventionalBlockTags.ORES)) return true;
		return Registries.BLOCK.getId(s.getBlock()).getPath().endsWith("_ore");
	}

	/**
	 * Руда, которую бот видит глазами: касается воздуха и прямой луч от глаз попадает именно в неё.
	 * Никаких сканов сквозь камень.
	 */
	@Nullable
	private BlockPos findVisibleOre(ServerWorld world) {
		Vec3d eye = bot.getEyePos();
		BlockPos center = BlockPos.ofFloored(eye);
		int r = 8;
		BlockPos best = null;
		double bestD = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(center.add(-r, -r, -r), center.add(r, r, r))) {
			BlockState s = world.getBlockState(p);
			if (!isOre(s) || ignored.contains(p)) continue;
			double d = eye.squaredDistanceTo(Vec3d.ofCenter(p));
			if (d > r * r || d >= bestD) continue;
			if (!exposed(world, p)) continue;
			if (!visible(world, eye, p)) continue;
			if (!Inv.canHarvest(bot, s)) {
				ignored.add(p.toImmutable());
				bot.sayOnce("tool_" + Registries.BLOCK.getId(s.getBlock()).getPath(),
						"Вижу " + s.getBlock().getName().getString() + ", но моя кирка слабовата для неё", 6000);
				continue;
			}
			best = p.toImmutable();
			bestD = d;
		}
		return best;
	}

	private static boolean exposed(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.values()) {
			BlockPos n = p.offset(d);
			BlockState s = world.getBlockState(n);
			if (s.isAir() || s.getCollisionShape(world, n).isEmpty() && s.getFluidState().isEmpty()) return true;
		}
		return false;
	}

	private boolean visible(ServerWorld world, Vec3d eye, BlockPos p) {
		// луч в центр и в центры открытых граней — достаточно, чтобы любой из них дошёл до самой руды
		List<Vec3d> points = new ArrayList<>();
		points.add(Vec3d.ofCenter(p));
		for (Direction d : Direction.values()) points.add(Vec3d.ofCenter(p).add(Vec3d.of(d.getVector()).multiply(0.49)));
		for (Vec3d to : points) {
			BlockHitResult hit = world.raycast(new RaycastContext(eye, to, RaycastContext.ShapeType.COLLIDER,
					RaycastContext.FluidHandling.NONE, bot));
			if (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(p)) return true;
		}
		return false;
	}

	private void mineOre(ServerWorld world) {
		BlockPos p = ore;
		if (p == null) return;
		BlockState s = world.getBlockState(p);
		if (!isOre(s) || ++oreTicks > 900) {
			if (oreTicks > 900) ignored.add(p);
			ore = null;
			oreScan = 0; // сразу поискать соседей по жиле
			hands.cancel();
			return;
		}
		if (touchesFluid(world, p) && touchesLava(world, p)) {
			ignored.add(p);
			ore = null;
			return;
		}
		if (hands.inReach(p) && visible(world, bot.getEyePos(), p)) {
			walker.stop();
			if (hands.breakBlock(p)) {
				ore = null;
				oreScan = 0;
			}
			return;
		}
		walker.moveTo(p, 3.2, false);
		if (walker.failedSearches() >= 3) {
			ignored.add(p);
			ore = null;
		}
	}

	private static boolean touchesLava(ServerWorld world, BlockPos p) {
		for (Direction d : Direction.values()) {
			if (world.getFluidState(p.offset(d)).isIn(net.minecraft.registry.tag.FluidTags.LAVA)) return true;
		}
		return false;
	}

	// ------------------------------------------------------------------ поход к сундуку

	/** Идти по крошкам: dir=-1 — к выходу, +1 — к забою. true — дошли до конца. */
	private boolean followCrumbs(int step) {
		if (crumbIndex < 0) crumbIndex = 0;
		if (crumbIndex >= crumbs.size()) crumbIndex = crumbs.size() - 1;
		BlockPos c = crumbs.get(crumbIndex);
		boolean at = bot.getBlockPos().equals(c) || bot.getPos().distanceTo(Vec3d.ofBottomCenter(c)) < 0.7;
		if (!at) {
			if (bot.getPos().distanceTo(Vec3d.ofBottomCenter(c)) < 1.8) walker.stepInto(c);
			else walker.moveTo(c, 0.5, false);
			return false;
		}
		int nextIdx = crumbIndex + step;
		if (nextIdx < 0 || nextIdx >= crumbs.size()) return true;
		crumbIndex = nextIdx;
		return false;
	}

	private boolean tickTrip() {
		if (tripOut) {
			if (!followCrumbs(-1)) return true;
			// у входа — к сундуку
			if (store.unload(entrance())) return true;
			tripOut = false;
			tripBack = true;
			crumbIndex = 0;
			if (Inv.emptySlots(bot) <= 2) {
				bot.say("Сундук полон — заканчиваю шахту.");
				phase = Phase.DONE;
				tripBack = false;
				return false;
			}
			return true;
		}
		// обратно к забою
		if (crumbIndex == 0 && bot.getPos().distanceTo(Vec3d.ofBottomCenter(entrance())) > 2) {
			walker.moveTo(entrance(), 0.6, false);
			return true;
		}
		if (followCrumbs(+1)) {
			tripBack = false;
			bot.say("Вернулся в забой, копаю дальше");
		}
		return true;
	}
}
