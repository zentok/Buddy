package com.buddy.ai;

import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.ScaffoldingBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Поиск пути для бота-игрока (A*). Узел — блок, где стоят ноги бота.
 * Умеет: ходить, по диагонали, шагать на блок вверх, спрыгивать до 3 блоков, плавать, лезть по лестницам,
 * проходить через деревянные двери и калитки. Обходит лаву, огонь, кактусы, ягоды и механизмы Create.
 */
public final class PathFinder {
	public static final int MAX_DROP = 3;

	private final ServerWorld world;
	private final Map<BlockPos, BlockState> cache = new HashMap<>();

	public PathFinder(ServerWorld world) {
		this.world = world;
	}

	private BlockState state(BlockPos p) {
		return cache.computeIfAbsent(p, world::getBlockState);
	}

	private boolean loaded(BlockPos p) {
		return world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4);
	}

	// ------------------------------------------------------------------ свойства блоков

	public static boolean isDangerous(BlockState s) {
		if (s.isOf(Blocks.LAVA) || s.isOf(Blocks.FIRE) || s.isOf(Blocks.SOUL_FIRE) || s.isOf(Blocks.MAGMA_BLOCK)
				|| s.isOf(Blocks.CACTUS) || s.isOf(Blocks.SWEET_BERRY_BUSH) || s.isOf(Blocks.WITHER_ROSE)
				|| s.isOf(Blocks.POWDER_SNOW) || s.isOf(Blocks.COBWEB) || s.isOf(Blocks.POINTED_DRIPSTONE)) return true;
		if (s.getBlock() instanceof CampfireBlock) return true;
		if (s.getFluidState().isIn(FluidTags.LAVA)) return true;
		// механизмы Create (пилы, буры, ремни, валы) — не ходить по ним и не задевать
		String ns = Registries.BLOCK.getId(s.getBlock()).getNamespace();
		return ns.equals("create") && !s.isOpaqueFullCube(net.minecraft.world.EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
	}

	private static boolean isOpenable(BlockState s) {
		if (s.getBlock() instanceof DoorBlock) return s.isIn(BlockTags.WOODEN_DOORS);
		return s.getBlock() instanceof FenceGateBlock;
	}

	private static boolean isClimbable(BlockState s) {
		return s.getBlock() instanceof LadderBlock || s.getBlock() instanceof VineBlock || s.getBlock() instanceof ScaffoldingBlock
				|| s.isIn(BlockTags.CLIMBABLE);
	}

	private boolean isWater(BlockPos p) {
		return state(p).getFluidState().isIn(FluidTags.WATER);
	}

	/** Можно ли находиться в этом блоке (нет твёрдой коллизии и не опасно). */
	private boolean passable(BlockPos p) {
		BlockState s = state(p);
		if (isDangerous(s)) return false;
		if (isOpenable(s)) return true;
		if (s.getBlock() instanceof AbstractRailBlock) return true;
		return s.getCollisionShape(world, p).isEmpty();
	}

	/** Ноги и голова помещаются. */
	private boolean bodyFits(BlockPos feet) {
		return passable(feet) && passable(feet.up());
	}

	/** На блок можно встать сверху (полная или почти полная опора, не выше 1 блока). */
	private boolean solidTop(BlockPos p) {
		BlockState s = state(p);
		if (isDangerous(s) || isOpenable(s)) return false;
		VoxelShape shape = s.getCollisionShape(world, p);
		if (shape.isEmpty()) return false;
		double top = shape.getMax(Direction.Axis.Y);
		return top >= 0.5 && top <= 1.0;
	}

	/** Можно стоять ногами в этом блоке. */
	public boolean standable(BlockPos feet) {
		if (!loaded(feet) || !bodyFits(feet)) return false;
		if (solidTop(feet.down())) return true;
		if (isWater(feet)) return true;
		return isClimbable(state(feet));
	}

	// ------------------------------------------------------------------ «как Baritone»: копать и ставить блоки

	/** Можно ли ломать блоки на пути (копать ступеньки, проходы). */
	private boolean canBreak;
	/** Сколько блоков можно поставить под себя (столбом наверх). */
	private int blocksToPlace;

	/** Разрешить боту менять мир по пути: копать природные блоки и ставить блоки под себя. */
	public PathFinder allowWorldEdits(boolean canBreak, int blocksToPlace) {
		this.canBreak = canBreak;
		this.blocksToPlace = Math.max(0, blocksToPlace);
		return this;
	}

	/**
	 * Природный блок, который можно сломать по пути: земля, камень, песок, гравий, листва, снег, незерак…
	 * Постройки (доски, стекло, кирпич, сундуки, механизмы) бот на пути НЕ ломает.
	 */
	public boolean breakable(BlockPos p) {
		BlockState s = state(p);
		if (s.isAir() || passable(p)) return false;
		if (isDangerous(s) || s.hasBlockEntity()) return false;
		float hard = s.getHardness(world, p);
		if (hard < 0 || hard > 4) return false;
		boolean natural = s.isIn(BlockTags.BASE_STONE_OVERWORLD) || s.isIn(BlockTags.BASE_STONE_NETHER) || s.isIn(BlockTags.DIRT)
				|| s.isIn(BlockTags.SAND) || s.isIn(BlockTags.LEAVES) || s.isIn(BlockTags.SNOW) || s.isIn(BlockTags.TERRACOTTA)
				|| s.isOf(Blocks.GRAVEL) || s.isOf(Blocks.CLAY) || s.isOf(Blocks.COBBLESTONE) || s.isOf(Blocks.COBBLED_DEEPSLATE)
				|| s.isOf(Blocks.SANDSTONE) || s.isOf(Blocks.RED_SANDSTONE) || s.isOf(Blocks.CALCITE) || s.isOf(Blocks.SMOOTH_BASALT)
				|| s.isOf(Blocks.DRIPSTONE_BLOCK) || s.isOf(Blocks.MOSS_BLOCK) || s.isOf(Blocks.ICE) || s.isOf(Blocks.PACKED_ICE)
				|| s.isOf(Blocks.SOUL_SAND) || s.isOf(Blocks.SOUL_SOIL) || s.isOf(Blocks.END_STONE) || s.isOf(Blocks.MUD)
				|| s.isOf(Blocks.SNOW_BLOCK) || s.isOf(Blocks.GLOWSTONE) || s.isIn(BlockTags.NYLIUM);
		if (!natural) return false;
		// не вскрывать воду/лаву
		for (Direction d : Direction.values()) {
			if (!world.getFluidState(p.offset(d)).isEmpty()) return false;
		}
		return true;
	}

	/** Свободно или можно расчистить. */
	private boolean clearable(BlockPos p) {
		return passable(p) || (canBreak && breakable(p));
	}

	/** Цена расчистки (0 — уже свободно). */
	private double digCost(BlockPos p) {
		if (passable(p)) return 0;
		BlockState s = state(p);
		return 1.5 + s.getHardness(world, p) * 3.0;
	}

	// ------------------------------------------------------------------ A*

	/** Как попасть в узел: пройти, расчистить и пройти, подняться столбом, прокопать вниз. */
	public enum Move {WALK, DIG, PILLAR, DIG_DOWN}

	/** Шаг пути: куда встать, как туда попасть и что сломать перед этим. */
	public record Step(BlockPos pos, Move move, List<BlockPos> clear) {
	}

	private record Node(BlockPos pos, double g, double f, @Nullable Node parent, Move move, List<BlockPos> clear, int placed) {
	}

	private static final Direction[] HORIZ = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

	/** Путь от start к goal (подойти ближе чем на reach). null — если не нашли. */
	@Nullable
	public List<Step> find(BlockPos start, BlockPos goal, double reach, int maxNodes) {
		BlockPos s = start;
		if (!standable(s)) {
			for (int i = 1; i <= 3 && !standable(s); i++) s = start.down(i);
			if (!standable(s)) s = start;
		}
		PriorityQueue<Node> open = new PriorityQueue<>((a, b) -> Double.compare(a.f, b.f));
		Map<BlockPos, Double> best = new HashMap<>();
		Node first = new Node(s, 0, h(s, goal), null, Move.WALK, List.of(), 0);
		open.add(first);
		best.put(s, 0.0);
		Node closest = first;
		int expanded = 0;
		double reachSq = reach * reach;
		while (!open.isEmpty() && expanded < maxNodes) {
			Node n = open.poll();
			if (n.g > best.getOrDefault(n.pos, Double.MAX_VALUE)) continue;
			expanded++;
			if (n.pos.getSquaredDistance(goal) <= reachSq) return build(n);
			if (n.f - n.g < closest.f - closest.g) closest = n;
			for (Node m : neighbors(n, goal)) {
				if (m.g < best.getOrDefault(m.pos, Double.MAX_VALUE)) {
					best.put(m.pos, m.g);
					open.add(m);
				}
			}
		}
		// не дошли — ведём хотя бы к ближайшей точке, если она заметно ближе старта
		if (closest != first && closest.pos.getSquaredDistance(goal) < s.getSquaredDistance(goal) - 9) return build(closest);
		return null;
	}

	private static double h(BlockPos a, BlockPos b) {
		return Math.sqrt(a.getSquaredDistance(b));
	}

	private Node step(Node from, BlockPos to, double cost, BlockPos goal) {
		return step(from, to, cost, goal, Move.WALK, List.of(), 0);
	}

	private Node step(Node from, BlockPos to, double cost, BlockPos goal, Move move, List<BlockPos> clear, int place) {
		double g = from.g + cost;
		return new Node(to, g, g + h(to, goal), from, move, clear, from.placed + place);
	}

	private List<Node> neighbors(Node n, BlockPos goal) {
		List<Node> out = new ArrayList<>(16);
		BlockPos p = n.pos;
		boolean inWater = isWater(p);
		for (Direction d : HORIZ) {
			BlockPos side = p.offset(d);
			if (standable(side)) {
				out.add(step(n, side, inWater || isWater(side) ? 2.0 : 1.0, goal));
				continue;
			}
			// шаг вверх на блок
			BlockPos up = side.up();
			if (passable(p.up(2)) && standable(up)) {
				out.add(step(n, up, 2.0, goal));
				continue;
			}
			// спрыгнуть вниз
			boolean dropped = false;
			if (bodyFits(side)) {
				for (int k = 1; k <= MAX_DROP; k++) {
					BlockPos down = side.down(k);
					if (!passable(down)) break;
					if (standable(down)) {
						out.add(step(n, down, 1.0 + k * 0.6, goal));
						dropped = true;
						break;
					}
				}
			}
			if (!canBreak || dropped || !loaded(side)) continue;
			// прокопать проход вперёд (пол есть)
			if (solidTop(side.down()) && clearable(side) && clearable(side.up())) {
				out.add(step(n, side, 1.0 + digCost(side) + digCost(side.up()), goal, Move.DIG,
						List.of(side.up(), side), 0));
			}
			// прокопать ступеньку вверх (как лесенка из ямы)
			if (solidTop(side) && clearable(up) && clearable(up.up()) && clearable(p.up(2))) {
				out.add(step(n, up, 2.0 + digCost(p.up(2)) + digCost(up.up()) + digCost(up), goal, Move.DIG,
						List.of(p.up(2), up.up(), up), 0));
			}
		}
		// диагонали — только если обе соседние клетки свободны (не срезаем углы)
		for (int i = 0; i < 4; i++) {
			Direction a = HORIZ[i < 2 ? 0 : 1];
			Direction b = HORIZ[2 + (i % 2)];
			BlockPos diag = p.offset(a).offset(b);
			if (standable(diag) && bodyFits(p.offset(a)) && bodyFits(p.offset(b))) {
				out.add(step(n, diag, 1.45, goal));
			}
		}
		// вертикаль: лестницы, лианы, вода
		BlockState here = state(p);
		if (isClimbable(here) || inWater) {
			BlockPos up = p.up();
			if (bodyFits(up) && (isClimbable(state(up)) || isWater(up) || standable(up))) out.add(step(n, up, 1.5, goal));
			BlockPos down = p.down();
			if (bodyFits(down) && (isClimbable(state(down)) || isWater(down))) out.add(step(n, down, 1.2, goal));
		} else {
			// подняться столбом: прыгнуть и поставить блок под себя
			if (n.placed < blocksToPlace && solidTop(p.down()) && passable(p.up()) && clearable(p.up(2))) {
				out.add(step(n, p.up(), 4.0 + digCost(p.up(2)), goal, Move.PILLAR,
						passable(p.up(2)) ? List.of() : List.of(p.up(2)), 1));
			}
			// прокопать вниз (только если цель ниже)
			if (canBreak && goal.getY() < p.getY() && breakable(p.down()) && solidTop(p.down(2)) && !isDangerous(state(p.down(2)))) {
				out.add(step(n, p.down(), 2.5 + digCost(p.down()), goal, Move.DIG_DOWN, List.of(p.down()), 0));
			}
		}
		return out;
	}

	private static List<Step> build(Node end) {
		List<Step> path = new ArrayList<>();
		for (Node n = end; n != null; n = n.parent) path.add(new Step(n.pos, n.move, n.clear));
		Collections.reverse(path);
		return path;
	}
}
