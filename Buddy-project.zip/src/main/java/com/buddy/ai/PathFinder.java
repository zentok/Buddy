package com.buddy.ai;

import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.CampfireBlock;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.block.LadderBlock;
import net.minecraft.block.ScaffoldingBlock;
import net.minecraft.block.VineBlock;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.BlockTags;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

/**
 * Поиск пути для бота-игрока (A*). Узел — блок, где стоят ноги бота.
 * Умеет: ходить, по диагонали, шагать на блок вверх, спрыгивать до 3 блоков, плавать, лезть по лестницам,
 * проходить через деревянные двери и калитки. Обходит лаву, огонь, кактусы, ягоды и механизмы Create.
 */
public final class PathFinder {
	public static final int MAX_DROP = 3;

	private final ServerWorld world;
	private final Map<BlockPos, BlockState> cache = new HashMap<>();

	public PathFinder(ServerWorld world) {
		this.world = world;
	}

	private BlockState state(BlockPos p) {
		return cache.computeIfAbsent(p, world::getBlockState);
	}

	private boolean loaded(BlockPos p) {
		return world.isChunkLoaded(p.getX() >> 4, p.getZ() >> 4);
	}

	// ------------------------------------------------------------------ свойства блоков

	public static boolean isDangerous(BlockState s) {
		if (s.isOf(Blocks.LAVA) || s.isOf(Blocks.FIRE) || s.isOf(Blocks.SOUL_FIRE) || s.isOf(Blocks.MAGMA_BLOCK)
				|| s.isOf(Blocks.CACTUS) || s.isOf(Blocks.SWEET_BERRY_BUSH) || s.isOf(Blocks.WITHER_ROSE)
				|| s.isOf(Blocks.POWDER_SNOW) || s.isOf(Blocks.COBWEB) || s.isOf(Blocks.POINTED_DRIPSTONE)) return true;
		if (s.getBlock() instanceof CampfireBlock) return true;
		if (s.getFluidState().isIn(FluidTags.LAVA)) return true;
		// механизмы Create (пилы, буры, ремни, валы) — не ходить по ним и не задевать
		String ns = Registries.BLOCK.getId(s.getBlock()).getNamespace();
		return ns.equals("create") && !s.isOpaqueFullCube(net.minecraft.world.EmptyBlockView.INSTANCE, BlockPos.ORIGIN);
	}

	private static boolean isOpenable(BlockState s) {
		if (s.getBlock() instanceof DoorBlock) return s.isIn(BlockTags.WOODEN_DOORS);
		return s.getBlock() instanceof FenceGateBlock;
	}

	private static boolean isClimbable(BlockState s) {
		return s.getBlock() instanceof LadderBlock || s.getBlock() instanceof VineBlock || s.getBlock() instanceof ScaffoldingBlock
				|| s.isIn(BlockTags.CLIMBABLE);
	}

	private boolean isWater(BlockPos p) {
		return state(p).getFluidState().isIn(FluidTags.WATER);
	}

	/** Можно ли находиться в этом блоке (нет твёрдой коллизии и не опасно). */
	private boolean passable(BlockPos p) {
		BlockState s = state(p);
		if (isDangerous(s)) return false;
		if (isOpenable(s)) return true;
		if (s.getBlock() instanceof AbstractRailBlock) return true;
		return s.getCollisionShape(world, p).isEmpty();
	}

	/** Ноги и голова помещаются. */
	private boolean bodyFits(BlockPos feet) {
		return passable(feet) && passable(feet.up());
	}

	/** На блок можно встать сверху (полная или почти полная опора, не выше 1 блока). */
	private boolean solidTop(BlockPos p) {
		BlockState s = state(p);
		if (isDangerous(s) || isOpenable(s)) return false;
		VoxelShape shape = s.getCollisionShape(world, p);
		if (shape.isEmpty()) return false;
		double top = shape.getMax(Direction.Axis.Y);
		return top >= 0.5 && top <= 1.0;
	}

	/** Можно стоять ногами в этом блоке. */
	public boolean standable(BlockPos feet) {
		if (!loaded(feet) || !bodyFits(feet)) return false;
		if (solidTop(feet.down())) return true;
		if (isWater(feet)) return true;
		return isClimbable(state(feet));
	}

	// ------------------------------------------------------------------ A*

	private record Node(BlockPos pos, double g, double f, @Nullable Node parent) {
	}

	private static final Direction[] HORIZ = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};

	/** Путь от start к goal (подойти ближе чем на reach). null — если не нашли. */
	@Nullable
	public List<BlockPos> find(BlockPos start, BlockPos goal, double reach, int maxNodes) {
		BlockPos s = start;
		if (!standable(s)) {
			for (int i = 1; i <= 3 && !standable(s); i++) s = start.down(i);
			if (!standable(s)) s = start;
		}
		PriorityQueue<Node> open = new PriorityQueue<>((a, b) -> Double.compare(a.f, b.f));
		Map<BlockPos, Double> best = new HashMap<>();
		Node first = new Node(s, 0, h(s, goal), null);
		open.add(first);
		best.put(s, 0.0);
		Node closest = first;
		int expanded = 0;
		double reachSq = reach * reach;
		while (!open.isEmpty() && expanded < maxNodes) {
			Node n = open.poll();
			if (n.g > best.getOrDefault(n.pos, Double.MAX_VALUE)) continue;
			expanded++;
			if (n.pos.getSquaredDistance(goal) <= reachSq) return build(n);
			if (n.f - n.g < closest.f - closest.g) closest = n;
			for (Node m : neighbors(n, goal)) {
				if (m.g < best.getOrDefault(m.pos, Double.MAX_VALUE)) {
					best.put(m.pos, m.g);
					open.add(m);
				}
			}
		}
		// не дошли — ведём хотя бы к ближайшей точке, если она заметно ближе старта
		if (closest != first && closest.pos.getSquaredDistance(goal) < s.getSquaredDistance(goal) - 9) return build(closest);
		return null;
	}

	private static double h(BlockPos a, BlockPos b) {
		return Math.sqrt(a.getSquaredDistance(b));
	}

	private Node step(Node from, BlockPos to, double cost, BlockPos goal) {
		double g = from.g + cost;
		return new Node(to, g, g + h(to, goal), from);
	}

	private List<Node> neighbors(Node n, BlockPos goal) {
		List<Node> out = new ArrayList<>(12);
		BlockPos p = n.pos;
		boolean inWater = isWater(p);
		for (Direction d : HORIZ) {
			BlockPos side = p.offset(d);
			if (standable(side)) {
				out.add(step(n, side, inWater || isWater(side) ? 2.0 : 1.0, goal));
				continue;
			}
			// шаг вверх на блок
			BlockPos up = side.up();
			if (passable(p.up(2)) && standable(up)) {
				out.add(step(n, up, 2.0, goal));
				continue;
			}
			// спрыгнуть вниз
			if (bodyFits(side)) {
				for (int k = 1; k <= MAX_DROP; k++) {
					BlockPos down = side.down(k);
					if (!passable(down)) break;
					if (standable(down)) {
						out.add(step(n, down, 1.0 + k * 0.6, goal));
						break;
					}
				}
			}
		}
		// диагонали — только если обе соседние клетки свободны (не срезаем углы)
		for (int i = 0; i < 4; i++) {
			Direction a = HORIZ[i < 2 ? 0 : 1];
			Direction b = HORIZ[2 + (i % 2)];
			BlockPos diag = p.offset(a).offset(b);
			if (standable(diag) && bodyFits(p.offset(a)) && bodyFits(p.offset(b))) {
				out.add(step(n, diag, 1.45, goal));
			}
		}
		// вертикаль: лестницы, лианы, вода
		BlockState here = state(p);
		if (isClimbable(here) || inWater) {
			BlockPos up = p.up();
			if (bodyFits(up) && (isClimbable(state(up)) || isWater(up) || standable(up))) out.add(step(n, up, 1.5, goal));
			BlockPos down = p.down();
			if (bodyFits(down) && (isClimbable(state(down)) || isWater(down))) out.add(step(n, down, 1.2, goal));
		}
		return out;
	}

	private static List<BlockPos> build(Node end) {
		List<BlockPos> path = new ArrayList<>();
		for (Node n = end; n != null; n = n.parent) path.add(n.pos);
		Collections.reverse(path);
		return path;
	}
}
