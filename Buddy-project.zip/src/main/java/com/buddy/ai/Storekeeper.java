package com.buddy.ai;

import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.minecraft.block.BlockState;
import net.minecraft.block.ChestBlock;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.jetbrains.annotations.Nullable;

/** Отнести добычу в сундук: назначенный (!склад) или ближайший к месту работы. */
public class Storekeeper {
	private final BuddyPlayer bot;
	private final Walker walker;
	@Nullable
	private BlockPos chest;
	private int fullCooldown;
	private int walkTicks;

	public Storekeeper(BuddyPlayer bot, Walker walker) {
		this.bot = bot;
		this.walker = walker;
	}

	public static boolean isStorage(ServerWorld world, BlockPos pos) {
		return ItemStorage.SIDED.find(world, pos, Direction.UP) != null;
	}

	/** Сколько предметов бот отдал бы в сундук. */
	public int storableCount() {
		int n = 0;
		for (var s : bot.getInventory().main) {
			if (s.isEmpty() || Inv.isTool(s) || Inv.isFood(s) || Inv.isSeed(s) || Inv.isFiller(s)
					|| s.isOf(net.minecraft.item.Items.TORCH)) continue;
			n += s.getCount();
		}
		return n;
	}

	public boolean wantsToUnload(int threshold) {
		if (fullCooldown > 0) {
			fullCooldown--;
			return false;
		}
		return storableCount() > 0 && (Inv.emptySlots(bot) <= 3 || storableCount() >= threshold);
	}

	/** Найти, куда нести: назначенный склад или ближайший сундук/бочка рядом с near. */
	@Nullable
	public BlockPos findChest(BlockPos near) {
		ServerWorld world = bot.getServerWorld();
		BlockPos assigned = bot.getStoragePos();
		if (assigned != null && isStorage(world, assigned)) return assigned;
		int r = BuddyConfig.get().chestSearchRadius;
		BlockPos best = null;
		double bestD = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(near.add(-r, -4, -r), near.add(r, 4, r))) {
			BlockEntity be = world.getBlockEntity(p);
			if (!(be instanceof ChestBlockEntity) && !(be instanceof BarrelBlockEntity)) continue;
			if (be.getClass().getName().toLowerCase().contains("lootr")) continue; // не трогаем сундуки с добычей
			double d = p.getSquaredDistance(near);
			if (d < bestD) {
				bestD = d;
				best = p.toImmutable();
			}
		}
		return best;
	}

	/**
	 * Тик разгрузки. true — ещё занят (идёт/кладёт), false — закончил (или некуда класть).
	 */
	public boolean unload(BlockPos near) {
		ServerWorld world = bot.getServerWorld();
		if (chest == null || !isStorage(world, chest)) {
			chest = findChest(near);
			walkTicks = 0;
			if (chest == null) {
				bot.sayOnce("nochest", "Некуда сложить добычу — поставь сундук рядом или покажи его: !склад", 2400);
				fullCooldown = 600;
				return false;
			}
		}
		if (bot.getEyePos().squaredDistanceTo(net.minecraft.util.math.Vec3d.ofCenter(chest)) > 3.5 * 3.5) {
			walker.moveTo(chest, 2.5, false);
			if (++walkTicks > 600 || walker.failedSearches() >= 4) {
				bot.sayOnce("chestfar", "Не могу дойти до сундука", 2400);
				chest = null;
				fullCooldown = 600;
				return false;
			}
			return true;
		}
		walker.stop();
		new Hands(bot).lookAt(net.minecraft.util.math.Vec3d.ofCenter(chest));
		BlockState st = world.getBlockState(chest);
		animate(world, chest, st, true);
		int moved = Inv.depositInto(bot, world, chest);
		animate(world, chest, st, false);
		if (moved <= 0 && Inv.emptySlots(bot) <= 3) {
			bot.sayOnce("chestfull", "Сундук полон!", 2400);
			fullCooldown = 1200;
		}
		chest = null;
		return false;
	}

	private static void animate(ServerWorld world, BlockPos pos, BlockState st, boolean open) {
		if (st.getBlock() instanceof ChestBlock) {
			world.addSyncedBlockEvent(pos, st.getBlock(), 1, open ? 1 : 0);
			world.playSound(null, pos, open ? SoundEvents.BLOCK_CHEST_OPEN : SoundEvents.BLOCK_CHEST_CLOSE, SoundCategory.BLOCKS, 0.5f, 1f);
		} else {
			world.playSound(null, pos, open ? SoundEvents.BLOCK_BARREL_OPEN : SoundEvents.BLOCK_BARREL_CLOSE, SoundCategory.BLOCKS, 0.5f, 1f);
		}
	}
}
