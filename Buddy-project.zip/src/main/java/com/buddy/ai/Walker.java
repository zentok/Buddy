package com.buddy.ai;

import com.buddy.BuddyPlayer;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/** «Ноги» бота: строит путь и ведёт по нему, нажимая вперёд/прыжок/спринт как игрок. */
public class Walker {
	private final BuddyPlayer bot;
	@Nullable
	private List<BlockPos> path;
	private int index;
	@Nullable
	private BlockPos pathGoal;
	private int repathTimer;
	private int failedSearches;
	private int stuckCount;
	private int stuckTimer;
	private Vec3d lastCheckPos = Vec3d.ZERO;
	private final List<BlockPos> openedDoors = new ArrayList<>();

	public Walker(BuddyPlayer bot) {
		this.bot = bot;
	}

	public void reset() {
		path = null;
		pathGoal = null;
		index = 0;
		stuckCount = 0;
		failedSearches = 0;
		stop();
	}

	public void stop() {
		bot.forwardSpeed = 0;
		bot.sidewaysSpeed = 0;
		bot.setJumping(false);
		bot.setSprinting(false);
		closeDoorsBehind(true);
	}

	public boolean isStuck() {
		return stuckCount >= 4;
	}

	public int failedSearches() {
		return failedSearches;
	}

	/** Идти к цели. true — уже на месте (ближе reach). */
	public boolean moveTo(BlockPos goal, double reach, boolean sprint) {
		ServerWorld world = bot.getServerWorld();
		Vec3d goalCenter = Vec3d.ofBottomCenter(goal);
		if (bot.getPos().distanceTo(goalCenter) <= reach) {
			stop();
			path = null;
			return true;
		}
		if (path == null || --repathTimer <= 0 || pathGoal == null || pathGoal.getSquaredDistance(goal) > 4) {
			path = new PathFinder(world).find(bot.getBlockPos(), goal, Math.max(1.5, reach - 0.5), 4000);
			pathGoal = goal;
			repathTimer = 30;
			index = 0;
			if (path == null) failedSearches++;
			else {
				failedSearches = 0;
				if (!path.isEmpty() && path.get(0).equals(bot.getBlockPos())) index = 1;
			}
		}
		if (path == null) {
			walkToward(goalCenter, sprint, goal.getY() > bot.getY() + 0.5);
		} else {
			followPath(sprint);
		}
		checkStuck();
		closeDoorsBehind(false);
		return false;
	}

	private void followPath(boolean sprint) {
		if (path == null) return;
		while (index < path.size()) {
			BlockPos node = path.get(index);
			double dx = node.getX() + 0.5 - bot.getX();
			double dz = node.getZ() + 0.5 - bot.getZ();
			double hd = Math.sqrt(dx * dx + dz * dz);
			double dy = node.getY() - bot.getY();
			boolean supported = bot.isOnGround() || bot.isTouchingWater() || bot.isClimbing();
			if (hd < 0.4 && Math.abs(dy) < 1.2 && supported) {
				index++;
				continue;
			}
			break;
		}
		if (index >= path.size()) {
			path = null;
			bot.forwardSpeed = 0;
			return;
		}
		BlockPos node = path.get(index);
		openDoorsAhead();
		Vec3d target = Vec3d.ofBottomCenter(node);
		walkToward(target, sprint, node.getY() > bot.getY() + 0.5);
	}

	private void walkToward(Vec3d target, boolean sprint, boolean needUp) {
		double dx = target.x - bot.getX();
		double dz = target.z - bot.getZ();
		double hd = Math.sqrt(dx * dx + dz * dz);
		if (hd > 0.05) {
			float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
			bot.setYaw(yaw);
			bot.setHeadYaw(yaw);
			bot.setBodyYaw(yaw);
		}
		bot.setPitch(0);
		bot.forwardSpeed = hd < 0.25 ? 0f : (hd < 0.7 ? 0.5f : 1.0f);
		boolean jump = false;
		if (bot.isOnGround() && (needUp || bot.horizontalCollision)) jump = true;
		if (bot.isTouchingWater() && (needUp || bot.horizontalCollision || target.y >= bot.getY() - 0.2)) jump = true;
		if (bot.isClimbing() && needUp) jump = true;
		bot.setJumping(jump);
		boolean canSprint = sprint && hd > 3 && bot.getHungerManager().getFoodLevel() > 6 && !bot.isTouchingWater()
				&& !bot.isUsingItem();
		bot.setSprinting(canSprint);
	}

	private void checkStuck() {
		if (++stuckTimer < 20) return;
		stuckTimer = 0;
		Vec3d now = bot.getPos();
		if (bot.forwardSpeed > 0 && now.distanceTo(lastCheckPos) < 0.3) {
			stuckCount++;
			path = null; // перестроить путь
		} else {
			stuckCount = 0;
		}
		lastCheckPos = now;
	}

	// ------------------------------------------------------------------ двери

	private void openDoorsAhead() {
		if (path == null) return;
		ServerWorld world = bot.getServerWorld();
		for (int i = index; i < Math.min(index + 2, path.size()); i++) {
			for (BlockPos p : new BlockPos[]{path.get(i), path.get(i).up()}) {
				BlockState s = world.getBlockState(p);
				if (s.getBlock() instanceof DoorBlock door && s.isIn(net.minecraft.registry.tag.BlockTags.WOODEN_DOORS) && !s.get(DoorBlock.OPEN)) {
					door.setOpen(bot, world, s, p, true);
					remember(s.get(DoorBlock.HALF) == net.minecraft.block.enums.DoubleBlockHalf.UPPER ? p.down() : p);
				} else if (s.getBlock() instanceof FenceGateBlock && !s.get(FenceGateBlock.OPEN)) {
					world.setBlockState(p, s.with(FenceGateBlock.OPEN, true), 10);
					world.playSound(null, p, SoundEvents.BLOCK_FENCE_GATE_OPEN, SoundCategory.BLOCKS, 1f, 1f);
					world.emitGameEvent(bot, GameEvent.BLOCK_OPEN, p);
					remember(p);
				}
			}
		}
	}

	private void remember(BlockPos p) {
		if (!openedDoors.contains(p)) openedDoors.add(p.toImmutable());
	}

	/** Закрыть двери, которые бот открыл и уже прошёл. */
	private void closeDoorsBehind(boolean all) {
		if (openedDoors.isEmpty()) return;
		ServerWorld world = bot.getServerWorld();
		openedDoors.removeIf(p -> {
			if (!all && bot.getPos().squaredDistanceTo(Vec3d.ofCenter(p)) < 2.5 * 2.5) return false;
			BlockState s = world.getBlockState(p);
			if (s.getBlock() instanceof DoorBlock door && s.get(DoorBlock.OPEN)) {
				door.setOpen(bot, world, s, p, false);
			} else if (s.getBlock() instanceof FenceGateBlock && s.get(FenceGateBlock.OPEN)) {
				world.setBlockState(p, s.with(Properties.OPEN, false), 10);
				world.playSound(null, p, SoundEvents.BLOCK_FENCE_GATE_CLOSE, SoundCategory.BLOCKS, 1f, 1f);
				world.emitGameEvent(bot, GameEvent.BLOCK_CLOSE, p);
			}
			return true;
		});
	}
}
