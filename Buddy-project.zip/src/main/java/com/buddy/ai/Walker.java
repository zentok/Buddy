package com.buddy.ai;

import com.buddy.BuddyPlayer;
import net.minecraft.block.BlockState;
import net.minecraft.block.DoorBlock;
import net.minecraft.block.FenceGateBlock;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.state.property.Properties;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.event.GameEvent;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/** «Ноги» бота: строит путь и ведёт по нему, нажимая вперёд/прыжок/спринт как игрок. */
public class Walker {
	private final BuddyPlayer bot;
	@Nullable
	private List<PathFinder.Step> path;
	/** Можно ли сейчас копать/ставить блоки по пути (в шахте бот копает сам по своему плану). */
	public boolean worldEdits = true;
	private int index;
	@Nullable
	private BlockPos pathGoal;
	private int repathTimer;
	private int failedSearches;
	private int stuckCount;
	private int stuckTimer;
	private Vec3d lastCheckPos = Vec3d.ZERO;
	private final List<BlockPos> openedDoors = new ArrayList<>();

	public Walker(BuddyPlayer bot) {
		this.bot = bot;
	}

	public void reset() {
		path = null;
		pathGoal = null;
		index = 0;
		stuckCount = 0;
		failedSearches = 0;
		stop();
	}

	public void stop() {
		bot.forwardSpeed = 0;
		bot.sidewaysSpeed = 0;
		bot.setJumping(false);
		bot.setSprinting(false);
		closeDoorsBehind(true);
	}

	public boolean isStuck() {
		return stuckCount >= 4;
	}

	public int failedSearches() {
		return failedSearches;
	}

	/** Идти к цели. true — уже на месте (ближе reach). */
	public boolean moveTo(BlockPos goal, double reach, boolean sprint) {
		ServerWorld world = bot.getServerWorld();
		Vec3d goalCenter = Vec3d.ofBottomCenter(goal);
		if (bot.getPos().distanceTo(goalCenter) <= reach) {
			stop();
			path = null;
			return true;
		}
		// совсем рядом и на одном уровне — просто подойти, без поиска пути
		// (иначе поиск пути «считает, что уже дошёл» в 1.5 блока и бот замирает, не подобрав предмет)
		double hx = goalCenter.x - bot.getX(), hz = goalCenter.z - bot.getZ();
		if (hx * hx + hz * hz < 2.5 * 2.5 && Math.abs(goal.getY() - bot.getY()) < 1.2 && directOk(goal)) {
			path = null;
			walkToward(goalCenter, false, goal.getY() > bot.getY() + 0.5);
			if (bot.forwardSpeed == 0f) bot.forwardSpeed = 0.4f;
			checkStuck();
			return false;
		}
		if (path == null || --repathTimer <= 0 || pathGoal == null || pathGoal.getSquaredDistance(goal) > 4) {
			com.buddy.BuddyConfig cfg = com.buddy.BuddyConfig.get();
			int blocks = worldEdits && cfg.pathPillar ? Inv.count(bot, Inv::isFiller) : 0;
			path = new PathFinder(world).allowWorldEdits(worldEdits && cfg.pathDig, blocks)
					.find(bot.getBlockPos(), goal, Math.max(1.0, reach - 0.5), 4000);
			pathGoal = goal;
			repathTimer = 30;
			index = 0;
			if (path == null) failedSearches++;
			else {
				failedSearches = 0;
				if (!path.isEmpty() && path.get(0).pos().equals(bot.getBlockPos())) index = 1;
			}
		}
		if (path == null) {
			walkToward(goalCenter, sprint, goal.getY() > bot.getY() + 0.5);
		} else {
			followPath(sprint);
		}
		checkStuck();
		closeDoorsBehind(false);
		return false;
	}

	private void followPath(boolean sprint) {
		if (path == null) return;
		while (index < path.size()) {
			BlockPos node = path.get(index).pos();
			double dx = node.getX() + 0.5 - bot.getX();
			double dz = node.getZ() + 0.5 - bot.getZ();
			double hd = Math.sqrt(dx * dx + dz * dz);
			double dy = node.getY() - bot.getY();
			boolean supported = bot.isOnGround() || bot.isTouchingWater() || bot.isClimbing();
			boolean vertical = path.get(index).move() == PathFinder.Move.PILLAR || path.get(index).move() == PathFinder.Move.DIG_DOWN;
			boolean arrived = vertical ? bot.getBlockPos().equals(node) && supported
					: (hd < 0.4 && Math.abs(dy) < (bot.isTouchingWater() ? 1.0 : 0.6) && supported) || (bot.getBlockPos().equals(node) && hd < 0.4);
			if (arrived) {
				index++;
				continue;
			}
			break;
		}
		if (index >= path.size()) {
			path = null;
			bot.forwardSpeed = 0;
			return;
		}
		PathFinder.Step st = path.get(index);
		BlockPos node = st.pos();
		// расчистить проход (ступенька из ямы, проход сквозь землю)
		ServerWorld w = bot.getServerWorld();
		for (BlockPos c : st.clear()) {
			if (isClear(w, c)) continue;
			bot.forwardSpeed = 0;
			bot.setJumping(false);
			bot.setSprinting(false);
			Hands hands = bot.hands();
			if (!hands.inReach(c)) { // не дотягиваемся — подойти поближе к шагу
				walkToward(Vec3d.ofBottomCenter(index > 0 ? path.get(index - 1).pos() : node), false, false);
				return;
			}
			hands.breakBlock(c);
			if (hands.hardFail()) path = null;
			return;
		}
		if (st.move() == PathFinder.Move.PILLAR) {
			pillar(w, node.down());
			return;
		}
		if (st.move() == PathFinder.Move.DIG_DOWN) {
			bot.forwardSpeed = 0;
			return; // блок под ногами сломан — падаем на шаг вниз
		}
		openDoorsAhead();
		Vec3d target = Vec3d.ofBottomCenter(node);
		walkToward(target, sprint, node.getY() > bot.getY() + 0.5);
	}

	private static boolean isClear(ServerWorld w, BlockPos c) {
		BlockState s = w.getBlockState(c);
		return s.getCollisionShape(w, c).isEmpty() && s.getFluidState().isEmpty()
				&& !(s.getBlock() instanceof net.minecraft.block.FallingBlock);
	}

	/** Подняться на блок: прыгнуть и в прыжке поставить блок под себя (как игрок «столбом»). */
	private void pillar(ServerWorld w, BlockPos base) {
		Vec3d c = Vec3d.ofBottomCenter(base);
		double dx = c.x - bot.getX(), dz = c.z - bot.getZ();
		bot.setSprinting(false);
		if (dx * dx + dz * dz > 0.2 * 0.2) { // встать по центру блока
			float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
			bot.setYaw(yaw);
			bot.setHeadYaw(yaw);
			bot.forwardSpeed = 0.25f;
		} else bot.forwardSpeed = 0;
		bot.setPitch(90);
		if (bot.getY() >= base.getY() + 1.0 && w.getBlockState(base).isReplaceable()) {
			bot.setJumping(false);
			if (!bot.hands().place(base, Inv::isFiller)) path = null; // нечего ставить — перестроить путь
			return;
		}
		bot.setJumping(bot.isOnGround() && bot.getY() < base.getY() + 0.5);
	}

	/** Прямой путь к близкой цели свободен (нет стены/обрыва между). */
	private boolean directOk(BlockPos goal) {
		ServerWorld w = bot.getServerWorld();
		BlockPos from = bot.getBlockPos();
		int steps = Math.max(Math.abs(goal.getX() - from.getX()), Math.abs(goal.getZ() - from.getZ()));
		for (int i = 1; i <= steps; i++) {
			int x = from.getX() + Math.round((goal.getX() - from.getX()) * i / (float) steps);
			int z = from.getZ() + Math.round((goal.getZ() - from.getZ()) * i / (float) steps);
			BlockPos p = new BlockPos(x, Math.max(from.getY(), goal.getY()), z);
			if (!w.getBlockState(p).getCollisionShape(w, p).isEmpty() && !w.getBlockState(p.up()).getCollisionShape(w, p.up()).isEmpty()) return false;
			if (!w.getBlockState(p.up()).getCollisionShape(w, p.up()).isEmpty()) return false;
			BlockPos below = new BlockPos(x, Math.min(from.getY(), goal.getY()) - 1, z);
			if (w.getBlockState(below).getCollisionShape(w, below).isEmpty() && w.getBlockState(below.down()).getCollisionShape(w, below.down()).isEmpty()
					&& !w.getFluidState(below).isIn(net.minecraft.registry.tag.FluidTags.WATER)) return false; // яма
			if (PathFinder.isDangerous(w.getBlockState(p)) || PathFinder.isDangerous(w.getBlockState(below))) return false;
		}
		return true;
	}

	/** Подойти к точной точке (подобрать предмет). true — уже рядом. */
	public boolean approach(Vec3d target, double reach) {
		if (bot.getPos().distanceTo(target) <= reach) {
			bot.forwardSpeed = 0;
			return true;
		}
		BlockPos b = BlockPos.ofFloored(target);
		double hx = target.x - bot.getX(), hz = target.z - bot.getZ();
		if (hx * hx + hz * hz < 2.5 * 2.5 && Math.abs(target.y - bot.getY()) < 1.2 && directOk(b)) {
			path = null;
			walkToward(target, false, target.y > bot.getY() + 0.6);
			if (bot.forwardSpeed == 0f) bot.forwardSpeed = 0.4f;
			checkStuck();
			return false;
		}
		moveTo(b, reach, false);
		return false;
	}

	/** Шагнуть прямо к точке без поиска пути (для коротких шагов в туннеле). true — уже стоим в этом блоке. */
	public boolean stepInto(BlockPos target) {
		if (bot.getBlockPos().equals(target) && (bot.isOnGround() || bot.isTouchingWater())) {
			double dx = target.getX() + 0.5 - bot.getX();
			double dz = target.getZ() + 0.5 - bot.getZ();
			if (dx * dx + dz * dz < 0.3 * 0.3) {
				bot.forwardSpeed = 0;
				bot.setJumping(false);
				return true;
			}
		}
		walkToward(Vec3d.ofBottomCenter(target), false, target.getY() > bot.getY() + 0.5);
		if (bot.forwardSpeed > 0.5f) bot.forwardSpeed = 0.6f;
		return false;
	}

	private void walkToward(Vec3d target, boolean sprint, boolean needUp) {
		double dx = target.x - bot.getX();
		double dz = target.z - bot.getZ();
		double hd = Math.sqrt(dx * dx + dz * dz);
		if (hd > 0.05) {
			float yaw = (float) (MathHelper.atan2(dz, dx) * (180.0 / Math.PI)) - 90.0f;
			bot.setYaw(yaw);
			bot.setHeadYaw(yaw);
			bot.setBodyYaw(yaw);
		}
		bot.setPitch(0);
		bot.forwardSpeed = hd < 0.25 ? 0f : (hd < 0.7 ? 0.5f : 1.0f);
		boolean jump = false;
		if (bot.isOnGround() && (needUp || bot.horizontalCollision)) jump = true;
		if (bot.isTouchingWater() && (needUp || bot.horizontalCollision || target.y >= bot.getY() - 0.2)) jump = true;
		if (bot.isClimbing() && needUp) jump = true;
		bot.setJumping(jump);
		boolean canSprint = sprint && hd > 3 && bot.getHungerManager().getFoodLevel() > 6 && !bot.isTouchingWater()
				&& !bot.isUsingItem();
		bot.setSprinting(canSprint);
	}

	private void checkStuck() {
		if (++stuckTimer < 20) return;
		stuckTimer = 0;
		Vec3d now = bot.getPos();
		if (bot.forwardSpeed > 0 && now.distanceTo(lastCheckPos) < 0.3) {
			stuckCount++;
			path = null; // перестроить путь
		} else {
			stuckCount = 0;
		}
		lastCheckPos = now;
	}

	// ------------------------------------------------------------------ двери

	private void openDoorsAhead() {
		if (path == null) return;
		ServerWorld world = bot.getServerWorld();
		for (int i = index; i < Math.min(index + 2, path.size()); i++) {
			for (BlockPos p : new BlockPos[]{path.get(i).pos(), path.get(i).pos().up()}) {
				BlockState s = world.getBlockState(p);
				if (s.getBlock() instanceof DoorBlock door && s.isIn(net.minecraft.registry.tag.BlockTags.WOODEN_DOORS) && !s.get(DoorBlock.OPEN)) {
					door.setOpen(bot, world, s, p, true);
					remember(s.get(DoorBlock.HALF) == net.minecraft.block.enums.DoubleBlockHalf.UPPER ? p.down() : p);
				} else if (s.getBlock() instanceof FenceGateBlock && !s.get(FenceGateBlock.OPEN)) {
					world.setBlockState(p, s.with(FenceGateBlock.OPEN, true), 10);
					world.playSound(null, p, SoundEvents.BLOCK_FENCE_GATE_OPEN, SoundCategory.BLOCKS, 1f, 1f);
					world.emitGameEvent(bot, GameEvent.BLOCK_OPEN, p);
					remember(p);
				}
			}
		}
	}

	private void remember(BlockPos p) {
		if (!openedDoors.contains(p)) openedDoors.add(p.toImmutable());
	}

	/** Закрыть двери, которые бот открыл и уже прошёл. */
	private void closeDoorsBehind(boolean all) {
		if (openedDoors.isEmpty()) return;
		ServerWorld world = bot.getServerWorld();
		openedDoors.removeIf(p -> {
			if (!all && bot.getPos().squaredDistanceTo(Vec3d.ofCenter(p)) < 2.5 * 2.5) return false;
			BlockState s = world.getBlockState(p);
			if (s.getBlock() instanceof DoorBlock door && s.get(DoorBlock.OPEN)) {
				door.setOpen(bot, world, s, p, false);
			} else if (s.getBlock() instanceof FenceGateBlock && s.get(FenceGateBlock.OPEN)) {
				world.setBlockState(p, s.with(Properties.OPEN, false), 10);
				world.playSound(null, p, SoundEvents.BLOCK_FENCE_GATE_CLOSE, SoundCategory.BLOCKS, 1f, 1f);
				world.emitGameEvent(bot, GameEvent.BLOCK_CLOSE, p);
			}
			return true;
		});
	}
}
