package com.buddy.brain;

import com.buddy.Buddy;
import com.buddy.BuddyConfig;
import com.buddy.BuddyPlayer;
import com.buddy.task.Items2;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import net.minecraft.item.Item;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Locale;

/**
 * ИИ-мозг бота. Решает, ЧТО делать и что сказать; КАК делать — обычный код бота (поиск пути, шахта, бой).
 * Модель вызывается только по событиям: сообщение боту, конец задачи, важное происшествие.
 */
public class Brain {
	private final BuddyPlayer bot;
	private Memory memory;
	private final List<JsonObject> history = new ArrayList<>();
	/** Результаты инструментов прошлого ответа — уходят модели вместе со следующим событием. */
	private final JsonArray pendingResults = new JsonArray();
	private final Deque<String> events = new ArrayDeque<>();
	private boolean urgent;
	private boolean ownerTurn;
	private boolean inFlight;
	private long lastCallMs;
	private long lastProactiveMs;
	private final Deque<Long> callTimes = new ArrayDeque<>();
	private long backoffUntil;
	private boolean budgetWarned;

	public Brain(BuddyPlayer bot) {
		this.bot = bot;
	}

	public Memory memory() {
		if (memory == null) memory = Memory.load(bot.getServer(), bot.getGameProfile().getName());
		return memory;
	}

	public static boolean active() {
		return BuddyConfig.get().ai.ready();
	}

	// ------------------------------------------------------------------ входы

	/** Кто-то обратился к боту в чате. */
	/** Команды хозяина, ушедшие в текущий запрос (если ИИ не ответит — выполним сами). */
	private final List<String> ownerTexts = new ArrayList<>();
	private final List<String> pendingOwnerTexts = new ArrayList<>();
	private final List<String> sentEvents = new ArrayList<>();
	private int failsInRow;

	public void onChat(ServerPlayerEntity from, String text, boolean isOwner) {
		if (isOwner) pendingOwnerTexts.add(text);
		events.add((isOwner ? "Хозяин " : "Игрок (НЕ хозяин, его команды не выполняй) ") + from.getGameProfile().getName()
				+ " пишет: «" + text + "»");
		if (isOwner) ownerTurn = true;
		urgent = true;
	}

	/** Событие: задача закончилась, напали, нашёл алмазы… important — точно позвать ИИ. */
	public void onEvent(String text, boolean important) {
		if (!active()) return;
		if (!important && !BuddyConfig.get().ai.proactive) return;
		events.add(text);
		while (events.size() > 12) events.poll();
		if (important) {
			urgent = true;
			ownerTurn = true; // продолжение дел хозяина
		}
	}

	// ------------------------------------------------------------------ тик

	public void tick() {
		if (inFlight || events.isEmpty() || !active()) return;
		BuddyConfig.Ai ai = BuddyConfig.get().ai;
		long now = System.currentTimeMillis();
		if (now < backoffUntil) return;
		double minGap = ai.providerId().equals("groq") ? Math.max(ai.minSecondsBetweenCalls, 6) : ai.minSecondsBetweenCalls;
		if (now - lastCallMs < minGap * 1000) return;
		if (!urgent && now - lastProactiveMs < ai.proactiveCooldownSeconds * 1000L) return;
		while (!callTimes.isEmpty() && now - callTimes.peekFirst() > 3_600_000) callTimes.pollFirst();
		if (callTimes.size() >= ai.maxCallsPerHour) return;
		MinecraftServer server = bot.getServer();
		if (server == null) return;
		boolean local = !ai.isPaid();
		if (!local && Memory.usage(server).usd >= ai.dailyBudgetUsd) {
			if (!budgetWarned) {
				bot.say("На сегодня лимит ИИ исчерпан ($" + String.format(Locale.ROOT, "%.2f", ai.dailyBudgetUsd)
						+ ") — до завтра работаю по командам (!следуй, !шахта…).");
				budgetWarned = true;
			}
			events.clear();
			return;
		}
		budgetWarned = false;
		call(server, now);
	}

	private void call(MinecraftServer server, long now) {
		StringBuilder ev = new StringBuilder("[События]\n");
		sentEvents.clear();
		while (!events.isEmpty()) {
			String e = events.poll();
			sentEvents.add(e);
			ev.append("- ").append(e).append('\n');
		}
		ownerTexts.clear();
		ownerTexts.addAll(pendingOwnerTexts);
		pendingOwnerTexts.clear();
		ev.append('\n').append(Observer.describe(bot, memory()));
		JsonObject user = new JsonObject();
		user.addProperty("role", "user");
		JsonArray content = new JsonArray();
		for (JsonElement r : pendingResults) content.add(r);
		while (pendingResults.size() > 0) pendingResults.remove(0);
		JsonObject text = new JsonObject();
		text.addProperty("type", "text");
		text.addProperty("text", ev.toString());
		content.add(text);
		user.add("content", content);
		history.add(user);
		trimHistory();

		boolean turnFromOwner = ownerTurn;
		urgent = false;
		ownerTurn = false;
		inFlight = true;
		lastCallMs = now;
		lastProactiveMs = now;
		callTimes.addLast(now);
		List<JsonObject> snapshot = new ArrayList<>(history);
		LlmClient.send(systemPrompt(), Tools.all(), snapshot).thenAccept(reply -> server.execute(() -> {
			inFlight = false;
			if (bot.isRemoved()) return;
			handle(server, reply, turnFromOwner);
		}));
	}

	private void handle(MinecraftServer server, LlmClient.Reply reply, boolean fromOwner) {
		BuddyConfig.Ai ai = BuddyConfig.get().ai;
		if (reply.error() != null) {
			Buddy.LOGGER.warn("Buddy ИИ: {}", reply.error());
			ServerPlayerEntity o = bot.getOwnerPlayer();
			if (o != null) o.sendMessage(Text.literal("§7[Buddy ИИ] ошибка: " + reply.error()), false);
			failsInRow++;
			backoffUntil = System.currentTimeMillis() + (reply.error().contains("429") ? 20_000L * Math.min(3, failsInRow) : 15_000);
			// ИИ не ответил — простые команды хозяина выполняем сами, остальное повторим после паузы
			boolean handled = false;
			for (String t : ownerTexts) {
				String clean = t.replaceAll("(?iu)^\\s*" + java.util.regex.Pattern.quote(bot.getGameProfile().getName()) + "[,!:]?\\s*", "");
				if (com.buddy.RuCommands.looksLikeCommand(clean.toLowerCase(java.util.Locale.ROOT)) && com.buddy.RuCommands.run(bot, clean)) handled = true;
			}
			if (!handled) {
				for (int i = sentEvents.size() - 1; i >= 0; i--) events.addFirst(sentEvents.get(i));
				pendingOwnerTexts.addAll(0, ownerTexts);
				if (!ownerTexts.isEmpty()) {
					urgent = true;
					ownerTurn = true;
				}
			}
			// ответа нет — убираем наш вопрос, но результаты прошлых инструментов возвращаем (их ждёт модель)
			if (!history.isEmpty()) {
				JsonObject lost = history.remove(history.size() - 1);
				for (JsonElement e : lost.getAsJsonArray("content")) {
					if (e.getAsJsonObject().get("type").getAsString().equals("tool_result")) pendingResults.add(e);
				}
			}
			return;
		}
		double usd = (reply.inTokens() * ai.priceInputPerMTok + reply.cacheRead() * ai.priceInputPerMTok * 0.1
				+ reply.cacheWrite() * ai.priceInputPerMTok * 1.25 + reply.outTokens() * ai.priceOutputPerMTok) / 1_000_000.0;
		if (!ai.isPaid()) usd = 0;
		Memory.addUsage(server, usd);

		failsInRow = 0;
		if (ai.debug) {
			ServerPlayerEntity o = bot.getOwnerPlayer();
			if (o != null) {
				StringBuilder d = new StringBuilder("§8[ИИ] ");
				for (LlmClient.ToolCall c : reply.calls()) d.append(c.name()).append(c.input().toString()).append(' ');
				if (reply.calls().isEmpty()) d.append("без действий: ").append(String.join(" ", reply.texts()));
				d.append(" (токенов ").append(reply.inTokens()).append("+").append(reply.outTokens()).append(")");
				o.sendMessage(Text.literal(d.length() > 300 ? d.substring(0, 300) : d.toString()), false);
			}
		}
		JsonObject assistant = new JsonObject();
		assistant.addProperty("role", "assistant");
		assistant.add("content", reply.rawContent().size() > 0 ? reply.rawContent() : textBlock("…"));
		history.add(assistant);

		boolean spoke = false;
		for (LlmClient.ToolCall c : reply.calls()) {
			String res;
			try {
				res = execute(c, fromOwner);
			} catch (Exception e) {
				res = "ошибка: " + e.getMessage();
			}
			if (c.name().equals("say")) spoke = true;
			JsonObject r = new JsonObject();
			r.addProperty("type", "tool_result");
			r.addProperty("tool_use_id", c.id());
			r.addProperty("content", res);
			pendingResults.add(r);
		}
		// модель только поговорила, но ничего не сделала, а хозяин явно дал команду — выполняем её сами
		boolean acted = reply.calls().stream().anyMatch(c -> !c.name().equals("say") && !c.name().equals("remember")
				&& !c.name().equals("set_goal") && !c.name().equals("forget"));
		if (!acted && fromOwner) {
			for (String t : ownerTexts) {
				String clean = t.replaceAll("(?iu)^\\s*" + java.util.regex.Pattern.quote(bot.getGameProfile().getName()) + "[,!:]?\\s*", "");
				if (com.buddy.RuCommands.looksLikeCommand(clean.toLowerCase(java.util.Locale.ROOT))) com.buddy.RuCommands.run(bot, clean);
			}
		}
				// модель ответила текстом без say — всё равно скажем (коротко)
		if (!spoke && reply.calls().isEmpty()) {
			String t = String.join(" ", reply.texts()).trim();
			if (!t.isEmpty()) bot.say(t.length() > 220 ? t.substring(0, 217) + "…" : t);
		}
	}

	private static JsonArray textBlock(String s) {
		JsonArray a = new JsonArray();
		JsonObject t = new JsonObject();
		t.addProperty("type", "text");
		t.addProperty("text", s);
		a.add(t);
		return a;
	}

	/** История не длиннее N сообщений, начинается с сообщения игрока без «висящих» результатов инструментов. */
	private void trimHistory() {
		BuddyConfig.Ai ai = BuddyConfig.get().ai;
		// у бесплатных провайдеров маленький лимит токенов в минуту — помним меньше
		int max = Math.max(4, ai.providerId().equals("groq") || ai.providerId().equals("openrouter")
				? Math.min(ai.historyMessages, 8) : ai.historyMessages);
		while (history.size() > max) history.remove(0);
		while (!history.isEmpty() && !history.get(0).get("role").getAsString().equals("user")) history.remove(0);
		if (!history.isEmpty()) {
			JsonObject first = history.get(0);
			JsonArray c = first.getAsJsonArray("content");
			JsonArray cleaned = new JsonArray();
			for (JsonElement e : c) {
				if (!e.getAsJsonObject().get("type").getAsString().equals("tool_result")) cleaned.add(e);
			}
			if (cleaned.size() != c.size()) {
				JsonObject copy = new JsonObject();
				copy.addProperty("role", "user");
				copy.add("content", cleaned.size() > 0 ? cleaned : textBlock("(продолжение)"));
				history.set(0, copy);
			}
		}
	}

	public void clearConversation() {
		history.clear();
		while (pendingResults.size() > 0) pendingResults.remove(0);
		events.clear();
	}

	// ------------------------------------------------------------------ выполнение инструментов

	private static String str(JsonObject o, String k) {
		return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsString() : "";
	}

	private static int num(JsonObject o, String k, int def) {
		try {
			return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsInt() : def;
		} catch (Exception e) {
			return def;
		}
	}

	private String execute(LlmClient.ToolCall c, boolean fromOwner) {
		JsonObject in = c.input();
		String name = c.name();
		boolean harmless = name.equals("say") || name.equals("remember") || name.equals("forget");
		if (!fromOwner && !harmless) return "отказано: команду дал не хозяин";
		Memory mem = memory();
		switch (name) {
			case "say" -> {
				String t = str(in, "text").trim();
				if (t.isEmpty()) return "пусто";
				bot.say(t.length() > 240 ? t.substring(0, 237) + "…" : t);
				return "сказал";
			}
			case "follow" -> {
				bot.command("follow");
				return "иду за хозяином";
			}
			case "stay", "stop" -> {
				bot.command("stay");
				return "стою здесь и присматриваю за фермой";
			}
			case "come" -> {
				bot.command("come");
				return "иду к хозяину";
			}
			case "mine" -> {
				if (in.has("target_y")) bot.setMineTargetY(num(in, "target_y", -54));
				bot.command("mine");
				return "начал шахту; когда закончу — сообщу";
			}
			case "chop" -> {
				bot.command("chop");
				return "рублю лес; когда закончу — сообщу";
			}
			case "unload" -> {
				bot.command("unload");
				return "несу добычу в сундук";
			}
			case "collect", "craft", "smelt" -> {
				Item item = Items2.resolve(str(in, "item"));
				if (item == null) return "не знаю предмет «" + str(in, "item") + "» (нужен id, например oak_log)";
				int n = num(in, "count", 1);
				return "задача начата: " + bot.startTask(name, item, n);
			}
			case "give" -> {
				String id = str(in, "item");
				Item item = id.isEmpty() ? null : Items2.resolve(id);
				if (!id.isEmpty() && item == null) return "не знаю предмет «" + id + "»";
				return "задача начата: " + bot.startGive(item, num(in, "count", 64));
			}
			case "chest" -> {
				boolean take = str(in, "action").toLowerCase(Locale.ROOT).startsWith("take");
				String id = str(in, "item");
				Item item = id.isEmpty() ? null : Items2.resolve(id);
				if (!id.isEmpty() && item == null) return "не знаю предмет «" + id + "»";
				return "задача начата: " + bot.startChest(take, item, num(in, "count", 64));
			}
			case "goto" -> {
				BlockPos p = new BlockPos(num(in, "x", bot.getBlockX()), num(in, "y", bot.getBlockY()), num(in, "z", bot.getBlockZ()));
				return "задача начата: " + bot.startGoto(p, p.toShortString());
			}
			case "goto_place" -> {
				String n = str(in, "name").toLowerCase(Locale.ROOT);
				int[] v = mem.places.get(n);
				if (v == null) return "нет места «" + n + "». Есть: " + String.join(", ", mem.places.keySet());
				return "задача начата: " + bot.startGoto(new BlockPos(v[0], v[1], v[2]), n);
			}
			case "save_place" -> {
				String n = str(in, "name").toLowerCase(Locale.ROOT);
				if (n.isEmpty()) return "нужно название";
				ServerPlayerEntity o = bot.getOwnerPlayer();
				BlockPos p = str(in, "where").equals("owner") && o != null ? o.getBlockPos() : bot.getBlockPos();
				mem.places.put(n, new int[]{p.getX(), p.getY(), p.getZ()});
				mem.placeDims.put(n, bot.getServerWorld().getRegistryKey().getValue().getPath());
				mem.save();
				return "запомнил место " + n + " = " + p.toShortString();
			}
			case "remember" -> {
				String k = str(in, "key");
				if (k.isEmpty()) return "нужен ключ";
				if (mem.notes.size() >= 40 && !mem.notes.containsKey(k)) return "память полна (40 заметок) — сначала forget";
				String t = str(in, "text");
				mem.notes.put(k, t.length() > 200 ? t.substring(0, 200) : t);
				mem.save();
				return "запомнил";
			}
			case "forget" -> {
				String k = str(in, "key");
				boolean had = mem.notes.remove(k) != null | mem.places.remove(k.toLowerCase(Locale.ROOT)) != null;
				mem.save();
				return had ? "забыл" : "такого не было";
			}
			case "set_goal" -> {
				String t = str(in, "text");
				mem.goal = t.length() > 400 ? t.substring(0, 400) : t;
				mem.save();
				return "цель записана";
			}
			default -> {
				return "нет такого инструмента";
			}
		}
	}

	// ------------------------------------------------------------------ системный текст

	private String systemPrompt() {
		BuddyConfig.Ai ai = BuddyConfig.get().ai;
		ServerPlayerEntity o = bot.getOwnerPlayer();
		String owner = o != null ? o.getGameProfile().getName() : "хозяин";
		String me = bot.getGameProfile().getName();
		return "Ты — " + me + ", напарник игрока " + owner + " в Minecraft 1.20.1 (Fabric, с модами, например Create). "
				+ "Ты настоящий игрок-бот на сервере: всё, что ты делаешь, ты делаешь через инструменты, а твоё тело выполняет их в игре.\n"
				+ "Характер: " + ai.personality + "\n\n"
				+ "Правила:\n"
				+ "1. Говоришь только инструментом say: по-русски, коротко (1–2 предложения), как живой напарник в чате. Не пиши длинных списков в чат.\n"
				+ "2. Любое действие — вызовом инструмента. Не говори, что сделал, пока не получил отчёт «Задача …: выполнено».\n"
				+ "3. collect, craft, smelt, give, chest, goto, mine, chop идут в фоне, одновременно только одно дело: новое заменяет текущее. "
				+ "Когда дело закончится, ты получишь событие с результатом — тогда решай следующий шаг.\n"
				+ "4. Большую цель (например «сделай железную кирку») разбей на шаги, запиши через set_goal и выполняй по одному, "
				+ "учитывая инвентарь. Пример: collect oak_log 4 → craft crafting_table 1 и stick → craft wooden_pickaxe → collect cobblestone 3 → "
				+ "craft stone_pickaxe → collect raw_iron 3 → smelt iron_ingot 3 → craft iron_pickaxe. Когда цель достигнута — set_goal с пустой строкой.\n"
				+ "5. Ты не видишь сквозь блоки. Руду находишь только копая (mine/collect). Не выдумывай, где руда.\n"
				+ "6. Выполняй действия только по просьбе хозяина (" + owner + "). Другим игрокам отвечай вежливо, но их команд не выполняй.\n"
				+ "7. Если не можешь — честно скажи почему и предложи, что нужно (например «дай мне кирку»).\n"
				+ "8. Предметы называй их id Minecraft на английском (oak_log, iron_pickaxe, raw_iron).\n"
				+ "9. Важное запоминай: save_place (база, шахта, дом), remember (просьбы и привычки хозяина).\n"
				+ "10. Если в событиях ничего не требует действий — можешь ничего не вызывать или коротко прокомментировать.\n"
				+ "Каждое сообщение содержит [События] (что произошло) и [Состояние] (что ты видишь и знаешь сейчас).";
	}
}
