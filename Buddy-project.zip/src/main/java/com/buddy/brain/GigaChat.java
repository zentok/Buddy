package com.buddy.brain;

import com.buddy.Buddy;
import com.buddy.BuddyConfig;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;
import java.io.ByteArrayInputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyStore;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * GigaChat (Сбер): бесплатный тариф для физлиц, работает из России без VPN, хорошо понимает русский.
 * Ключ — «Authorization key» из личного кабинета GigaChat API (Sber Studio / developers.sber.ru).
 * <p>
 * Сервер GigaChat подписан российским корневым сертификатом Минцифры, которого нет в Java.
 * Мод один раз скачивает его с официального сайта Госуслуг в config/buddy/ и доверяет ему ТОЛЬКО для запросов к GigaChat.
 */
final class GigaChat {
	private static final String OAUTH = "https://ngw.devices.sberbank.ru:9443/api/v2/oauth";
	private static final String CHAT = "https://gigachat.devices.sberbank.ru/api/v1/chat/completions";
	private static final String[] CA_URLS = {
			"https://gu-st.ru/content/lending/russian_trusted_root_ca_pem.crt",
			"https://gu-st.ru/content/lending/russian_trusted_sub_ca_pem.crt"};

	private static HttpClient client;
	private static String token;
	private static long tokenExpires;

	private GigaChat() {
	}

	private static synchronized HttpClient client() throws Exception {
		if (client != null) return client;
		Path dir = FabricLoader.getInstance().getConfigDir().resolve("buddy");
		Files.createDirectories(dir);
		List<Certificate> extra = new ArrayList<>();
		CertificateFactory cf = CertificateFactory.getInstance("X.509");
		HttpClient plain = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
		for (String url : CA_URLS) {
			Path f = dir.resolve(url.substring(url.lastIndexOf('/') + 1));
			if (!Files.exists(f)) {
				try {
					HttpResponse<byte[]> r = plain.send(HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(20)).build(),
							HttpResponse.BodyHandlers.ofByteArray());
					if (r.statusCode() == 200) Files.write(f, r.body());
				} catch (Exception e) {
					Buddy.LOGGER.warn("Buddy: не скачал сертификат {} — положи его вручную в {}", url, f);
				}
			}
			if (Files.exists(f)) {
				try {
					Collection<? extends Certificate> cs = cf.generateCertificates(new ByteArrayInputStream(Files.readAllBytes(f)));
					extra.addAll(cs);
				} catch (Exception e) {
					Buddy.LOGGER.warn("Buddy: файл {} не похож на сертификат", f);
				}
			}
		}
		// стандартные доверенные сертификаты Java + сертификаты Минцифры
		TrustManagerFactory def = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		def.init((KeyStore) null);
		KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
		ks.load(null, null);
		int i = 0;
		for (var tm : def.getTrustManagers()) {
			if (tm instanceof X509TrustManager x) for (X509Certificate c : x.getAcceptedIssuers()) ks.setCertificateEntry("java" + (i++), c);
		}
		for (Certificate c : extra) ks.setCertificateEntry("ru" + (i++), c);
		TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
		tmf.init(ks);
		SSLContext ssl = SSLContext.getInstance("TLS");
		ssl.init(null, tmf.getTrustManagers(), null);
		client = HttpClient.newBuilder().sslContext(ssl).connectTimeout(Duration.ofSeconds(15)).build();
		return client;
	}

	private static synchronized String token(BuddyConfig.Ai ai) throws Exception {
		if (token != null && System.currentTimeMillis() < tokenExpires - 60_000) return token;
		String key = ai.apiKey().replaceFirst("(?i)^basic\\s+", "");
		HttpRequest req = HttpRequest.newBuilder(URI.create(OAUTH))
				.timeout(Duration.ofSeconds(20))
				.header("Authorization", "Basic " + key)
				.header("RqUID", UUID.randomUUID().toString())
				.header("Content-Type", "application/x-www-form-urlencoded")
				.header("Accept", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString("scope=" + ai.gigachatScope))
				.build();
		HttpResponse<String> r = client().send(req, HttpResponse.BodyHandlers.ofString());
		if (r.statusCode() != 200) throw new IllegalStateException("вход в GigaChat не удался (HTTP " + r.statusCode() + "): проверь ключ и gigachatScope");
		JsonObject j = JsonParser.parseString(r.body()).getAsJsonObject();
		token = j.get("access_token").getAsString();
		tokenExpires = j.has("expires_at") ? j.get("expires_at").getAsLong() : System.currentTimeMillis() + 25 * 60_000;
		return token;
	}

	static LlmClient.Reply send(BuddyConfig.Ai ai, String system, JsonArray tools, List<JsonObject> history) {
		try {
			JsonObject body = new JsonObject();
			body.addProperty("model", ai.model());
			body.addProperty("max_tokens", ai.maxTokens);
			JsonArray msgs = new JsonArray();
			msgs.add(msg("system", system));
			Map<String, String> idToName = new HashMap<>();
			for (JsonObject m : history) {
				String role = m.get("role").getAsString();
				JsonArray content = m.getAsJsonArray("content");
				if (role.equals("assistant")) {
					StringBuilder text = new StringBuilder();
					JsonObject call = null;
					for (JsonElement el : content) {
						JsonObject b = el.getAsJsonObject();
						String t = b.get("type").getAsString();
						if (t.equals("text")) text.append(b.get("text").getAsString());
						else if (t.equals("tool_use")) {
							idToName.put(b.get("id").getAsString(), b.get("name").getAsString());
							if (call == null) { // GigaChat за раз вызывает одну функцию
								call = new JsonObject();
								call.addProperty("name", b.get("name").getAsString());
								call.add("arguments", b.get("input"));
							}
						}
					}
					JsonObject a = msg("assistant", text.toString());
					if (call != null) a.add("function_call", call);
					msgs.add(a);
				} else {
					StringBuilder text = new StringBuilder();
					boolean firstResult = true;
					for (JsonElement el : content) {
						JsonObject b = el.getAsJsonObject();
						String t = b.get("type").getAsString();
						if (t.equals("tool_result")) {
							String name = idToName.getOrDefault(b.get("tool_use_id").getAsString(), "say");
							JsonObject res = new JsonObject();
							res.addProperty("result", b.get("content").getAsString());
							if (firstResult) {
								JsonObject f = new JsonObject();
								f.addProperty("role", "function");
								f.addProperty("name", name);
								f.addProperty("content", res.toString());
								msgs.add(f);
								firstResult = false;
							} else {
								text.append("(результат ").append(name).append(": ").append(b.get("content").getAsString()).append(")\n");
							}
						} else if (t.equals("text")) {
							text.append(b.get("text").getAsString()).append('\n');
						}
					}
					if (text.length() > 0) msgs.add(msg("user", text.toString()));
				}
			}
			body.add("messages", msgs);
			JsonArray fns = new JsonArray();
			for (JsonElement t : tools) {
				JsonObject src = t.getAsJsonObject();
				JsonObject f = new JsonObject();
				f.addProperty("name", src.get("name").getAsString());
				f.addProperty("description", src.get("description").getAsString());
				JsonObject schema = src.getAsJsonObject("input_schema").deepCopy();
				if (schema.has("required") && schema.getAsJsonArray("required").isEmpty()) schema.remove("required");
				f.add("parameters", schema);
				fns.add(f);
			}
			body.add("functions", fns);
			body.addProperty("function_call", "auto");

			HttpRequest req = HttpRequest.newBuilder(URI.create(CHAT))
					.timeout(Duration.ofSeconds(90))
					.header("Authorization", "Bearer " + token(ai))
					.header("Content-Type", "application/json")
					.header("Accept", "application/json")
					.POST(HttpRequest.BodyPublishers.ofString(body.toString()))
					.build();
			HttpResponse<String> r = client().send(req, HttpResponse.BodyHandlers.ofString());
			if (r.statusCode() == 401) {
				token = null; // токен протух — в следующий раз войдём заново
				return LlmClient.Reply.fail("GigaChat: токен устарел, повторю");
			}
			if (r.statusCode() == 402) return LlmClient.Reply.fail("GigaChat: бесплатные токены этой модели кончились — поставь другую модель (GigaChat-2)");
			if (r.statusCode() == 429) return LlmClient.Reply.fail("GigaChat: слишком часто (429), подожду");
			if (r.statusCode() >= 300) return LlmClient.Reply.fail("GigaChat HTTP " + r.statusCode() + ": " + r.body().substring(0, Math.min(200, r.body().length())));
			JsonObject j = JsonParser.parseString(r.body()).getAsJsonObject();
			JsonObject m = j.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
			List<String> texts = new ArrayList<>();
			List<LlmClient.ToolCall> calls = new ArrayList<>();
			JsonArray raw = new JsonArray();
			if (m.has("content") && !m.get("content").isJsonNull() && !m.get("content").getAsString().isBlank()) {
				texts.add(m.get("content").getAsString());
				JsonObject tb = new JsonObject();
				tb.addProperty("type", "text");
				tb.addProperty("text", m.get("content").getAsString());
				raw.add(tb);
			}
			if (m.has("function_call") && m.get("function_call").isJsonObject()) {
				JsonObject fc = m.getAsJsonObject("function_call");
				JsonElement args = fc.get("arguments");
				JsonObject input = args == null || args.isJsonNull() ? new JsonObject()
						: args.isJsonObject() ? args.getAsJsonObject()
						: JsonParser.parseString(args.getAsString().isBlank() ? "{}" : args.getAsString()).getAsJsonObject();
				String id = "gc_" + UUID.randomUUID().toString().substring(0, 8);
				calls.add(new LlmClient.ToolCall(id, fc.get("name").getAsString(), input));
				JsonObject tu = new JsonObject();
				tu.addProperty("type", "tool_use");
				tu.addProperty("id", id);
				tu.addProperty("name", fc.get("name").getAsString());
				tu.add("input", input);
				raw.add(tu);
			}
			JsonObject u = j.has("usage") ? j.getAsJsonObject("usage") : new JsonObject();
			long in = u.has("prompt_tokens") ? u.get("prompt_tokens").getAsLong() : 0;
			long out = u.has("completion_tokens") ? u.get("completion_tokens").getAsLong() : 0;
			return new LlmClient.Reply(texts, calls, raw, in, out, 0, 0, null);
		} catch (javax.net.ssl.SSLHandshakeException e) {
			return LlmClient.Reply.fail("GigaChat: нет российского сертификата. Скачай russian_trusted_root_ca_pem.crt с gosuslugi.ru/crt и положи в config/buddy/");
		} catch (Exception e) {
			return LlmClient.Reply.fail("GigaChat: " + e.getMessage());
		}
	}

	private static JsonObject msg(String role, String text) {
		JsonObject o = new JsonObject();
		o.addProperty("role", role);
		o.addProperty("content", text);
		return o;
	}
}
