package com.buddy.brain;

import com.buddy.BuddyConfig;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Связь с языковой моделью. История хранится в формате Anthropic Messages API; для локальных моделей
 * (Ollama, LM Studio и любой OpenAI-совместимый сервер) она переводится в формат chat/completions.
 */
public final class LlmClient {
	public record ToolCall(String id, String name, JsonObject input) {
	}

	public record Reply(List<String> texts, List<ToolCall> calls, JsonArray rawContent,
						long inTokens, long outTokens, long cacheRead, long cacheWrite, String error) {
		static Reply fail(String e) {
			return new Reply(List.of(), List.of(), new JsonArray(), 0, 0, 0, 0, e);
		}
	}

	private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

	private LlmClient() {
	}

	public static CompletableFuture<Reply> send(String system, JsonArray tools, List<JsonObject> history) {
		BuddyConfig.Ai ai = BuddyConfig.get().ai;
		try {
			return ai.provider.equalsIgnoreCase("openai") || ai.provider.equalsIgnoreCase("ollama")
					? sendOpenAi(ai, system, tools, history)
					: sendAnthropic(ai, system, tools, history);
		} catch (Exception e) {
			return CompletableFuture.completedFuture(Reply.fail(e.getMessage()));
		}
	}

	// ------------------------------------------------------------------ Anthropic

	private static CompletableFuture<Reply> sendAnthropic(BuddyConfig.Ai ai, String system, JsonArray tools, List<JsonObject> history) {
		JsonObject body = new JsonObject();
		body.addProperty("model", ai.model);
		body.addProperty("max_tokens", ai.maxTokens);
		JsonArray sys = new JsonArray();
		JsonObject sb = new JsonObject();
		sb.addProperty("type", "text");
		sb.addProperty("text", system);
		JsonObject cache = new JsonObject();
		cache.addProperty("type", "ephemeral");
		sb.add("cache_control", cache); // системный текст и инструменты кэшируются — дешевле
		sys.add(sb);
		body.add("system", sys);
		body.add("tools", tools);
		JsonArray msgs = new JsonArray();
		for (JsonObject m : history) msgs.add(m);
		body.add("messages", msgs);

		HttpRequest req = HttpRequest.newBuilder(URI.create(trimSlash(ai.anthropicUrl) + "/v1/messages"))
				.timeout(Duration.ofSeconds(60))
				.header("content-type", "application/json")
				.header("x-api-key", ai.apiKey())
				.header("anthropic-version", "2023-06-01")
				.POST(HttpRequest.BodyPublishers.ofString(body.toString()))
				.build();
		return HTTP.sendAsync(req, HttpResponse.BodyHandlers.ofString()).handle((resp, err) -> {
			if (err != null) return Reply.fail("нет связи: " + err.getClass().getSimpleName());
			try {
				JsonObject j = JsonParser.parseString(resp.body()).getAsJsonObject();
				if (resp.statusCode() >= 300 || j.has("error")) {
					String msg = j.has("error") ? j.getAsJsonObject("error").get("message").getAsString() : ("HTTP " + resp.statusCode());
					return Reply.fail(msg);
				}
				JsonArray content = j.getAsJsonArray("content");
				List<String> texts = new ArrayList<>();
				List<ToolCall> calls = new ArrayList<>();
				for (JsonElement el : content) {
					JsonObject b = el.getAsJsonObject();
					String type = b.get("type").getAsString();
					if (type.equals("text")) texts.add(b.get("text").getAsString());
					else if (type.equals("tool_use")) {
						calls.add(new ToolCall(b.get("id").getAsString(), b.get("name").getAsString(),
								b.has("input") && b.get("input").isJsonObject() ? b.getAsJsonObject("input") : new JsonObject()));
					}
				}
				JsonObject u = j.has("usage") ? j.getAsJsonObject("usage") : new JsonObject();
				return new Reply(texts, calls, content, num(u, "input_tokens"), num(u, "output_tokens"),
						num(u, "cache_read_input_tokens"), num(u, "cache_creation_input_tokens"), null);
			} catch (Exception e) {
				return Reply.fail("непонятный ответ: " + e.getMessage());
			}
		});
	}

	// ------------------------------------------------------------------ OpenAI-совместимые (Ollama и т.п.)

	private static CompletableFuture<Reply> sendOpenAi(BuddyConfig.Ai ai, String system, JsonArray tools, List<JsonObject> history) {
		JsonObject body = new JsonObject();
		body.addProperty("model", ai.model);
		body.addProperty("max_tokens", ai.maxTokens);
		JsonArray msgs = new JsonArray();
		msgs.add(msg("system", system));
		for (JsonObject m : history) {
			String role = m.get("role").getAsString();
			JsonArray content = m.getAsJsonArray("content");
			if (role.equals("user")) {
				StringBuilder text = new StringBuilder();
				for (JsonElement el : content) {
					JsonObject b = el.getAsJsonObject();
					String type = b.get("type").getAsString();
					if (type.equals("tool_result")) {
						JsonObject t = new JsonObject();
						t.addProperty("role", "tool");
						t.addProperty("tool_call_id", b.get("tool_use_id").getAsString());
						t.addProperty("content", b.get("content").getAsString());
						msgs.add(t);
					} else if (type.equals("text")) {
						text.append(b.get("text").getAsString()).append('\n');
					}
				}
				if (text.length() > 0) msgs.add(msg("user", text.toString()));
			} else {
				JsonObject a = new JsonObject();
				a.addProperty("role", "assistant");
				StringBuilder text = new StringBuilder();
				JsonArray calls = new JsonArray();
				for (JsonElement el : content) {
					JsonObject b = el.getAsJsonObject();
					String type = b.get("type").getAsString();
					if (type.equals("text")) text.append(b.get("text").getAsString());
					else if (type.equals("tool_use")) {
						JsonObject c = new JsonObject();
						c.addProperty("id", b.get("id").getAsString());
						c.addProperty("type", "function");
						JsonObject f = new JsonObject();
						f.addProperty("name", b.get("name").getAsString());
						f.addProperty("arguments", b.get("input").toString());
						c.add("function", f);
						calls.add(c);
					}
				}
				a.addProperty("content", text.toString());
				if (!calls.isEmpty()) a.add("tool_calls", calls);
				msgs.add(a);
			}
		}
		body.add("messages", msgs);
		JsonArray oaTools = new JsonArray();
		for (JsonElement t : tools) {
			JsonObject src = t.getAsJsonObject();
			JsonObject f = new JsonObject();
			f.addProperty("name", src.get("name").getAsString());
			f.addProperty("description", src.get("description").getAsString());
			f.add("parameters", src.get("input_schema"));
			JsonObject w = new JsonObject();
			w.addProperty("type", "function");
			w.add("function", f);
			oaTools.add(w);
		}
		body.add("tools", oaTools);

		HttpRequest.Builder rb = HttpRequest.newBuilder(URI.create(trimSlash(ai.openaiUrl) + "/v1/chat/completions"))
				.timeout(Duration.ofSeconds(120))
				.header("content-type", "application/json")
				.POST(HttpRequest.BodyPublishers.ofString(body.toString()));
		if (!ai.apiKey().isEmpty()) rb.header("Authorization", "Bearer " + ai.apiKey());
		return HTTP.sendAsync(rb.build(), HttpResponse.BodyHandlers.ofString()).handle((resp, err) -> {
			if (err != null) return Reply.fail("нет связи с " + ai.openaiUrl + ": " + err.getClass().getSimpleName());
			try {
				JsonObject j = JsonParser.parseString(resp.body()).getAsJsonObject();
				if (resp.statusCode() >= 300 || j.has("error")) {
					JsonElement e = j.get("error");
					String msg = e == null ? "HTTP " + resp.statusCode() : (e.isJsonObject() ? e.getAsJsonObject().get("message").getAsString() : e.getAsString());
					return Reply.fail(msg);
				}
				JsonObject m = j.getAsJsonArray("choices").get(0).getAsJsonObject().getAsJsonObject("message");
				List<String> texts = new ArrayList<>();
				List<ToolCall> calls = new ArrayList<>();
				JsonArray raw = new JsonArray();
				if (m.has("content") && !m.get("content").isJsonNull() && !m.get("content").getAsString().isBlank()) {
					texts.add(m.get("content").getAsString());
					JsonObject tb = new JsonObject();
					tb.addProperty("type", "text");
					tb.addProperty("text", m.get("content").getAsString());
					raw.add(tb);
				}
				if (m.has("tool_calls") && m.get("tool_calls").isJsonArray()) {
					int n = 0;
					for (JsonElement el : m.getAsJsonArray("tool_calls")) {
						JsonObject c = el.getAsJsonObject();
						JsonObject f = c.getAsJsonObject("function");
						String id = c.has("id") ? c.get("id").getAsString() : ("call_" + (n++));
						JsonObject input;
						JsonElement args = f.get("arguments");
						if (args == null || args.isJsonNull()) input = new JsonObject();
						else if (args.isJsonObject()) input = args.getAsJsonObject();
						else {
							JsonElement p = JsonParser.parseString(args.getAsString().isBlank() ? "{}" : args.getAsString());
							input = p.isJsonObject() ? p.getAsJsonObject() : new JsonObject();
						}
						calls.add(new ToolCall(id, f.get("name").getAsString(), input));
						JsonObject tu = new JsonObject();
						tu.addProperty("type", "tool_use");
						tu.addProperty("id", id);
						tu.addProperty("name", f.get("name").getAsString());
						tu.add("input", input);
						raw.add(tu);
					}
				}
				JsonObject u = j.has("usage") ? j.getAsJsonObject("usage") : new JsonObject();
				return new Reply(texts, calls, raw, num(u, "prompt_tokens"), num(u, "completion_tokens"), 0, 0, null);
			} catch (Exception e) {
				return Reply.fail("непонятный ответ: " + e.getMessage());
			}
		});
	}

	private static JsonObject msg(String role, String text) {
		JsonObject o = new JsonObject();
		o.addProperty("role", role);
		o.addProperty("content", text);
		return o;
	}

	private static long num(JsonObject o, String k) {
		return o.has(k) && !o.get(k).isJsonNull() ? o.get(k).getAsLong() : 0;
	}

	private static String trimSlash(String s) {
		return s.endsWith("/") ? s.substring(0, s.length() - 1) : s;
	}
}
