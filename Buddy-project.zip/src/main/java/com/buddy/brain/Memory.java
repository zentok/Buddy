package com.buddy.brain;

import com.buddy.Buddy;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Долгая память бота (переживает перезапуск): заметки, места, текущая цель.
 * Файл: папка_мира/buddy/ИмяБота.json. Плюс общий учёт трат на ИИ за день: buddy/usage.json.
 */
public class Memory {
	public Map<String, String> notes = new LinkedHashMap<>();
	public Map<String, int[]> places = new LinkedHashMap<>();
	public Map<String, String> placeDims = new LinkedHashMap<>();
	public String goal = "";

	private transient Path file;
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	public static Path dir(MinecraftServer server) {
		return server.getSavePath(WorldSavePath.ROOT).resolve("buddy");
	}

	public static Memory load(MinecraftServer server, String botName) {
		Path f = dir(server).resolve(botName + ".json");
		Memory m = null;
		if (Files.exists(f)) {
			try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
				m = GSON.fromJson(r, Memory.class);
			} catch (Exception e) {
				Buddy.LOGGER.warn("Buddy: не прочитал память {}", f, e);
			}
		}
		if (m == null) m = new Memory();
		if (m.notes == null) m.notes = new LinkedHashMap<>();
		if (m.places == null) m.places = new LinkedHashMap<>();
		if (m.placeDims == null) m.placeDims = new LinkedHashMap<>();
		if (m.goal == null) m.goal = "";
		m.file = f;
		return m;
	}

	public void save() {
		if (file == null) return;
		try {
			Files.createDirectories(file.getParent());
			try (Writer w = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
				GSON.toJson(this, w);
			}
		} catch (Exception e) {
			Buddy.LOGGER.warn("Buddy: не сохранил память {}", file, e);
		}
	}

	public String describe() {
		StringBuilder sb = new StringBuilder();
		if (!places.isEmpty()) {
			sb.append("Места: ");
			places.forEach((k, v) -> sb.append(k).append(" = ").append(v[0]).append(' ').append(v[1]).append(' ').append(v[2])
					.append(placeDims.containsKey(k) && !placeDims.get(k).equals("overworld") ? " (" + placeDims.get(k) + ")" : "").append("; "));
			sb.append('\n');
		}
		if (!notes.isEmpty()) {
			sb.append("Заметки: ");
			notes.forEach((k, v) -> sb.append(k).append(": ").append(v).append("; "));
			sb.append('\n');
		}
		sb.append("Цель: ").append(goal.isEmpty() ? "нет" : goal).append('\n');
		return sb.toString();
	}

	// ------------------------------------------------------------------ траты за день

	public static class Usage {
		public String day = "";
		public double usd = 0;
		public long calls = 0;
	}

	private static Usage usage;
	private static Path usageFile;

	public static synchronized Usage usage(MinecraftServer server) {
		Path f = dir(server).resolve("usage.json");
		if (usage == null || !f.equals(usageFile)) {
			usageFile = f;
			usage = null;
			if (Files.exists(f)) {
				try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
					usage = GSON.fromJson(r, Usage.class);
				} catch (Exception ignored) {
				}
			}
			if (usage == null) usage = new Usage();
		}
		String today = LocalDate.now().toString();
		if (!today.equals(usage.day)) {
			usage.day = today;
			usage.usd = 0;
			usage.calls = 0;
		}
		return usage;
	}

	public static synchronized void addUsage(MinecraftServer server, double usd) {
		Usage u = usage(server);
		u.usd += usd;
		u.calls++;
		try {
			Files.createDirectories(usageFile.getParent());
			try (Writer w = Files.newBufferedWriter(usageFile, StandardCharsets.UTF_8)) {
				GSON.toJson(u, w);
			}
		} catch (Exception ignored) {
		}
	}
}
