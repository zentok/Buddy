package com.buddy.brain;

import com.buddy.BuddyPlayer;
import com.buddy.task.Items2;
import net.minecraft.block.BedBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

/** «Глаза» бота для ИИ: короткое текстовое описание того, что бот знает и видит (без рентгена). */
public final class Observer {
	private Observer() {
	}

	public static String describe(BuddyPlayer bot, Memory mem) {
		ServerWorld w = bot.getServerWorld();
		StringBuilder sb = new StringBuilder("[Состояние]\n");
		long t = w.getTimeOfDay() % 24000;
		int hour = (int) ((t / 1000 + 6) % 24), min = (int) (t % 1000 * 60 / 1000);
		String phase = t < 12000 ? "день" : (t < 13000 ? "закат" : (t < 23000 ? "ночь" : "рассвет"));
		sb.append(String.format(Locale.ROOT, "Время: %s (%02d:%02d), %s, мир %s\n", phase, hour, min,
				w.isThundering() ? "гроза" : (w.isRaining() ? "дождь" : "ясно"), w.getRegistryKey().getValue().getPath()));
		BlockPos p = bot.getBlockPos();
		String biome = w.getBiome(p).getKey().map(k -> k.getValue().getPath()).orElse("?");
		sb.append(String.format(Locale.ROOT, "Я (%s): здоровье %.0f/20, еда %d/20, броня %d, позиция %d %d %d, биом %s%s\n",
				bot.getGameProfile().getName(), bot.getHealth(), bot.getHungerManager().getFoodLevel(), bot.getArmor(),
				p.getX(), p.getY(), p.getZ(), biome, bot.isSleeping() ? ", сплю" : ""));
		sb.append("Сейчас делаю: ").append(bot.activityText()).append('\n');

		ServerPlayerEntity o = bot.getOwnerPlayer();
		if (o == null) sb.append("Хозяин: не в игре\n");
		else if (o.getWorld() != w) sb.append("Хозяин ").append(o.getGameProfile().getName()).append(": в другом измерении\n");
		else {
			BlockPos op = o.getBlockPos();
			sb.append(String.format(Locale.ROOT, "Хозяин %s: в %.0f бл. (%d %d %d), здоровье %.0f, в руке %s%s\n",
					o.getGameProfile().getName(), bot.distanceTo(o), op.getX(), op.getY(), op.getZ(), o.getHealth(),
					o.getMainHandStack().isEmpty() ? "ничего" : Items2.id(o.getMainHandStack()),
					o.isSleeping() ? ", спит" : ""));
		}

		// инвентарь (сгруппировано)
		Map<String, Integer> inv = new TreeMap<>();
		StringBuilder tools = new StringBuilder();
		for (ItemStack s : bot.getInventory().main) {
			if (s.isEmpty()) continue;
			if (s.isDamageable()) {
				tools.append(Items2.id(s)).append(String.format(Locale.ROOT, "(%d%%) ", 100 - 100 * s.getDamage() / Math.max(1, s.getMaxDamage())));
			} else inv.merge(Items2.id(s), s.getCount(), Integer::sum);
		}
		sb.append("Инвентарь: ");
		if (inv.isEmpty() && tools.length() == 0) sb.append("пусто");
		sb.append(tools);
		inv.forEach((k, v) -> sb.append(k).append(" x").append(v).append(", "));
		int free = 0;
		for (ItemStack s : bot.getInventory().main) if (s.isEmpty()) free++;
		sb.append(" (свободно слотов: ").append(free).append(")\n");
		StringBuilder armor = new StringBuilder();
		for (ItemStack s : bot.getInventory().armor) if (!s.isEmpty()) armor.append(Items2.id(s)).append(' ');
		if (!bot.getOffHandStack().isEmpty()) armor.append("+ во второй руке ").append(Items2.id(bot.getOffHandStack()));
		if (armor.length() > 0) sb.append("Надето: ").append(armor).append('\n');

		// существа рядом
		Map<String, Integer> mobs = new LinkedHashMap<>();
		Map<String, Integer> items = new LinkedHashMap<>();
		for (Entity e : w.getOtherEntities(bot, bot.getBoundingBox().expand(16, 8, 16))) {
			if (e instanceof ItemEntity ie) {
				items.merge(Items2.id(ie.getStack()), ie.getStack().getCount(), Integer::sum);
				continue;
			}
			if (!(e instanceof LivingEntity) || e == o || !bot.canSee(e)) continue;
			String name = e instanceof PlayerEntity pl ? "игрок " + pl.getGameProfile().getName()
					: net.minecraft.registry.Registries.ENTITY_TYPE.getId(e.getType()).getPath() + (e instanceof Monster ? "(враг)" : "");
			mobs.merge(name, 1, Integer::sum);
		}
		if (!mobs.isEmpty()) {
			sb.append("Вижу рядом: ");
			mobs.forEach((k, v) -> sb.append(k).append(v > 1 ? " x" + v : "").append(", "));
			sb.append('\n');
		}
		if (!items.isEmpty()) {
			sb.append("Предметы на земле: ");
			items.forEach((k, v) -> sb.append(k).append(" x").append(v).append(", "));
			sb.append('\n');
		}

		// важные блоки, которые видно глазами
		sb.append("Вижу блоки: ").append(visibleBlocks(bot, w)).append('\n');
		if (bot.getStoragePos() != null) {
			BlockPos s = bot.getStoragePos();
			sb.append("Склад (назначенный сундук): ").append(s.getX()).append(' ').append(s.getY()).append(' ').append(s.getZ()).append('\n');
		}
		sb.append(mem.describe());
		return sb.toString();
	}

	private static String visibleBlocks(BuddyPlayer bot, ServerWorld w) {
		Map<String, Double> nearest = new LinkedHashMap<>();
		Map<String, BlockPos> where = new LinkedHashMap<>();
		BlockPos c = bot.getBlockPos();
		int r = 12;
		for (BlockPos p : BlockPos.iterate(c.add(-r, -5, -r), c.add(r, 5, r))) {
			String kind = kind(w, p);
			if (kind == null) continue;
			double d = p.getSquaredDistance(c);
			if (nearest.containsKey(kind) && nearest.get(kind) <= d) continue;
			if (!visible(bot, w, p)) continue;
			nearest.put(kind, d);
			where.put(kind, p.toImmutable());
		}
		if (where.isEmpty()) return "ничего особенного";
		StringBuilder sb = new StringBuilder();
		where.forEach((k, v) -> sb.append(k).append(String.format(Locale.ROOT, " (%.0f бл.)", Math.sqrt(nearest.get(k)))).append(", "));
		return sb.toString();
	}

	private static String kind(ServerWorld w, BlockPos p) {
		BlockState s = w.getBlockState(p);
		if (s.isAir()) return null;
		if (s.isOf(Blocks.CRAFTING_TABLE)) return "верстак";
		if (s.getBlock() instanceof BedBlock) return "кровать";
		if (s.getFluidState().isIn(FluidTags.LAVA) && s.getFluidState().isStill()) return "лава";
		if (s.getFluidState().isIn(FluidTags.WATER) && s.getFluidState().isStill()) return "вода";
		BlockEntity be = s.hasBlockEntity() ? w.getBlockEntity(p) : null;
		if (be instanceof AbstractFurnaceBlockEntity) return "печь";
		if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity) return "сундук";
		if (com.buddy.ai.FarmJob.isRipe(w, p, s)) return "созревший урожай";
		if (com.buddy.ai.MineJob.isOre(s)) return "руда " + net.minecraft.registry.Registries.BLOCK.getId(s.getBlock()).getPath();
		return null;
	}

	private static boolean visible(BuddyPlayer bot, ServerWorld w, BlockPos p) {
		Vec3d eye = bot.getEyePos();
		BlockHitResult hit = w.raycast(new RaycastContext(eye, Vec3d.ofCenter(p), RaycastContext.ShapeType.COLLIDER,
				RaycastContext.FluidHandling.ANY, bot));
		return hit.getType() == HitResult.Type.MISS || hit.getBlockPos().equals(p);
	}

	@SuppressWarnings("unused")
	private static String id(Item i) {
		return Items2.id(i);
	}
}
