package com.buddy.brain;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

/** Описание инструментов (действий), которые ИИ может вызывать. Формат — Anthropic tools. */
public final class Tools {
	private Tools() {
	}

	private static JsonArray cached;

	public static JsonArray all() {
		if (cached != null) return cached;
		JsonArray a = new JsonArray();
		a.add(tool("say", "Сказать фразу в игровой чат (по-русски, коротко). Единственный способ говорить.",
				prop("text", "string", "Что сказать"), "text"));
		a.add(tool("follow", "Ходить за хозяином (держится в 5–7 блоках, защищает)."));
		a.add(tool("stay", "Остаться здесь и работать рядом: собирать созревший урожай, сажать, носить в сундук."));
		a.add(tool("come", "Подойти вплотную к хозяину, потом стоять рядом."));
		a.add(tool("mine", "Копать шахту: лесенкой вниз до target_y, потом туннели. Руду берёт только видимую.",
				prop("target_y", "integer", "Глубина (необязательно). Алмазы -54, железо 16, золото -16, медь 48")));
		a.add(tool("chop", "Рубить деревья рядом, пока не кончатся."));
		a.add(tool("unload", "Отнести добычу в сундук-склад и вернуться к прежнему делу."));
		a.add(tool("collect", "Добыть N штук ресурса (фоновая задача): брёвна — рубит лес; руда/уголь/булыжник — шахта на подходящей глубине; песок, земля, глина, гравий — копает видимое рядом.",
				props(prop("item", "string", "id предмета: oak_log, raw_iron, coal, cobblestone, sand…"),
						prop("count", "integer", "Сколько")), "item", "count"));
		a.add(tool("craft", "Скрафтить N предметов по настоящим рецептам (в т.ч. моды). Промежуточное (доски, палки, верстак) делает сам, если есть сырьё.",
				props(prop("item", "string", "id: crafting_table, stick, wooden_pickaxe, iron_pickaxe, torch, furnace…"),
						prop("count", "integer", "Сколько")), "item", "count"));
		a.add(tool("smelt", "Переплавить в печи (найдёт/поставит/скрафтит печь, положит топливо).",
				props(prop("item", "string", "Что получить (iron_ingot) или что плавить (raw_iron)"),
						prop("count", "integer", "Сколько")), "item", "count"));
		a.add(tool("give", "Подойти к хозяину и отдать предметы. Без item — всю добычу (кроме инструментов и еды).",
				props(prop("item", "string", "id предмета (необязательно)"), prop("count", "integer", "Сколько (необязательно)"))));
		a.add(tool("chest", "Взять из сундука-склада или положить в него.",
				props(prop("action", "string", "take или put"), prop("item", "string", "id предмета (для put можно не указывать — положит добычу)"),
						prop("count", "integer", "Сколько")), "action"));
		a.add(tool("goto", "Дойти до координат.",
				props(prop("x", "integer", "X"), prop("y", "integer", "Y"), prop("z", "integer", "Z")), "x", "y", "z"));
		a.add(tool("goto_place", "Дойти до сохранённого места (см. «Места» в памяти).", prop("name", "string", "Название места"), "name"));
		a.add(tool("save_place", "Запомнить место под названием (например «база», «шахта»).",
				props(prop("name", "string", "Название"), prop("where", "string", "here — где я, owner — где хозяин")), "name"));
		a.add(tool("remember", "Запомнить надолго факт (переживёт перезапуск).",
				props(prop("key", "string", "Короткий ключ"), prop("text", "string", "Что запомнить")), "key", "text"));
		a.add(tool("forget", "Забыть заметку или место.", prop("key", "string", "Ключ заметки или название места"), "key"));
		a.add(tool("set_goal", "Записать текущую большую цель и план по шагам (пустая строка — цели нет).",
				prop("text", "string", "Цель и план: «железная кирка: 1) брёвна 2) верстак 3) каменная кирка 4) 3 raw_iron 5) переплавить 6) скрафтить»"), "text"));
		a.add(tool("stop", "Прекратить текущее дело и просто стоять рядом."));
		cached = a;
		return a;
	}

	private static JsonObject prop(String name, String type, String desc) {
		JsonObject p = new JsonObject();
		JsonObject d = new JsonObject();
		d.addProperty("type", type);
		d.addProperty("description", desc);
		p.add(name, d);
		return p;
	}

	private static JsonObject props(JsonObject... ps) {
		JsonObject all = new JsonObject();
		for (JsonObject p : ps) for (String k : p.keySet()) all.add(k, p.get(k));
		return all;
	}

	private static JsonObject tool(String name, String desc) {
		return tool(name, desc, new JsonObject());
	}

	private static JsonObject tool(String name, String desc, JsonObject properties, String... required) {
		JsonObject t = new JsonObject();
		t.addProperty("name", name);
		t.addProperty("description", desc);
		JsonObject schema = new JsonObject();
		schema.addProperty("type", "object");
		schema.add("properties", properties);
		JsonArray req = new JsonArray();
		for (String r : required) req.add(r);
		schema.add("required", req);
		t.add("input_schema", schema);
		return t;
	}
}
