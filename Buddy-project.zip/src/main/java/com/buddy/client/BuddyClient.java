package com.buddy.client;

import com.buddy.BuddyNet;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.util.ActionResult;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;

import java.util.HashSet;
import java.util.Set;

/**
 * Клиентская часть: клавиша колеса команд (меняется в Настройки → Управление → «Buddy»),
 * само колесо и ПКМ по своему боту.
 */
public class BuddyClient implements ClientModInitializer {
	public static KeyBinding WHEEL;
	/** Имена моих ботов (присылает сервер). */
	public static final Set<String> MY_BOTS = new HashSet<>();

	@Override
	public void onInitializeClient() {
		WHEEL = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.buddy.wheel", InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_G, "key.categories.buddy"));

		ClientPlayNetworking.registerGlobalReceiver(BuddyNet.BOTS, (client, handler, buf, sender) -> {
			int n = buf.readVarInt();
			Set<String> names = new HashSet<>();
			for (int i = 0; i < n; i++) names.add(buf.readString(16));
			client.execute(() -> {
				MY_BOTS.clear();
				MY_BOTS.addAll(names);
			});
		});
		ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> MY_BOTS.clear());

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (WHEEL.wasPressed()) {
				if (client.player != null && client.currentScreen == null) open(client, botUnderCrosshair(client), true);
			}
		});

		// ПКМ по своему боту — колесо именно для него
		UseEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
			if (!world.isClient || !(entity instanceof PlayerEntity p)) return ActionResult.PASS;
			String name = p.getGameProfile().getName();
			if (!MY_BOTS.contains(name) || player.isSneaking()) return ActionResult.PASS;
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.currentScreen == null) open(mc, name, false);
			return ActionResult.SUCCESS;
		});
	}

	private static void open(MinecraftClient client, @Nullable String bot, boolean byKey) {
		if (!ClientPlayNetworking.canSend(BuddyNet.COMMAND)) {
			if (client.player != null) client.player.sendMessage(net.minecraft.text.Text.translatable("buddy.wheel.no_server"), true);
			return;
		}
		client.setScreen(new WheelScreen(bot, byKey));
	}

	@Nullable
	private static String botUnderCrosshair(MinecraftClient client) {
		HitResult hit = client.crosshairTarget;
		if (hit instanceof EntityHitResult eh) {
			Entity e = eh.getEntity();
			if (e instanceof PlayerEntity p && MY_BOTS.contains(p.getGameProfile().getName())) return p.getGameProfile().getName();
		}
		return null;
	}

	/** Отправить команду на сервер (с блоком под прицелом — для склада/кровати). */
	public static void send(String action, @Nullable String bot) {
		MinecraftClient mc = MinecraftClient.getInstance();
		PacketByteBuf buf = PacketByteBufs.create();
		buf.writeString(action, 32);
		buf.writeString(bot == null ? "" : bot, 16);
		HitResult hit = mc.crosshairTarget;
		if (hit instanceof BlockHitResult bh && hit.getType() == HitResult.Type.BLOCK) {
			buf.writeBoolean(true);
			buf.writeBlockPos(bh.getBlockPos());
		} else {
			buf.writeBoolean(false);
		}
		ClientPlayNetworking.send(BuddyNet.COMMAND, buf);
	}
}
