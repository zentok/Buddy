package com.buddy.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import org.jetbrains.annotations.Nullable;

/**
 * Меню команд: 8 кнопок по кругу. Появляется обычный курсор мыши — наведи на кнопку и кликни.
 * Ничего не выбирается само: только клик. Esc или повторное нажатие клавиши — закрыть.
 */
public class WheelScreen extends Screen {
	private record Option(String action, String key, ItemStack icon) {
	}

	private static final Option[] OPTIONS = {
			new Option("follow", "buddy.wheel.follow", new ItemStack(Items.LEAD)),
			new Option("come", "buddy.wheel.come", new ItemStack(Items.BELL)),
			new Option("stay", "buddy.wheel.stay", new ItemStack(Items.WHEAT)),
			new Option("mine", "buddy.wheel.mine", new ItemStack(Items.IRON_PICKAXE)),
			new Option("chop", "buddy.wheel.chop", new ItemStack(Items.IRON_AXE)),
			new Option("unload", "buddy.wheel.unload", new ItemStack(Items.HOPPER)),
			new Option("store", "buddy.wheel.store", new ItemStack(Items.CHEST)),
			new Option("bed", "buddy.wheel.bed", new ItemStack(Items.RED_BED)),
	};

	private static final int BW = 48, BH = 18; // половина ширины и высоты кнопки

	/** Кому команда: null — всем моим ботам, иначе имя. Выбирается кликом по центру меню. */
	private final java.util.List<String> choices = new java.util.ArrayList<>();
	private int choice;
	private int hovered = -1;
	private final long openedAt = System.currentTimeMillis();

	public WheelScreen(@Nullable String bot, boolean byKey) {
		super(Text.translatable("buddy.wheel.title"));
		choices.add(null);
		java.util.List<String> names = new java.util.ArrayList<>(BuddyClient.MY_BOTS);
		names.sort(String.CASE_INSENSITIVE_ORDER);
		choices.addAll(names);
		// если ботов несколько и не выбран конкретный — по умолчанию первый, а не «все»
		int idx = bot != null ? choices.indexOf(bot) : (names.size() == 1 ? 1 : -1);
		choice = Math.max(0, idx);
	}

	@Nullable
	private String bot() {
		return choices.get(choice);
	}

	private boolean overCenter(double mx, double my) {
		return Math.abs(mx - width / 2.0) <= 60 && Math.abs(my - height / 2.0) <= 16;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private int radius() {
		return Math.max(70, Math.min(width, height) / 2 - 40);
	}

	private int cx(int i) {
		return width / 2 + (int) Math.round(Math.cos(Math.toRadians(i * 45 - 90)) * radius());
	}

	private int cy(int i) {
		return height / 2 + (int) Math.round(Math.sin(Math.toRadians(i * 45 - 90)) * radius() * 0.8);
	}

	/** Кнопка под курсором (по её прямоугольнику) или -1. */
	private int buttonAt(double mx, double my) {
		for (int i = 0; i < OPTIONS.length; i++) {
			if (Math.abs(mx - cx(i)) <= BW && Math.abs(my - cy(i)) <= BH) return i;
		}
		return -1;
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		ctx.fill(0, 0, width, height, 0x66000000);
		hovered = buttonAt(mouseX, mouseY);
		int mx = width / 2, my = height / 2;
		boolean hc = overCenter(mouseX, mouseY) && choices.size() > 1;
		ctx.fill(mx - 60, my - 16, mx + 60, my + 16, hc ? 0xEE3A6FD8 : 0xDD20242C);
		ctx.drawBorder(mx - 60, my - 16, 120, 32, hc ? 0xFFFFFFFF : 0xFF5A6070);
		Text title = bot() == null ? Text.translatable("buddy.wheel.all") : Text.literal(bot());
		ctx.drawCenteredTextWithShadow(textRenderer, title, mx, my - 8, 0xFFE8C24A);
		if (choices.size() > 1) {
			ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("buddy.wheel.switch"), mx, my + 4, 0xAAAAAA);
			ctx.drawTextWithShadow(textRenderer, Text.literal("◀"), mx - 56, my - 4, 0xFFFFFF);
			ctx.drawTextWithShadow(textRenderer, Text.literal("▶"), mx + 50, my - 4, 0xFFFFFF);
		}
		for (int i = 0; i < OPTIONS.length; i++) {
			int x = cx(i), y = cy(i);
			boolean h = i == hovered;
			ctx.fill(x - BW, y - BH, x + BW, y + BH, h ? 0xEE3A6FD8 : 0xDD2A2F3A);
			ctx.drawBorder(x - BW, y - BH, BW * 2, BH * 2, h ? 0xFFFFFFFF : 0xFF5A6070);
			ctx.drawItem(OPTIONS[i].icon(), x - 8, y - BH + 2);
			ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable(OPTIONS[i].key()), x, y + 5, 0xFFFFFF);
		}
		ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable("buddy.wheel.hint"), mx, height - 20, 0xBBBBBB);
		super.render(ctx, mouseX, mouseY, delta);
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		if (overCenter(mx, my) && choices.size() > 1) { // выбрать бота: ЛКМ — следующий, ПКМ — предыдущий
			choice = Math.floorMod(choice + (button == 1 ? -1 : 1), choices.size());
			return true;
		}
		if (button != 0) return super.mouseClicked(mx, my, button);
		int s = buttonAt(mx, my);
		if (s >= 0) {
			BuddyClient.send(OPTIONS[s].action(), bot());
			close();
		}
		return true; // клик мимо кнопок ничего не делает — меню остаётся открытым
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		// повторное нажатие клавиши меню — закрыть
		if (BuddyClient.WHEEL != null && BuddyClient.WHEEL.matchesKey(keyCode, scanCode) && System.currentTimeMillis() - openedAt > 200) {
			close();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}
}
