package com.buddy.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.jetbrains.annotations.Nullable;

/**
 * Колесо команд: 8 действий по кругу. Наведи и кликни — или отпусти клавишу, наведя мышь.
 * Esc — закрыть.
 */
public class WheelScreen extends Screen {
	private record Option(String action, String key, ItemStack icon) {
	}

	private static final Option[] OPTIONS = {
			new Option("follow", "buddy.wheel.follow", new ItemStack(Items.LEAD)),
			new Option("come", "buddy.wheel.come", new ItemStack(Items.BELL)),
			new Option("stay", "buddy.wheel.stay", new ItemStack(Items.WHEAT)),
			new Option("mine", "buddy.wheel.mine", new ItemStack(Items.IRON_PICKAXE)),
			new Option("chop", "buddy.wheel.chop", new ItemStack(Items.IRON_AXE)),
			new Option("unload", "buddy.wheel.unload", new ItemStack(Items.HOPPER)),
			new Option("store", "buddy.wheel.store", new ItemStack(Items.CHEST)),
			new Option("bed", "buddy.wheel.bed", new ItemStack(Items.RED_BED)),
	};

	@Nullable
	private final String bot;
	private int hovered = -1;
	private final long openedAt = System.currentTimeMillis();

	/** Открыто клавишей (тогда отпускание клавиши выбирает пункт) или ПКМ по боту. */
	private final boolean byKey;

	public WheelScreen(@Nullable String bot, boolean byKey) {
		super(Text.translatable("buddy.wheel.title"));
		this.bot = bot;
		this.byKey = byKey;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	private int radius() {
		return Math.min(width, height) / 4 + 20;
	}

	private int sectorAt(double mx, double my) {
		double dx = mx - width / 2.0, dy = my - height / 2.0;
		if (dx * dx + dy * dy < 22 * 22) return -1;
		double ang = Math.toDegrees(Math.atan2(dy, dx)) + 90 + 22.5; // 0 — сверху, по часовой
		ang = (ang % 360 + 360) % 360;
		return (int) (ang / 45) % OPTIONS.length;
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		ctx.fill(0, 0, width, height, 0x66000000);
		int cx = width / 2, cy = height / 2, r = radius();
		hovered = sectorAt(mouseX, mouseY);
		// центр
		ctx.fill(cx - 40, cy - 12, cx + 40, cy + 12, 0xCC20242C);
		Text title = bot == null ? Text.translatable("buddy.wheel.all") : Text.literal(bot);
		ctx.drawCenteredTextWithShadow(textRenderer, title, cx, cy - 4, 0xFFE8C24A);
		for (int i = 0; i < OPTIONS.length; i++) {
			double a = Math.toRadians(i * 45 - 90);
			int x = cx + (int) Math.round(Math.cos(a) * r);
			int y = cy + (int) Math.round(Math.sin(a) * r);
			boolean h = i == hovered;
			int w = 46, hh = 34;
			int bg = h ? 0xEE3A6FD8 : 0xCC2A2F3A;
			ctx.fill(x - w, y - hh / 2, x + w, y + hh / 2, bg);
			ctx.drawBorder(x - w, y - hh / 2, w * 2, hh, h ? 0xFFFFFFFF : 0xFF5A6070);
			ctx.drawItem(OPTIONS[i].icon(), x - 8, y - hh / 2 + 2);
			ctx.drawCenteredTextWithShadow(textRenderer, Text.translatable(OPTIONS[i].key()), x, y + 3, 0xFFFFFF);
		}
		// подсказка
		Text hint = Text.translatable("buddy.wheel.hint");
		ctx.drawCenteredTextWithShadow(textRenderer, hint, cx, cy + r + 30, 0xAAAAAA);
		super.render(ctx, mouseX, mouseY, delta);
	}

	@Override
	public boolean mouseClicked(double mx, double my, int button) {
		int s = sectorAt(mx, my);
		if (s >= 0) {
			choose(s);
			return true;
		}
		close();
		return true;
	}

	@Override
	public void tick() {
		// отпустил клавишу колеса, наведя на пункт — выбрать (как в колесе эмоций)
		if (!byKey || client == null || BuddyClient.WHEEL == null) return;
		InputUtil.Key key = net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper.getBoundKeyOf(BuddyClient.WHEEL);
		if (key.getCategory() != InputUtil.Type.KEYSYM || key.getCode() < 0) return;
		boolean down = InputUtil.isKeyPressed(client.getWindow().getHandle(), key.getCode());
		if (!down && System.currentTimeMillis() - openedAt > 250) {
			if (hovered >= 0) choose(hovered);
		}
	}

	private void choose(int i) {
		BuddyClient.send(OPTIONS[i].action(), bot);
		close();
	}

	@Override
	public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
		if (BuddyClient.WHEEL != null && BuddyClient.WHEEL.matchesKey(keyCode, scanCode) && System.currentTimeMillis() - openedAt > 250) {
			if (hovered >= 0) choose(hovered);
			else close();
			return true;
		}
		return super.keyPressed(keyCode, scanCode, modifiers);
	}

	@SuppressWarnings("unused")
	private static float clamp(float v) {
		return MathHelper.clamp(v, 0, 1);
	}
}
