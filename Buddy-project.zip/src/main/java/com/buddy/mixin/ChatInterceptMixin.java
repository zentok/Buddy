package com.buddy.mixin;

import com.buddy.Buddy;
import com.buddy.BuddyPlayer;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import net.minecraft.server.network.ServerPlayNetworkHandler;
import net.minecraft.server.network.ServerPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Ловим сообщение чата прямо когда оно пришло от игрока — так команды боту («!шахта», «сделай топор»)
 * работают, даже если другой мод перехватывает или переделывает обычную рассылку чата.
 */
@Mixin(ServerPlayNetworkHandler.class)
public abstract class ChatInterceptMixin {
	@Shadow
	public ServerPlayerEntity player;

	@Inject(method = "onChatMessage", at = @At("HEAD"))
	private void buddy$onChat(ChatMessageC2SPacket packet, CallbackInfo ci) {
		ServerPlayerEntity p = this.player;
		if (p == null || p instanceof BuddyPlayer || p.getServer() == null) return;
		String text = packet.chatMessage();
		Buddy.queueChat(p, text);
	}
}
