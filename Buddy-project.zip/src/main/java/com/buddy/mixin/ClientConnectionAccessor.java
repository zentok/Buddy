package com.buddy.mixin;

import io.netty.channel.Channel;
import net.minecraft.network.ClientConnection;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.net.SocketAddress;

/** Даёт поддельному соединению бота «канал» и адрес, чтобы другие моды не падали на null. */
@Mixin(ClientConnection.class)
public interface ClientConnectionAccessor {
	@Accessor("channel")
	void buddy$setChannel(Channel channel);

	@Accessor("address")
	void buddy$setAddress(SocketAddress address);
}
