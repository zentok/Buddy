package com.buddy.mixin;

import com.buddy.BuddyPlayer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.SleepManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import java.util.List;

/** Боты не мешают пропустить ночь: при подсчёте спящих их не учитываем. */
@Mixin(SleepManager.class)
public abstract class SleepManagerMixin {
	@ModifyVariable(method = "update", at = @At("HEAD"), argsOnly = true, require = 0)
	private List<ServerPlayerEntity> buddy$ignoreBotsUpdate(List<ServerPlayerEntity> players) {
		return withoutBots(players);
	}

	@ModifyVariable(method = "canResetTime", at = @At("HEAD"), argsOnly = true, require = 0)
	private List<ServerPlayerEntity> buddy$ignoreBotsReset(List<ServerPlayerEntity> players) {
		return withoutBots(players);
	}

	private static List<ServerPlayerEntity> withoutBots(List<ServerPlayerEntity> players) {
		for (ServerPlayerEntity p : players) {
			if (p instanceof BuddyPlayer) return players.stream().filter(x -> !(x instanceof BuddyPlayer)).toList();
		}
		return players;
	}
}
