package com.buddy.task;

import com.buddy.BuddyPlayer;
import com.buddy.ai.Hands;
import com.buddy.ai.Inv;
import com.buddy.ai.Storekeeper;
import com.buddy.ai.Walker;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

/** Взять из сундука-склада или положить в него. */
public class ChestTask implements Task {
	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Storekeeper store;
	private final boolean take;
	@Nullable
	private final Item item;
	private final int want;
	@Nullable
	private BlockPos chest;
	private int ticks;
	private String result = "";

	public ChestTask(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, boolean take, @Nullable Item item, int count) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.store = store;
		this.take = take;
		this.item = item;
		this.want = Math.max(1, count);
	}

	@Override
	public String describe() {
		String what = item == null ? "добычу" : want + " " + Items2.id(item);
		return (take ? "взять из сундука " : "положить в сундук ") + what;
	}

	@Override
	public String result() {
		return result;
	}

	@Override
	public Status tick() {
		ServerWorld w = bot.getServerWorld();
		if (chest == null) {
			chest = store.findChest(bot.getBlockPos());
			if (chest == null) {
				result = "не знаю, где сундук (покажи: !склад)";
				return Status.FAILED;
			}
		}
		if (++ticks > 1800) {
			result = "не дошёл до сундука";
			return Status.FAILED;
		}
		if (!hands.inReach(chest)) {
			walker.moveTo(chest, 2.5, false);
			return Status.RUNNING;
		}
		walker.stop();
		hands.lookAt(Vec3d.ofCenter(chest));
		Storage<ItemVariant> st = ItemStorage.SIDED.find(w, chest, Direction.UP);
		if (st == null) {
			result = "это не сундук";
			return Status.FAILED;
		}
		if (!take) {
			if (item == null) {
				int n = Inv.depositInto(bot, w, chest);
				result = "положил " + Math.max(0, n) + " предметов";
				return Status.DONE;
			}
			int moved = 0;
			for (ItemStack s : bot.getInventory().main) {
				if (moved >= want || s.isEmpty() || !s.isOf(item)) continue;
				int n = Math.min(s.getCount(), want - moved);
				try (Transaction tx = Transaction.openOuter()) {
					long ins = st.insert(ItemVariant.of(s), n, tx);
					tx.commit();
					s.decrement((int) ins);
					moved += (int) ins;
				}
			}
			result = moved > 0 ? "положил " + moved + " " + Items2.id(item) : "не получилось положить (сундук полон или у меня нет)";
			return moved > 0 ? Status.DONE : Status.FAILED;
		}
		if (item == null) {
			result = "что взять? укажи предмет";
			return Status.FAILED;
		}
		long got;
		try (Transaction tx = Transaction.openOuter()) {
			got = st.extract(ItemVariant.of(item), want, tx);
			tx.commit();
		}
		long left = got;
		while (left > 0) {
			int n = (int) Math.min(left, item.getMaxCount());
			bot.getInventory().offerOrDrop(new ItemStack(item, n));
			left -= n;
		}
		result = got > 0 ? "взял " + got + " " + Items2.id(item) : "в сундуке нет " + Items2.id(item);
		return got > 0 ? Status.DONE : Status.FAILED;
	}
}
