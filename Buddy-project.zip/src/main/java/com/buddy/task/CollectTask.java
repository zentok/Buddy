package com.buddy.task;

import com.buddy.BuddyPlayer;
import com.buddy.ai.Hands;
import com.buddy.ai.Inv;
import com.buddy.ai.LumberJob;
import com.buddy.ai.MineJob;
import com.buddy.ai.Storekeeper;
import com.buddy.ai.Walker;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.ItemEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.Nullable;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;

/**
 * «Принеси N штук»: брёвна — рубит лес; руда/уголь/камень — шахта (без рентгена) на подходящей глубине;
 * песок, земля, гравий, глина и т.п. — копает то, что видно на поверхности рядом.
 */
public class CollectTask implements Task {
	private enum Kind {LOGS, MINE, SURFACE, UNKNOWN}

	/** Руда → на какой высоте искать. */
	private static final Map<Item, Integer> MINE_Y = Map.ofEntries(
			Map.entry(Items.COAL, 48), Map.entry(Items.RAW_IRON, 16), Map.entry(Items.IRON_ORE, 16),
			Map.entry(Items.RAW_COPPER, 48), Map.entry(Items.COPPER_ORE, 48), Map.entry(Items.RAW_GOLD, -16),
			Map.entry(Items.GOLD_ORE, -16), Map.entry(Items.DIAMOND, -54), Map.entry(Items.REDSTONE, -54),
			Map.entry(Items.LAPIS_LAZULI, 0), Map.entry(Items.EMERALD, 100), Map.entry(Items.COBBLESTONE, 9999),
			Map.entry(Items.COBBLED_DEEPSLATE, -8), Map.entry(Items.DEEPSLATE, -8), Map.entry(Items.FLINT, 9999),
			Map.entry(Items.AMETHYST_SHARD, -10));

	/** Что даёт какой блок, если блок ≠ предмет. */
	private static final Map<Item, Block> SOURCE = Map.of(
			Items.CLAY_BALL, Blocks.CLAY, Items.FLINT, Blocks.GRAVEL, Items.SNOWBALL, Blocks.SNOW_BLOCK,
			Items.STRING, Blocks.COBWEB, Items.STICK, Blocks.DEAD_BUSH);

	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Storekeeper store;
	private final Item item;
	private final int want;
	private final int start;
	private final Predicate<ItemStack> counts;
	private final Kind kind;
	@Nullable
	private LumberJob lumber;
	@Nullable
	private MineJob mine;
	@Nullable
	private BlockPos surfaceTarget;
	private final Set<BlockPos> skip = new HashSet<>();
	private int ticks;
	private int idle;
	private String result = "";

	public CollectTask(BuddyPlayer bot, Walker walker, Hands hands, Storekeeper store, Item item, int count) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.store = store;
		this.want = Math.max(1, Math.min(count, 1024));
		if (new ItemStack(item).isIn(ItemTags.LOGS)) {
			this.item = item;
			this.kind = Kind.LOGS;
			this.counts = s -> s.isIn(ItemTags.LOGS);
		} else if (MINE_Y.containsKey(item)) {
			this.item = item;
			this.kind = Kind.MINE;
			Item ore = item;
			this.counts = s -> s.isOf(ore) || (ore == Items.RAW_IRON && s.isOf(Items.IRON_ORE)) || (ore == Items.RAW_GOLD && s.isOf(Items.GOLD_ORE))
					|| (ore == Items.RAW_COPPER && s.isOf(Items.COPPER_ORE));
		} else if (item instanceof BlockItem || SOURCE.containsKey(item)) {
			this.item = item;
			this.kind = Kind.SURFACE;
			this.counts = s -> s.isOf(item);
		} else {
			this.item = item;
			this.kind = Kind.UNKNOWN;
			this.counts = s -> s.isOf(item);
		}
		this.start = Inv.count(bot, counts);
	}

	@Override
	public String describe() {
		return "добыть " + want + " " + Items2.id(item);
	}

	@Override
	public String result() {
		return result;
	}

	private int got() {
		return Inv.count(bot, counts) - start;
	}

	@Override
	public Status tick() {
		ServerWorld w = bot.getServerWorld();
		ticks++;
		if (kind == Kind.UNKNOWN) {
			result = "не знаю, где добыть " + Items2.id(item) + " (это крафтится или плавится? попробуй craft/smelt)";
			return Status.FAILED;
		}
		boolean enough = got() >= want;
		switch (kind) {
			case LOGS -> {
				if (enough) return done();
				if (lumber == null) lumber = new LumberJob(bot, walker, hands, store, bot.getBlockPos());
				if (!lumber.tick()) return got() > 0 ? done() : fail("рядом нет деревьев");
			}
			case MINE -> {
				if (mine == null) {
					int target = MINE_Y.get(item);
					if (target == 9999) target = bot.getBlockY() - 6;
					target = Math.max(target, w.getBottomY() + 5);
					mine = new MineJob(bot, walker, hands, store, bot.getHorizontalFacing(), Math.min(target, bot.getBlockY()));
					mine.keep = counts;
				}
				if (enough) mine.finish();
				if (!mine.tick()) return got() >= want ? done() : (got() > 0 ? done() : fail("шахта кончилась, а " + Items2.id(item) + " не попалось"));
			}
			case SURFACE -> {
				if (enough) return done();
				return surface(w);
			}
			default -> {
			}
		}
		if (ticks > 20 * 60 * 15) return got() > 0 ? done() : fail("15 минут искал — не нашёл");
		return Status.RUNNING;
	}

	private Status done() {
		walker.stop();
		hands.cancel();
		result = "готово: добыл " + got() + " " + Items2.id(item) + " (в инвентаре " + Inv.count(bot, counts) + ")";
		return Status.DONE;
	}

	private Status fail(String why) {
		walker.stop();
		hands.cancel();
		result = why + "; добыл " + Math.max(0, got());
		return Status.FAILED;
	}

	/** Копать видимые блоки нужного типа рядом (песок, землю, глину…). */
	private Status surface(ServerWorld w) {
		Block source = SOURCE.getOrDefault(item, item instanceof BlockItem bi ? bi.getBlock() : null);
		if (source == null) return fail("не знаю, из какого блока берётся " + Items2.id(item));
		if (collectDrops()) return Status.RUNNING;
		if (surfaceTarget == null || !w.getBlockState(surfaceTarget).isOf(source)) {
			hands.cancel();
			surfaceTarget = findVisible(w, source);
			if (surfaceTarget == null) {
				if (++idle > 100) return got() > 0 ? done() : fail("рядом не вижу " + Items2.id(item));
				return Status.RUNNING;
			}
		}
		idle = 0;
		if (!hands.inReach(surfaceTarget)) {
			walker.moveTo(surfaceTarget, 3.0, false);
			if (walker.failedSearches() >= 3) {
				skip.add(surfaceTarget);
				surfaceTarget = null;
			}
			return Status.RUNNING;
		}
		walker.stop();
		BlockState st = w.getBlockState(surfaceTarget);
		if (st.isToolRequired() && !Inv.canHarvest(bot, st)) return fail("нечем добыть " + Items2.id(item));
		if (hands.breakBlock(surfaceTarget)) surfaceTarget = null;
		return Status.RUNNING;
	}

	private boolean collectDrops() {
		Box area = bot.getBoundingBox().expand(6, 3, 6);
		for (ItemEntity e : bot.getWorld().getEntitiesByClass(ItemEntity.class, area, e -> !e.cannotPickup() && counts.test(e.getStack()))) {
			walker.approach(e.getPos(), 0.5);
			return true;
		}
		return false;
	}

	@Nullable
	private BlockPos findVisible(ServerWorld w, Block source) {
		Vec3d eye = bot.getEyePos();
		BlockPos c = bot.getBlockPos();
		BlockPos best = null;
		double bd = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(c.add(-16, -6, -16), c.add(16, 6, 16))) {
			if (!w.getBlockState(p).isOf(source) || skip.contains(p)) continue;
			double d = p.getSquaredDistance(c);
			if (d >= bd) continue;
			boolean open = false;
			for (Direction dir : Direction.values()) if (w.getBlockState(p.offset(dir)).isAir()) open = true;
			if (!open) continue;
			// видно ли (без рентгена) — если блок далеко, достаточно открытой грани сверху (видно с поверхности)
			if (d > 64 && !w.getBlockState(p.up()).isAir()) continue;
			if (d <= 64) {
				BlockHitResult hit = w.raycast(new RaycastContext(eye, Vec3d.ofCenter(p), RaycastContext.ShapeType.COLLIDER,
						RaycastContext.FluidHandling.NONE, bot));
				if (hit.getType() == HitResult.Type.BLOCK && !hit.getBlockPos().equals(p) && !w.getBlockState(p.up()).isAir()) continue;
			}
			bd = d;
			best = p.toImmutable();
		}
		return best;
	}
}
