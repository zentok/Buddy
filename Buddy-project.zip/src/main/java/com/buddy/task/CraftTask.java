package com.buddy.task;

import com.buddy.BuddyPlayer;
import com.buddy.ai.Hands;
import com.buddy.ai.Inv;
import com.buddy.ai.Walker;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

/** Скрафтить N предметов. Сам найдёт/поставит/скрафтит верстак, если рецепту нужен 3×3. */
public class CraftTask implements Task {
	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final Item item;
	private final int want;
	private final int startCount;
	private final Crafter crafter;
	@Nullable
	private BlockPos table;
	private int ticks;
	private int cooldown;
	private String result = "";

	public CraftTask(BuddyPlayer bot, Walker walker, Hands hands, Item item, int count) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.item = item;
		this.want = Math.max(1, Math.min(count, 256));
		this.startCount = Inv.count(bot, s -> s.isOf(item));
		this.crafter = new Crafter(bot);
	}

	@Override
	public String describe() {
		return "скрафтить " + want + " " + Items2.id(item);
	}

	@Override
	public String result() {
		return result;
	}

	private int have() {
		return Inv.count(bot, s -> s.isOf(item)) - startCount;
	}

	@Override
	public Status tick() {
		if (have() >= want) {
			result = "готово: скрафтил " + have() + " " + Items2.id(item);
			return Status.DONE;
		}
		if (++ticks > 2400) {
			result = "слишком долго, бросил (есть " + have() + " из " + want + ")";
			return Status.FAILED;
		}
		if (cooldown > 0) {
			cooldown--;
			return Status.RUNNING;
		}
		ServerWorld w = bot.getServerWorld();
		boolean atTable = table != null && w.getBlockState(table).isOf(Blocks.CRAFTING_TABLE) && hands.inReach(table);
		if (table != null && !w.getBlockState(table).isOf(Blocks.CRAFTING_TABLE)) table = null;
		if (table != null && !atTable) {
			walker.moveTo(table, 2.5, false);
			if (walker.failedSearches() >= 4) table = null;
			return Status.RUNNING;
		}
		walker.stop();
		Crafter.Result r = crafter.craftOnce(item, atTable);
		switch (r) {
			case CRAFTED -> {
				cooldown = 4;
				if (atTable) hands.lookAt(Vec3d.ofCenter(table));
			}
			case NEED_TABLE -> {
				table = findTable(w);
				if (table == null && !placeTable(w)) {
					// скрафтить верстак (2×2) и поставить
					Crafter.Result t = crafter.craftOnce(Items.CRAFTING_TABLE, false);
					if (t != Crafter.Result.CRAFTED) {
						result = "нужен верстак, а его не из чего сделать (нужны доски/брёвна)";
						return Status.FAILED;
					}
				}
			}
			case MISSING -> {
				result = "не хватает: " + String.join(", ", crafter.missing);
				return have() > 0 ? Status.DONE : Status.FAILED;
			}
			case NO_RECIPE -> {
				result = "у " + Items2.id(item) + " нет рецепта на верстаке (может, его плавят в печи или добывают?)";
				return Status.FAILED;
			}
		}
		return Status.RUNNING;
	}

	@Nullable
	private BlockPos findTable(ServerWorld w) {
		BlockPos c = bot.getBlockPos();
		BlockPos best = null;
		double bd = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(c.add(-16, -4, -16), c.add(16, 4, 16))) {
			if (!w.getBlockState(p).isOf(Blocks.CRAFTING_TABLE)) continue;
			double d = p.getSquaredDistance(c);
			if (d < bd) {
				bd = d;
				best = p.toImmutable();
			}
		}
		return best;
	}

	/** Поставить верстак из инвентаря рядом с собой. */
	private boolean placeTable(ServerWorld w) {
		if (Inv.find(bot, s -> s.isOf(Items.CRAFTING_TABLE)) < 0) return false;
		BlockPos feet = bot.getBlockPos();
		for (Direction d : Direction.Type.HORIZONTAL) {
			BlockPos p = feet.offset(d);
			if (w.getBlockState(p).isReplaceable() && hands.place(p, s -> s.isOf(Items.CRAFTING_TABLE))) {
				table = p;
				return true;
			}
		}
		return false;
	}
}
