package com.buddy.task;

import com.buddy.BuddyPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.recipe.CraftingRecipe;
import net.minecraft.recipe.Ingredient;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.ShapedRecipe;
import net.minecraft.recipe.ShapelessRecipe;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.collection.DefaultedList;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * Крафт по настоящим рецептам игры (в т.ч. из модов): 2×2 — в инвентаре, 3×3 — у верстака.
 * Недостающие промежуточные предметы (доски, палки, верстак…) крафтит сам, если есть из чего.
 */
public final class Crafter {
	public enum Result {CRAFTED, NEED_TABLE, MISSING, NO_RECIPE}

	/** Чего не хватило в последней попытке (для сообщения). */
	public final Set<String> missing = new LinkedHashSet<>();

	private final BuddyPlayer bot;

	public Crafter(BuddyPlayer bot) {
		this.bot = bot;
	}

	public Result craftOnce(Item target, boolean haveTable) {
		missing.clear();
		return craft(target, haveTable, 3, new HashSet<>());
	}

	private List<CraftingRecipe> recipesFor(Item target) {
		ServerWorld w = bot.getServerWorld();
		List<CraftingRecipe> out = new ArrayList<>();
		for (CraftingRecipe r : w.getRecipeManager().listAllOfType(RecipeType.CRAFTING)) {
			if (!(r instanceof ShapedRecipe) && !(r instanceof ShapelessRecipe)) continue;
			ItemStack o = r.getOutput(w.getRegistryManager());
			if (o.isEmpty() || o.getItem() != target) continue;
			// не «разбирать» обратно (слиток из блока ради блока и т.п.)
			boolean selfRef = false;
			for (Ingredient ing : r.getIngredients()) {
				if (!ing.isEmpty() && ing.test(new ItemStack(target))) selfRef = true;
			}
			if (!selfRef) out.add(r);
		}
		return out;
	}

	private static boolean needs3x3(CraftingRecipe r) {
		if (r instanceof ShapedRecipe s) return s.getWidth() > 2 || s.getHeight() > 2;
		int n = 0;
		for (Ingredient i : r.getIngredients()) if (!i.isEmpty()) n++;
		return n > 4;
	}

	private Result craft(Item target, boolean haveTable, int depth, Set<Item> visiting) {
		List<CraftingRecipe> recipes = recipesFor(target);
		if (recipes.isEmpty()) return Result.NO_RECIPE;
		if (!visiting.add(target)) return Result.MISSING;
		boolean needTable = false;
		// 1) можно скрафтить прямо сейчас?
		for (CraftingRecipe r : recipes) {
			if (needs3x3(r) && !haveTable) {
				needTable = true;
				continue;
			}
			int[] used = match(r);
			if (used != null) {
				apply(r, used);
				visiting.remove(target);
				return Result.CRAFTED;
			}
		}
		// 2) скрафтить недостающий ингредиент
		if (depth > 0) {
			for (CraftingRecipe r : recipes) {
				if (needs3x3(r) && !haveTable) continue;
				for (Ingredient ing : missingIngredients(r)) {
					for (ItemStack cand : ing.getMatchingStacks()) {
						Result sub = craft(cand.getItem(), haveTable, depth - 1, visiting);
						if (sub == Result.CRAFTED) {
							visiting.remove(target);
							return Result.CRAFTED; // шаг сделан; следующий тик продолжит
						}
						if (sub == Result.NEED_TABLE) needTable = true;
					}
					ItemStack[] m = ing.getMatchingStacks();
					if (m.length > 0) missing.add(Items2.id(m[0]));
				}
			}
		}
		visiting.remove(target);
		if (needTable && !haveTable) return Result.NEED_TABLE;
		if (missing.isEmpty()) {
			for (CraftingRecipe r : recipes) {
				for (Ingredient ing : missingIngredients(r)) {
					ItemStack[] m = ing.getMatchingStacks();
					if (m.length > 0) missing.add(Items2.id(m[0]));
				}
				break;
			}
		}
		return Result.MISSING;
	}

	/** Номера слотов инвентаря под каждый ингредиент или null. */
	private int[] match(CraftingRecipe r) {
		DefaultedList<ItemStack> main = bot.getInventory().main;
		int[] left = new int[main.size()];
		for (int i = 0; i < main.size(); i++) left[i] = main.get(i).getCount();
		List<Integer> used = new ArrayList<>();
		for (Ingredient ing : r.getIngredients()) {
			if (ing.isEmpty()) continue;
			int found = -1;
			for (int i = 0; i < main.size(); i++) {
				if (left[i] > 0 && ing.test(main.get(i))) {
					found = i;
					break;
				}
			}
			if (found < 0) return null;
			left[found]--;
			used.add(found);
		}
		return used.stream().mapToInt(Integer::intValue).toArray();
	}

	private List<Ingredient> missingIngredients(CraftingRecipe r) {
		DefaultedList<ItemStack> main = bot.getInventory().main;
		int[] left = new int[main.size()];
		for (int i = 0; i < main.size(); i++) left[i] = main.get(i).getCount();
		List<Ingredient> miss = new ArrayList<>();
		for (Ingredient ing : r.getIngredients()) {
			if (ing.isEmpty()) continue;
			boolean ok = false;
			for (int i = 0; i < main.size(); i++) {
				if (left[i] > 0 && ing.test(main.get(i))) {
					left[i]--;
					ok = true;
					break;
				}
			}
			if (!ok) miss.add(ing);
		}
		return miss;
	}

	private void apply(CraftingRecipe r, int[] used) {
		DefaultedList<ItemStack> main = bot.getInventory().main;
		List<ItemStack> remainders = new ArrayList<>();
		for (int slot : used) {
			ItemStack s = main.get(slot);
			Item rem = s.getItem().getRecipeRemainder();
			if (rem != null) remainders.add(new ItemStack(rem));
			s.decrement(1);
		}
		ItemStack out = r.getOutput(bot.getServerWorld().getRegistryManager()).copy();
		out.onCraft(bot.getWorld(), bot, out.getCount());
		bot.getInventory().offerOrDrop(out);
		for (ItemStack rem : remainders) bot.getInventory().offerOrDrop(rem);
		bot.swingHand(net.minecraft.util.Hand.MAIN_HAND);
	}
}
