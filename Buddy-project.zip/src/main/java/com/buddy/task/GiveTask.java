package com.buddy.task;

import com.buddy.BuddyPlayer;
import com.buddy.ai.Hands;
import com.buddy.ai.Inv;
import com.buddy.ai.Walker;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import org.jetbrains.annotations.Nullable;

/** Подойти к хозяину и бросить ему предметы (item=null — всю добычу, кроме инструментов и еды). */
public class GiveTask implements Task {
	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	@Nullable
	private final Item item;
	private final int want;
	private int ticks;
	private String result = "";

	public GiveTask(BuddyPlayer bot, Walker walker, Hands hands, @Nullable Item item, int count) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.item = item;
		this.want = Math.max(1, count);
	}

	@Override
	public String describe() {
		return item == null ? "отдать хозяину добычу" : "отдать хозяину " + want + " " + Items2.id(item);
	}

	@Override
	public String result() {
		return result;
	}

	@Override
	public Status tick() {
		ServerPlayerEntity owner = bot.getOwnerPlayer();
		if (owner == null || owner.getWorld() != bot.getWorld()) {
			result = "хозяина нет рядом";
			return Status.FAILED;
		}
		if (++ticks > 1200) {
			result = "не смог подойти";
			return Status.FAILED;
		}
		if (bot.distanceTo(owner) > 2.8) {
			walker.moveTo(owner.getBlockPos(), 2.0, bot.distanceTo(owner) > 8);
			return Status.RUNNING;
		}
		walker.stop();
		hands.lookAt(owner.getEyePos().add(0, -0.6, 0));
		int given = 0;
		var main = bot.getInventory().main;
		for (int i = 0; i < main.size() && (item == null || given < want); i++) {
			ItemStack s = main.get(i);
			if (s.isEmpty()) continue;
			if (item != null && !s.isOf(item)) continue;
			if (item == null && (Inv.isTool(s) || Inv.isFood(s))) continue;
			int n = item == null ? s.getCount() : Math.min(s.getCount(), want - given);
			ItemStack drop = s.split(n);
			bot.dropItem(drop, false, true);
			given += n;
		}
		if (given == 0) {
			result = item == null ? "отдавать нечего" : "у меня нет " + Items2.id(item);
			return Status.FAILED;
		}
		result = "отдал " + given + (item != null ? " " + Items2.id(item) : " предметов");
		return Status.DONE;
	}
}
