package com.buddy.task;

import com.buddy.BuddyPlayer;
import com.buddy.ai.Walker;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;

/** Дойти до точки (можно далеко: идёт отрезками по ~28 блоков по поверхности). */
public class GotoTask implements Task {
	private final BuddyPlayer bot;
	private final Walker walker;
	private final BlockPos target;
	private final String label;
	private int ticks;
	private int stuck;
	private Vec3d lastPos = Vec3d.ZERO;
	private String result = "";

	public GotoTask(BuddyPlayer bot, Walker walker, BlockPos target, String label) {
		this.bot = bot;
		this.walker = walker;
		this.target = target.toImmutable();
		this.label = label;
	}

	@Override
	public String describe() {
		return "дойти до " + label + " (" + target.getX() + " " + target.getY() + " " + target.getZ() + ")";
	}

	@Override
	public String result() {
		return result;
	}

	@Override
	public Status tick() {
		ServerWorld w = bot.getServerWorld();
		Vec3d pos = bot.getPos();
		double dx = target.getX() + 0.5 - pos.x, dz = target.getZ() + 0.5 - pos.z;
		double hd = Math.sqrt(dx * dx + dz * dz);
		if (hd < 2.5 && Math.abs(target.getY() - pos.y) < 3) {
			walker.stop();
			result = "пришёл к " + label;
			return Status.DONE;
		}
		if (++ticks > 20 * 60 * 5) {
			walker.stop();
			result = "не дошёл за 5 минут, остановился в " + bot.getBlockPos().toShortString();
			return Status.FAILED;
		}
		BlockPos goal = target;
		if (hd > 28) {
			double k = 28 / hd;
			int x = (int) Math.floor(pos.x + dx * k), z = (int) Math.floor(pos.z + dz * k);
			int y = w.isChunkLoaded(x >> 4, z >> 4) ? w.getTopY(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) : bot.getBlockY();
			goal = new BlockPos(x, y, z);
		}
		walker.moveTo(goal, hd > 28 ? 3.0 : 1.5, hd > 8);
		if (ticks % 100 == 0) {
			if (pos.distanceTo(lastPos) < 2) stuck++;
			else stuck = 0;
			lastPos = pos;
			if (stuck >= 4) {
				walker.stop();
				result = "застрял по дороге в " + bot.getBlockPos().toShortString();
				return Status.FAILED;
			}
		}
		return Status.RUNNING;
	}
}
