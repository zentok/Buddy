package com.buddy.task;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;
import org.jetbrains.annotations.Nullable;

import java.util.Locale;

/** Предметы по имени, которое прислал ИИ или игрок: «iron_pickaxe», «minecraft:oak_log», «create:zinc_ingot». */
public final class Items2 {
	private Items2() {
	}

	@Nullable
	public static Item resolve(String raw) {
		if (raw == null) return null;
		String s = raw.trim().toLowerCase(Locale.ROOT).replace(' ', '_');
		if (s.isEmpty()) return null;
		Identifier id = s.contains(":") ? Identifier.tryParse(s) : new Identifier("minecraft", s);
		if (id != null && Registries.ITEM.containsId(id)) return Registries.ITEM.get(id);
		// без пространства имён — поискать в модах
		if (!s.contains(":")) {
			for (Identifier i : Registries.ITEM.getIds()) if (i.getPath().equals(s)) return Registries.ITEM.get(i);
			// синонимы
			switch (s) {
				case "wood", "log", "logs" -> {
					return Items.OAK_LOG;
				}
				case "iron", "iron_ore" -> {
					return Items.RAW_IRON;
				}
				case "gold", "gold_ore" -> {
					return Items.RAW_GOLD;
				}
				case "copper", "copper_ore" -> {
					return Items.RAW_COPPER;
				}
				case "coal_ore" -> {
					return Items.COAL;
				}
				case "diamond_ore", "diamonds" -> {
					return Items.DIAMOND;
				}
				case "stone", "cobble" -> {
					return Items.COBBLESTONE;
				}
				default -> {
				}
			}
		}
		return null;
	}

	public static String id(Item item) {
		Identifier id = Registries.ITEM.getId(item);
		return id.getNamespace().equals("minecraft") ? id.getPath() : id.toString();
	}

	public static String id(ItemStack s) {
		return id(s.getItem());
	}
}
