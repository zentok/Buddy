package com.buddy.task;

import com.buddy.BuddyPlayer;
import com.buddy.ai.Hands;
import com.buddy.ai.Inv;
import com.buddy.ai.Walker;
import net.fabricmc.fabric.api.registry.FuelRegistry;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.FurnaceBlockEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.recipe.RecipeType;
import net.minecraft.recipe.SmeltingRecipe;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.jetbrains.annotations.Nullable;

/**
 * Переплавить в печи: «smelt iron_ingot 5» (или «smelt raw_iron 5»).
 * Ищет печь рядом, ставит свою или крафтит из булыжника; кладёт руду и топливо, ждёт, забирает результат.
 */
public class SmeltTask implements Task {
	private enum Phase {PREPARE, LOAD, WAIT}

	private final BuddyPlayer bot;
	private final Walker walker;
	private final Hands hands;
	private final int want;
	@Nullable
	private Item output;
	@Nullable
	private SmeltingRecipe recipe;
	@Nullable
	private BlockPos furnace;
	@Nullable
	private CraftTask makeFurnace;
	private Phase phase = Phase.PREPARE;
	private int collected;
	private int ticks;
	private int loadedInput;
	private String result = "";
	private final String asked;

	public SmeltTask(BuddyPlayer bot, Walker walker, Hands hands, Item what, int count) {
		this.bot = bot;
		this.walker = walker;
		this.hands = hands;
		this.want = Math.max(1, Math.min(count, 64));
		this.asked = Items2.id(what);
		findRecipe(what);
	}

	private void findRecipe(Item what) {
		ServerWorld w = bot.getServerWorld();
		SmeltingRecipe byOutput = null;
		for (SmeltingRecipe r : w.getRecipeManager().listAllOfType(RecipeType.SMELTING)) {
			ItemStack out = r.getOutput(w.getRegistryManager());
			boolean haveInput = Inv.find(bot, s -> r.getIngredients().get(0).test(s)) >= 0;
			if (out.isOf(what) && haveInput) {
				recipe = r;
				output = out.getItem();
				return;
			}
			if (out.isOf(what) && byOutput == null) byOutput = r;
			if (r.getIngredients().get(0).test(new ItemStack(what))) {
				recipe = r;
				output = out.getItem();
				return;
			}
		}
		if (byOutput != null) {
			recipe = byOutput;
			output = byOutput.getOutput(w.getRegistryManager()).getItem();
		}
	}

	@Override
	public String describe() {
		return "переплавить " + want + " → " + (output != null ? Items2.id(output) : asked);
	}

	@Override
	public String result() {
		return result;
	}

	@Override
	public Status tick() {
		ServerWorld w = bot.getServerWorld();
		if (recipe == null || output == null) {
			result = "не знаю, как получить " + asked + " в печи";
			return Status.FAILED;
		}
		if (++ticks > want * 220 + 2400) {
			result = "печь слишком долго, забрал " + collected;
			return collected > 0 ? Status.DONE : Status.FAILED;
		}
		SmeltingRecipe rec = recipe;
		switch (phase) {
			case PREPARE -> {
				if (Inv.find(bot, s -> rec.getIngredients().get(0).test(s)) < 0 && loadedInput == 0) {
					result = "нечего плавить: нет " + firstId(rec);
					return Status.FAILED;
				}
				if (fuelSlot() < 0) {
					result = "нет топлива (уголь, доски, брёвна)";
					return Status.FAILED;
				}
				if (furnace == null || !(w.getBlockEntity(furnace) instanceof AbstractFurnaceBlockEntity)) furnace = findFurnace(w);
				if (furnace == null) {
					if (placeFurnace(w)) return Status.RUNNING;
					if (makeFurnace == null) makeFurnace = new CraftTask(bot, walker, hands, Items.FURNACE, 1);
					Status s = makeFurnace.tick();
					if (s == Status.FAILED) {
						result = "нет печи, а сделать не из чего: " + makeFurnace.result();
						return Status.FAILED;
					}
					return Status.RUNNING;
				}
				if (!hands.inReach(furnace)) {
					walker.moveTo(furnace, 2.5, false);
					if (walker.failedSearches() >= 4) {
						result = "не могу дойти до печи";
						return Status.FAILED;
					}
					return Status.RUNNING;
				}
				walker.stop();
				phase = Phase.LOAD;
			}
			case LOAD -> {
				AbstractFurnaceBlockEntity f = furnace(w);
				if (f == null) {
					phase = Phase.PREPARE;
					return Status.RUNNING;
				}
				hands.lookAt(Vec3d.ofCenter(furnace));
				// руда
				ItemStack in = f.getStack(0);
				int need = want - loadedInput;
				for (int i = 0; i < bot.getInventory().main.size() && need > 0; i++) {
					ItemStack s = bot.getInventory().main.get(i);
					if (s.isEmpty() || !rec.getIngredients().get(0).test(s)) continue;
					if (!in.isEmpty() && !ItemStack.canCombine(in, s)) break;
					int space = s.getMaxCount() - (in.isEmpty() ? 0 : in.getCount());
					int n = Math.min(Math.min(need, s.getCount()), space);
					if (n <= 0) break;
					if (in.isEmpty()) {
						in = s.copyWithCount(n);
						f.setStack(0, in);
					} else in.increment(n);
					s.decrement(n);
					need -= n;
					loadedInput += n;
				}
				// топливо
				int burnPerItem = 200;
				int totalTicks = (want - collected) * burnPerItem;
				ItemStack fuelIn = f.getStack(1);
				int have = fuelIn.isEmpty() ? 0 : fuelIn.getCount() * burnTime(fuelIn.getItem());
				while (have < totalTicks) {
					int slot = fuelSlot();
					if (slot < 0) break;
					ItemStack fs = bot.getInventory().main.get(slot);
					if (!fuelIn.isEmpty() && !ItemStack.canCombine(fuelIn, fs)) break;
					int bt = burnTime(fs.getItem());
					int n = Math.min(fs.getCount(), Math.max(1, (int) Math.ceil((totalTicks - have) / (double) bt)));
					if (!fuelIn.isEmpty()) n = Math.min(n, fuelIn.getMaxCount() - fuelIn.getCount());
					if (n <= 0) break;
					if (fuelIn.isEmpty()) {
						fuelIn = fs.copyWithCount(n);
						f.setStack(1, fuelIn);
					} else fuelIn.increment(n);
					fs.decrement(n);
					have += n * bt;
				}
				f.markDirty();
				w.playSound(null, furnace, SoundEvents.BLOCK_FURNACE_FIRE_CRACKLE, SoundCategory.BLOCKS, 0.6f, 1f);
				phase = Phase.WAIT;
			}
			case WAIT -> {
				AbstractFurnaceBlockEntity f = furnace(w);
				if (f == null) {
					result = "печь пропала, забрал " + collected;
					return collected > 0 ? Status.DONE : Status.FAILED;
				}
				if (!hands.inReach(furnace)) {
					walker.moveTo(furnace, 2.5, false);
					return Status.RUNNING;
				}
				walker.stop();
				if (ticks % 20 == 0) {
					hands.lookAt(Vec3d.ofCenter(furnace));
					ItemStack out = f.getStack(2);
					if (!out.isEmpty()) {
						int n = out.getCount();
						bot.getInventory().offerOrDrop(out.copy());
						f.setStack(2, ItemStack.EMPTY);
						f.markDirty();
						collected += n;
					}
					if (collected >= want) {
						result = "готово: " + collected + " " + Items2.id(output);
						return Status.DONE;
					}
					// руда кончилась в печи, а мы положили меньше нужного — догрузить
					if (f.getStack(0).isEmpty() && loadedInput < want) phase = Phase.PREPARE;
					else if (f.getStack(0).isEmpty() && f.getStack(2).isEmpty() && !isBurning(f)) {
						result = "готово: " + collected + " " + Items2.id(output);
						return collected > 0 ? Status.DONE : Status.FAILED;
					}
				}
			}
		}
		return Status.RUNNING;
	}

	private static boolean isBurning(AbstractFurnaceBlockEntity f) {
		return f.getCachedState().contains(net.minecraft.block.AbstractFurnaceBlock.LIT) && f.getCachedState().get(net.minecraft.block.AbstractFurnaceBlock.LIT);
	}

	private static String firstId(SmeltingRecipe r) {
		ItemStack[] m = r.getIngredients().get(0).getMatchingStacks();
		return m.length > 0 ? Items2.id(m[0]) : "?";
	}

	private static int burnTime(Item i) {
		Integer t = FuelRegistry.INSTANCE.get(i);
		return t == null ? 0 : t;
	}

	/** Лучшее топливо в инвентаре (не жжём инструменты и саженцы). */
	private int fuelSlot() {
		var main = bot.getInventory().main;
		int best = -1, bestT = 0;
		for (int i = 0; i < main.size(); i++) {
			ItemStack s = main.get(i);
			if (s.isEmpty() || Inv.isTool(s) || s.isOf(Items.CRAFTING_TABLE) || Inv.isSeed(s)) continue;
			if (recipe != null && recipe.getIngredients().get(0).test(s)) continue;
			int t = burnTime(s.getItem());
			if (t > bestT && t <= 16000) {
				bestT = t;
				best = i;
			}
		}
		return best;
	}

	@Nullable
	private AbstractFurnaceBlockEntity furnace(ServerWorld w) {
		if (furnace == null) return null;
		BlockEntity be = w.getBlockEntity(furnace);
		return be instanceof AbstractFurnaceBlockEntity f ? f : null;
	}

	@Nullable
	private BlockPos findFurnace(ServerWorld w) {
		BlockPos c = bot.getBlockPos();
		BlockPos best = null;
		double bd = Double.MAX_VALUE;
		for (BlockPos p : BlockPos.iterate(c.add(-16, -4, -16), c.add(16, 4, 16))) {
			BlockEntity be = w.getBlockEntity(p);
			if (!(be instanceof FurnaceBlockEntity f)) continue;
			// занятая чужой плавкой печь не подходит
			if (!f.getStack(0).isEmpty() && recipe != null && !recipe.getIngredients().get(0).test(f.getStack(0))) continue;
			double d = p.getSquaredDistance(c);
			if (d < bd) {
				bd = d;
				best = p.toImmutable();
			}
		}
		return best;
	}

	private boolean placeFurnace(ServerWorld w) {
		if (Inv.find(bot, s -> s.isOf(Items.FURNACE)) < 0) return false;
		BlockPos feet = bot.getBlockPos();
		for (Direction d : Direction.Type.HORIZONTAL) {
			BlockPos p = feet.offset(d);
			if (w.getBlockState(p).isReplaceable() && hands.place(p, s -> s.isOf(Items.FURNACE))) {
				furnace = p;
				return true;
			}
		}
		return false;
	}
}
