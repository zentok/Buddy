package com.buddy.task;

/** Задача бота с понятным результатом (для ИИ-планировщика: «сделано / не вышло, потому что…»). */
public interface Task {
	enum Status {RUNNING, DONE, FAILED}

	Status tick();

	/** Что делаем (для чата и для ИИ): «скрафтить 1 iron_pickaxe». */
	String describe();

	/** Итог после DONE/FAILED: «готово, в инвентаре 1 iron_pickaxe» или «не хватает: stick». */
	String result();

	/** Прервать (новая команда). */
	default void cancel() {
	}
}
